## Metadata_Start 
## code: en
## title: Rotating a selection 
## slug: rotating-a-selection 
## seoTitle: Rotating a selection 
## description:  
## contentType: Markdown 
## Metadata_End

*Rotating a selection*

To rotate a selection using the mouse:

1\. 	Position the mouse cursor near one of the corner handles (represented by squares), side handles (represented by circles), or near the transformation rectangle bounds. 

![][free_transform_operation_04]

2\. 	Press the mouse button and drag the mouse. The transformation rectangle will rotate around its center. Hold down the Shift key to constrain the rotation angle to 45-degree increments.

3\. 	Release the button to accept the rotation.

To move the center of rotation, just drag the center handle (represented by a cross) to its new position.

To rotate a selection using the Property bar, enter the value of rotation and press Free\_Transform\_operation\_property\_bar\_CCW.png to rotate left or counter clockwise, or Free\_Transform\_operation\_property\_bar\_CW.png to rotate right or clockwise. You can use the nine-point proxy Free\_Transform\_operation\_property\_bar\_nineproxy.png to choose the origin point of the transformation. Click in the editing field or press Return to accept the completed transformation or press the Esc key to reject it.

*Slanting or skewing a selection*

To slant or skew a selection using the mouse:

1\. 	Position the mouse cursor on one of the side handles (represented by circles), or on the transformation rectangle bounds, just like you would for scaling.

2\. 	Press Cmd (or Ctrl on Windows) and drag the mouse. The transformation rectangle will be slanted. Hold down the Shift key to constrain the slant direction to horizontal or vertical. Hold down Alt to slant around the center handle. Drag horizontal bounds to slant horizontally, and vertical bounds to slant vertically. 

![][free_transform_operation_05]

3\. 	Release the button to accept the slanting.

To slant or skew a selection using the Property bar, enter the angle into the text field, and press Free\_Transform\_operation\_property\_bar\_slant\_left.png to slant left or Free\_Transform\_operation\_property\_bar\_slant\_right.png to slant right. You can use the nine-point proxy Free\_Transform\_operation\_property\_bar\_nineproxy.png to choose the origin point of the transformation. Click in the editing field or press Return to accept the completed transformation or press the Esc key to reject it.

*Distorting a selection*

To distort a selection:

1\. 	Position the mouse cursor on one of the corner handles (represented by squares).

2\. 	Press Cmd (or Ctrl on Windows) and drag the mouse. The transformation rectangle will be distorted in the direction you move the mouse. Hold down the Shift key to constrain the direction to horizontal or vertical. Hold down Alt to distort around the center handle.

![][free_transform_operation_07]

3\. 	Release the button to accept the distortion.

Click in the editing field or press Return to accept the completed transformation or press the Esc key to reject it.

*Flipping the selection*

* To flip a selection horizontally, press ⧒.
* To flip a selection vertically, press ⤪.

You can use the nine-point proxy (󰁴) to choose the origin point of the transformation. Click in the editing field or press Return to accept the completed transformation or press the Esc key to reject it.

Note that during Free Transform, Edit \> Undo cancels the current transformation process (the same way it did in FontLab Studio 5), and does not undo the previous action.

[free_transform_operation_04]: free_transform_operation_04.png width=93px height=100px

[free_transform_operation_05]: free_transform_operation_05.png width=159px height=99px

[free_transform_operation_07]: free_transform_operation_07.png width=107px height=100px