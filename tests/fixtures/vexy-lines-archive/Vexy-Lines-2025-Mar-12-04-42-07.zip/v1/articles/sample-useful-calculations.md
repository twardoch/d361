## Metadata_Start 
## code: en
## title: Sample useful calculations 
## slug: sample-useful-calculations 
## seoTitle: Sample useful calculations 
## description:  
## contentType: Markdown 
## Metadata_End

To put a guideline in the middle of the baseline and x-height:

(x\_height-baseline)/2

To put a guideline 12u below the baseline, useful for an overshoot:

baseline-12

To position an anchor at a given distance from the caps height you can use:

caps\_height+64

To add a vertical glyph guideline at the exact middle of the glyph using simply:

width/2

To define the coordinates of an anchor (x,y) in relation to the glyph’s advance width and the font’s baseline:

width/2, baseline-80

Here, the first expression defines the horizontal position and the second, the vertical one.