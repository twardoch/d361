## Metadata_Start 
## code: en
## title: **Contour: Overlap: Exclude** 
## slug: contour-overlap-exclude 
## seoTitle: **Contour: Overlap: Exclude** 
## description:  
## contentType: Markdown 
## Metadata_End

If you choose ==Contour > Overlap > Exclude==, the result is a _union contour_, which contains the union of the “front” and “back” contours (same as the result of ==Contour > Remove Overlap==), and an _intersection contour_, which contains the overlapping areas of the “front” and “back” contours (same as the result of ==Contour > Overlap > Intersect==). The intersection contour has the opposite direction of the union contour. The original direction of the “front” and “back” contours doesn’t matter. FontLab removes the original “front” and “back” contours.

This is similar to ==Exclude== in Adobe Illustrator.

A non-distructive alternative to ==Exclude== is the ==Fill== tool or Fusion group(see above).
