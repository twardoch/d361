## Metadata_Start 
## code: en
## title: Document View Properties 
## slug: document-view-options 
## seoTitle: Document View Properties 
## description:  
## contentType: Markdown 
## Metadata_End
Vexy Lines offers several ways to control how your artwork is displayed while working. These view settings help you focus on specific aspects of your design and make editing easier.

## Toolbar View Controls

The main **toolbar** provides quick access to essential visibility toggles:

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-M4368HKU.png){height="" width="177"}

![Highlight edges](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/view-selection(6).svg) **Highlight Edges**: Makes selected strokes more visible
![Show masks](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/view-controls(4).svg) **Show Masks**: Displays masks and mesh edges
![Show fills](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/show-fills.svg) **Show Fills**: Toggles visibility of all fills
![Show source](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/show-images.svg) **Show Source**: Controls visibility of source images


## View Menu

The **View** menu in the main menu bar offers additional display options:
- Zoom controls and navigation
- Interface element visibility
- Background color settings
- Refresh and rendering options

## Properties Panel

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-208J3U1X.png){height="" width="277"}

The View section of the Properties panel gives you precise control over:

### Source Image Display
Fine-tune how reference images appear:
- Adjust **transparency** (25-100%)
- Toggle **visibility**
- Set custom **background color**

### Visual Highlights
Customize how different elements stand out:
- **Edge** highlight colors
- **Mask boundary** visibility
- **Mesh grid** display
- **Mask highlight** colors

Remember: These view settings only affect how you see your artwork while working - they don't change the final exported result.