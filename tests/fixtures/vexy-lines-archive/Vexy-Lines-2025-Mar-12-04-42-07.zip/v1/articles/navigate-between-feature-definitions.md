## Metadata_Start 
## code: en
## title: Navigate between feature definitions 
## slug: navigate-between-feature-definitions 
## seoTitle: Navigate between feature definitions 
## description:  
## contentType: Markdown 
## Metadata_End

If you’re in the ==Features== panel, you can now use keyboard shortcuts to navigate between the feature definitions: 

- press ++Cmd+BracketRight++{ .M } or ++Ctrl+BracketRight++{ .W } to navigate to the next feature definition, 
- press ++Cmd+BracketLeft++{ .M } or ++Ctrl+BracketLeft++{ .W } to navigate to the previous feature definition. 

