## Metadata_Start 
## code: en
## title: Autohint 
## slug: autohint-2 
## seoTitle: Autohint 
## description:  
## contentType: Markdown 
## Metadata_End

Analyzes a glyph’s outline and generates PostScript hints for the glyph. This is the Tools \> Autohint command.