## Metadata_Start 
## code: en
## title: Drawing sharp and smooth nodes 
## slug: drawing-sharp-and-smooth-nodes 
## seoTitle: Drawing sharp and smooth nodes 
## description:  
## contentType: Markdown 
## Metadata_End

If all Rapid sub-tools are turned off, you can use Rapid to add sharp or smooth nodes in two ways.

If the ==Preferences > Editing > Rapid tool remembers last state== setting is turned off (default):

- Click to add a sharp node, and to make the next segment a line.
- Double-click or ++Ctrl++-click to add a smooth node, and to make the previous and the next segment a curve.
- Hold ++Shift++ to align the next node to the previous one horizontally or vertically.

If the setting is turned on, each click adds a sharp node, and makes the next segment a line, until you double-click or ++Ctrl++-click. Rapid then adds a smooth node, and all subsequent clicks add a smooth node, until you double-click or ++Ctrl++-click again. Rapid then adds a sharp node, and all subsequent clicks add a smooth node.

If you turn on the ==Rapid > Corner== sub-tool, you can click to add a sharp node, and double-click to add a smooth node. If you turn the ==Rapid > Curve== sub-tool, you can click to add a smooth node, and double-click to add a sharp node. In both cases, keyboard modifiers except ++Shift++ have no function.
