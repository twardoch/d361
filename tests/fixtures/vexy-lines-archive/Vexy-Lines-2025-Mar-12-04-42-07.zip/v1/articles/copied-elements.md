## Metadata_Start 
## code: en
## title: Copied elements 
## slug: copied-elements 
## seoTitle: Copied elements 
## description:  
## contentType: Markdown 
## Metadata_End

* If you want to re-use some contours as element references in multiple glyphs, or if you want to assign a different color or stroke to some contours, or if you want to apply a different filter such as Power Brush to contours, you can create independent, separate elements based on existing contours or elements.
* In the Glyph window, navigate to the glyph and layer from which you want to copy.
* If you want to copy entire contours or just some segments, then with the Contour (A) tool, select some contours or segments, and choose Edit \> Copy Contours (CmdC CtrlC). Navigate to the glyph and layer where you want to paste, and choose Edit \> Paste New Element (ShiftCmdV CtrlShiftV). FontLab creates a new element, and pastes the copied contours there.
* If you want to copy one or more elements, then with the Element (V) tool, select the element(s), choose Edit \> Copy (CmdC CtrlC). Navigate to the glyph and layer where you want to paste, and choose Edit \> Paste Elements (CmdV CtrlV).