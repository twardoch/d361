## Metadata_Start 
## code: en
## title: Easier handling of export profiles 
## slug: easier-handling-of-export-profiles-1 
## seoTitle: Easier handling of export profiles 
## description:  
## contentType: Markdown 
## Metadata_End

The File \> Export Font As… dialog has a new Customize… button that opens a Customize Profile dialog where you can quickly change the technical settings of the currently selected export profile.

*If the currently selected profile is a built-in profile, shown in bold in the profiles list, FontLab will create a duplicate custom profile with the name suffix* (clone) *that you can change*.

Previously, to change the export settings, you first had to open File \> Profiles, choose or clone a profile, customize it, close the dialog, then open File \> Export Font As… and choose the just-customized profile.

When you now open File \> Profiles to customize a profile, the profile that you last used in File \> Export Font As… will be selected. Previously, the Profiles dialog opened with the first profile selected.

In the File \> Profiles dialog, the profiles list is now wider.