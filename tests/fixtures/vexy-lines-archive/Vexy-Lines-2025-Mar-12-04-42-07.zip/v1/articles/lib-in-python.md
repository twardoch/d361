## Metadata_Start 
## code: en
## title: Lib in Python 
## slug: lib-in-python 
## seoTitle: Lib in Python 
## description:  
## contentType: Markdown 
## Metadata_End

You can access the font Lib and the Lib of the current master in Python:

from fontlab import *

print(flPackage(CurrentFont()).packageLib)

print(flPackage(CurrentFont()).masterLib)
