## Metadata_Start 
## code: en
## title: Unicode in CJK fonts 
## slug: unicode-in-cjk-fonts-1 
## seoTitle: Unicode in CJK fonts 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 7.1 exports the Windows-compatible OpenType cmap subtable 3.1 with format 4 more efficiently. This means that fonts with large glyph sets (\>20,000 glyphs) now export correctly in more cases.

| :----- |
| Because of the limitations of the OpenType format, there is no 100% guarantee that this will always work. |

To achieve additional optimization, do Font \> Sort Glyphs \> Unicode before exporting the font