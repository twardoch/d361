## Metadata_Start 
## code: en
## title: Anchors in Python 
## slug: anchors-in-python 
## seoTitle: Anchors in Python 
## description:  
## contentType: Markdown 
## Metadata_End

The FontLab Python API now exposes anchors, including their expressions. With TypeRig, you can access them via:

from typerig.proxy import *

g = pGlyph()

print(g.anchors())
