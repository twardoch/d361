## Metadata_Start 
## code: en
## title: Additional acknowledgments 
## slug: additional-acknowledgments 
## seoTitle: Additional acknowledgments 
## description:  
## contentType: Markdown 
## Metadata_End

Curvature visualization inspired by Speed Punk by Jan “Yanone” Gerner.

FontAudit visualization inspired by Glyph Nanny by Tal Leming © 2014 Type Supply LLC.

Thickness visualization inspired by SuperTool by Simon Cozens.

Cover artwork by Jean François Porchez (Typofonderie + ZeCraft)