## Metadata_Start 
## code: en
## title: End lines, center line, rainbow 
## slug: end-lines-center-line-rainbow-1 
## seoTitle: End lines, center line, rainbow 
## description:  
## contentType: Markdown 
## Metadata_End

Then, turn on additional Quick measurement details to show along the basic Quick measurement:

*Show end lines:* if on, in addition to basic Quick measurement (the distance between two opposite segments near your pointer), FontLab also shows distances near both ends of opposite segments inside a filled area.

*Show center line:* if on, in addition to basic Quick measurement, FontLab temporarily shows a green center line between two opposing segments inside a filled area. Useful for positioning guides or anchors in the center of a stem.

*Show rainbow:* if on, in addition to basic Quick measurement, FontLab also shows a thickness rainbow between opposite segments inside a filled area.

* If the segments are lines, the thickness is even (the rainbow is uniform blue) if they are perfectly parallel.
* If the segments are curves, the thickness is even when the contrast between the measured vertical and horizontal thickness matches the contrast specified in Measurements panel.
* When the thickness is not even, the rainbow is colorful: blue where the distance is smallest, and red where it’s largest.

To equalize the thickness of a stem (esp. diagonal or curved), enter the desired contrast in Measurements panel, turn off Preferences \> Editing \> Clicking outline selects segment, click anywhere in a segment, or click a Tunni line or a node or handle, then place the pointer inside the stem so the rainbow appears, and use cursor keys to tweak the position until the rainbow becomes uniform blue.

| :----- |
| The thickness rainbow visualization was inspired by Super Tool by **Simon Cozens**. |