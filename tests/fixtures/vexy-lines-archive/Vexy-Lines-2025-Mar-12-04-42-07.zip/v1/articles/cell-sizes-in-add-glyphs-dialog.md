## Metadata_Start 
## code: en
## title: Cell sizes in Add Glyphs dialog 
## slug: cell-sizes-in-add-glyphs-dialog 
## seoTitle: Cell sizes in Add Glyphs dialog 
## description:  
## contentType: Markdown 
## Metadata_End

In the Font \> Add Glyphs dialog, cell sizes were increased to better show glyphs that extend to the height limits (diacritics, descenders, etc.).