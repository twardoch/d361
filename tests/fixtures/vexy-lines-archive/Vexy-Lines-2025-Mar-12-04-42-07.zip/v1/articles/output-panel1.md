## Metadata_Start 
## code: en
## title: Output panel-1 
## slug: output-panel1 
## seoTitle: Output panel-1 
## description:  
## contentType: Markdown 
## Metadata_End

**Output panel**

The Output panel is used by the macro system to show the results of macro program interpretation from the Scripting panel, and by OpenType features compiler to show error messages and warnings that come up from the features written in the Features panel.

To open the contextual menu of the panel, Right-CLICK anywhere in text area of the panel. The menu has three operations – Copy, Select All and Clear.

To erase all of the panels contents, press Clear in the contextual menu, or click ✕.