## Metadata_Start 
## code: en
## title: Using the Property bar 
## slug: using-the-property-bar-1 
## seoTitle: Using the Property bar 
## description:  
## contentType: Markdown 
## Metadata_End

When you have a glyph (or several glyphs) open in the Glyph window with no nodes or contours selected, the Property bar looks like this:

![][property_bar_labeled]

[property_bar_labeled]: property_bar_labeled.png width=1242px height=225px