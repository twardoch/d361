## Metadata_Start 
## code: en
## title: Removing Pins 
## slug: removing-pins 
## seoTitle: Removing Pins 
## description:  
## contentType: Markdown 
## Metadata_End

To remove a pin, click it to select it and press Backspace or Del on your keyboard. You can also remove a pin through the Anchors and Pins panel: select the pin in the panel and click the – button.