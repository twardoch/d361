## Metadata_Start 
## code: en
## title: Closed and Open Contours 
## slug: closed-and-open-contours 
## seoTitle: Closed and Open Contours 
## description:  
## contentType: Markdown 
## Metadata_End

Contours may be open or closed:

contours\_01.png

All current font formats require contours to be closed, but during outline editing it may be useful to have some contours in an open form and later connect them to each other to build final closed contours.

In FontLab it is very easy to open closed contours or to close open contours. It is also possible to customize the appearance of the open contours so that some of them are shown filled:

contours\_12.png contours\_13.png