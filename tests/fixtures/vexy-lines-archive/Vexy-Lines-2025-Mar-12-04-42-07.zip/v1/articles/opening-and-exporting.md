## Metadata_Start 
## code: en
## title: Opening and exporting 
## slug: opening-and-exporting 
## seoTitle: Opening and exporting 
## description:  
## contentType: Markdown 
## Metadata_End

**Opening and exporting .glyphs files**

FontLab now includes many detailed improvements when opening and exporting files in the .glyphs format.

FontLab opens .glyphs brace layers such as \{300, 100\} as sparse font-less masters with layer names :wt=300,wd=100.

With FontLab 6.1.4 (both the Mac and the Windows version), you can now export .glyphs files, and you can also open .glyphs files much more faithfully!

So now, you can easily exchange source files with users of [Glyphs.app](https://glyphsapp.com/), or you can quickly switch from one app to another (and back, if need be), depending on the tasks you’re facing and the tools you need. FontLab also opens and exports .designSpace files and .ufo packages (both UFO 2 and UFO 3), and in the past few versions, we’ve greatly improved the support for these formats. So it has been really easy to collaborate with users of [RoboFont](https://robofont.com/), [Superpolator](http://superpolator.com/) or [FontForge](https://fontforge.github.io/) as well, and to use those apps along FontLab.

*Note: export to* .glyphs *is* “beta” *functionality, so in this release, the* Glyphs *font export profile is hidden by default.* Go to File \> Profiles, turn on the blue checkbox next to the Glyphs entry, and click OK. Now go to File \> Export Font As and choose the Glyphs profile. The Glyphs export profile exports the entire font with multiple masters into one file (into the Source-Glyphs subfolder if you turn on Subfolders by: Profile).

When FontLab opens or exports .glyphs, it correctly translates the most essential info:

* *masters* and *instance* defintions
* *glyphs* and *layers*
* *contours* and ordinary *components*
* *guides* and *anchors*
* *kerning* and *kerning groups*
* some font *custom parameters* such as naming
* some master *custom parameters*
* the *font note*, *TrueType stem* info and various other details

But FontLab does not read or export *all* data. Below are some known limitations in 6.1.4:

When FontLab opens a .glyphs file, it converts all *automatically aligned* components into normal manually positioned components, and reads *smart components* and *serif components* as plain contours.

FontLab does not read or export many font or master *custom parameters*, the do *not export* glyph flag, stored tabs or windows, info about the *automatic alignment* of components, some *hinting* info.

FontLab reads metrics keys from .glyphs as metrics expressions, and exports metrics expressions to .glyphs as metrics keys. However —while the syntax of the FontLab [metrics expressions](https://help.fontlab.com/fontlab-vi/Editing-Glyph-Metrics/) and that of Glyphs *metrics keys* is similar in many aspects— there are differences. At this point, FontLab does some conversion, but you may get keys or expressions that are valid in one app but invalid in another.

However, since both apps also store the actual glyph metrics, if you want to quickly “hop over” from one tool to another and back for a little fix —you can, and your metrics keys/expressions will survive. But if you set up more complex keys/expressions in one app and then change the spacing in another app, and go back to the first app —you may get unexpected results. You can always check which glyphs have expressions in FontLab’s Font window list view and remove them with Font \> Remove Metrics Links.

If you open a .glyphs file in FontLab, and then export a new .glyphs file, you can open both files in the [MergeGlyphs](https://glyphsapp.com/tools/mergeglyphs) utility to compare what has changed, and you can even copy over some info that’s missing.