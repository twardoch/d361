## Metadata_Start 
## code: en
## title: Delta Instructions 
## slug: delta-instructions 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

#### \#\# Delta Instructions

Now you know all about the visual hinting commands that can be applied to an outline at all PPMs. In addition to these commands the TrueType hinting language lets you set special commands that will work only at specific PPM sizes. These commands are called delta instructions.

There are two delta instructions for each hinting direction: middle delta instructions and final delta instructions.