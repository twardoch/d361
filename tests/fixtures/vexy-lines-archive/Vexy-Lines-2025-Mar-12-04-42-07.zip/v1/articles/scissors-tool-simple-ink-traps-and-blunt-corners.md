## Metadata_Start 
## code: en
## title: Scissors tool simple ink traps and blunt corners 
## slug: scissors-tool-simple-ink-traps-and-blunt-corners 
## seoTitle: Scissors tool simple ink traps and blunt corners 
## description:  
## contentType: Markdown 
## Metadata_End

**Scissors tool: simple ink traps and blunt corners**

When you Shift-click a node (smooth or sharp) with the Scissors tool, FontLab 7.1 duplicates the node, and intelligently moves the resulting two nodes apart by the distance defined in Font Info \> Font Dimensions \> Ink trap width

[![][fl71-make-inktrap]](file:///Volumes/Igor/Manual/Github/docs/fontlab/7/manual/img/fl71-make-inktrap.png)

Inktrap with Scissors tool

When Edit \> Match when Editing is on, this happens on all matching masters.

You can still use Smart Corners to create live, adjustable rounded corners and curved ink traps.

| :----- |
| Curved ink traps made with Smart Corners are live until you use Apply Smart Corner, so existing ink traps in the current font master change when you change the Ink trap width parameter. Simple ink traps made with Scissors are created immediately. |

[fl71-make-inktrap]: fl71-make-inktrap.png width=174px height=153px