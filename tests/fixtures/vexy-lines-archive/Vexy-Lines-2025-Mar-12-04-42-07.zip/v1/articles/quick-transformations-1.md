## Metadata_Start 
## code: en
## title: Quick transformations 
## slug: quick-transformations-1 
## seoTitle: Quick transformations 
## description:  
## contentType: Markdown 
## Metadata_End

While in the Glyph Window, you can use keyboard shortcuts to activate the quick transformation tools that allow you to scale, slant, rotate and flip (mirror) your elements, contours or contour selections visually. 

| :----- |
| See Geometric transformations for information about the difference between element-level and contour-level transformations. |