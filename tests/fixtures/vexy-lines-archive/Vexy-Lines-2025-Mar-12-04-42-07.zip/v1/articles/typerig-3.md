## Metadata_Start 
## code: en
## title: typerig 
## slug: typerig-3 
## seoTitle: typerig 
## description:  
## contentType: Markdown 
## Metadata_End

The TypeRig package includes the [typerig](https://fontlabcom.github.io/fontlab-python-docs/typerig.html) Python package that provides a simplified, alternative “pythonic” API to FontLab. TypeRig is written in Python. To use the typerig package, run FontLab 7, choose *Scripts \> Update / Install Scripts*. Click *OK* in the dialog, wait until the installation completes. When you see the TypeRig is up-to-date dialog, click *OK* and close FontLab 7. If your macOS asks you to install the Developer Tools, install them. Once the installation is complete, start FontLab 7 and check the Scripts menu.