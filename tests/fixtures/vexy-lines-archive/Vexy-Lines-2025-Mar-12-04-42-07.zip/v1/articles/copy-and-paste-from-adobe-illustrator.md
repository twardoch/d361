## Metadata_Start 
## code: en
## title: Copy and paste from Adobe Illustrator 
## slug: copy-and-paste-from-adobe-illustrator 
## seoTitle: Copy and paste from Adobe Illustrator 
## description:  
## contentType: Markdown 
## Metadata_End

When you copy vector artwork in Adobe Illustrator, and then paste it into the Glyph window with Preferences \> Paste & Duplicate \> Ignore stroke and colors selected, FontLab now selects the pasted content.

When you copy vector artwork in Adobe Illustrator, and then you paste it into the Glyph window with Preferences \> Paste & Duplicate \> Keep stroke and colors chosen, FontLab activates the Element tool and selects the pasted artwork.