## Metadata_Start 
## code: en
## title: Right-click to remove kerning pair 
## slug: rightclick-to-remove-kerning-pair-1 
## seoTitle: Right-click to remove kerning pair 
## description:  
## contentType: Markdown 
## Metadata_End

In Kerning mode of the Glyph window, while you are changing a kerning pair by dragging either the kerning handle (with View \> Show \> Spacing Controls on) or the 2nd glyph, you can now remove the kerning pair by also clicking the right mouse button, while already holding the left mouse button (like in Fontlab Studio 5).