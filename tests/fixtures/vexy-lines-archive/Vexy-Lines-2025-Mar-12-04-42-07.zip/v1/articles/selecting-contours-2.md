## Metadata_Start 
## code: en
## title: Selecting Contours 
## slug: selecting-contours-2 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

Select [contours](Contours) with the [[Contour tool]] ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-cont_icon.png)

To select **part** of a contour, see [[Selecting Segments]].

**To select the whole contour**, double-click the contour or ++Alt++-click white space near the contour. Use ++Shift++ while clicking further, to add to the selection or remove from it.

**To select contours belonging to different [elements](Elements)**, turn on ==Edit > Edit Across Elements==.

**To select contours belonging to different glyphs**, turn on ==Edit > Edit Across Glyphs== in addition to ==Edit > Edit Across Elements==.

Use the ==Edit > Invert Selection== (++Cmd+I++) operation to deselect the selected contours (nodes) and select the rest. This command works only within the current element in the current glyph.

Once selected, you can [move](Moving-Contour-Selections), copy/paste, delete or [transform](index#transformations) selected contours.
