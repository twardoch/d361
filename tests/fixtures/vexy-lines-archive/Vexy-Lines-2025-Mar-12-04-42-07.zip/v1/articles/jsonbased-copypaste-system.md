## Metadata_Start 
## code: en
## title: JSON-based copy-paste system 
## slug: jsonbased-copypaste-system 
## seoTitle: JSON-based copy-paste system 
## description:  
## contentType: Markdown 
## Metadata_End

If you’re a technical font developer, you’ll be glad to know that when you copy glyph cells in the Font window, anything in the Glyph window, pairs in the Kerning panel, classes in the Classes panel or use the new Copy buttons in Font Info, FontLab 7 copies the data into the clipboard in a human-readable JSON format, which uses the same data structures as our VFJ file format.

[![][fl7-prefs-copy-json]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-prefs-copy-json.png)

Preference to copy FontLab JSON as plain text

If you turn on Preferences \> Editing \> Copy FontLab JSON data as plain text, FontLab will also copy the data in the JSON format as plain text, so you can paste it into a plain-text editor such as TextEdit, Notepad, Sublime Text or Atom, edit the information outside, use search-replace or some scripts, and paste the data back into FontLab.

[![][fl7-gw-copy-json]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-gw-copy-json.png)

FontLab uses human-readable JSON for copy-paste

| :----- |
| FontLab’s clipboard JSON format uses a special key "dataType" that tells the app what the JSON data is. For example, if the JSON data includes "dataType":"com.fontlab.classes", FontLab knows that the clipboard contents holds a classes definitions. The Source panel also uses the updated JSON format. |

[fl7-prefs-copy-json]: fl7-prefs-copy-json.png width=174px height=48px

[fl7-gw-copy-json]: fl7-gw-copy-json.png width=290px height=182px