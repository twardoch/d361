## Metadata_Start 
## code: en
## title: Associated layers 
## slug: associated-layers 
## seoTitle: Associated layers 
## description:  
## contentType: Markdown 
## Metadata_End

The ==Layers & Masters== panel now supports visual grouping of arbitrary layers.

If a glyph has a layer named, for example, `Regular`, and it has another layer named `Regular.draft` (so it’s the same base name plus a `.` followed by a suffix), the ==Layers & Masters== panel forms a visual group of “associated” layers: it shows the `Regular.draft` as a child layer, indented underneath its parent `Regular` layer, and only shows the `draft` part of the name, prefixed with an arrow icon.

This visual grouping of layers is just a presentational mechanism, and only works one level deep. The layers don’t form any technical parent-child structure. The `Regular.draft` layer is still completely independent of its associated `Regular` parent layer. If you rename the `Regular` layer to something else, FontLab does **not** automatically rename associated layers like `Regular.1` or `mask.Regular`. Those layers will become visually ungrouped (disassociated), will no longer appear nested, and their prefix/suffix will be shown.
