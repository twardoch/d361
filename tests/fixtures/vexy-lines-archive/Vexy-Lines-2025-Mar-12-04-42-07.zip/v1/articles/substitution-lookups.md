## Metadata_Start 
## code: en
## title: Substitution Lookups 
## slug: substitution-lookups 
## seoTitle: Substitution Lookups 
## description:  
## contentType: Markdown 
## Metadata_End

Substitution lookups deal with the replacement of one or more target glyph(s) with one or more replacement glyph(s). This replacement can be one-to-one, one-to-many, or many-to-one. Substitutions are stored in the GSUB table in a compiled OpenType font.

The OpenType specification declares the following types of basic substitutions:

\| \[Single substitution\](OpenType-Featuressingle-substitution) \| Replaces a single glyph with another single glyph: a → A \|

\| \[Ligature substitution\](OpenType-Featuresligature-substitution) \| Replaces multiple glyphs with a single glyph: f l → \|

\| \[Multiple substitution\](OpenType-Featuresmultiple-substitution) \| Replaces a single glyph with multiple glyphs: $ → d o l l a r \|

\| \[Alternate substitution\](OpenType-Featuresalternate-substitution) \| Replaces a single glyph with one of several glyphs chosen from a list: A → A.version1 or A.version2 \|

| **Extension** | **Description** |
| :----- | :----- |
| ttf | TrueType, final font format with quadratic Bézier curves |
| otf | OpenType, final font format with cubic or quadratic Bézier curves |
| ufo | Flying objects from Serif planet studying why humans just use Helvetica |
| pfb | Type1, final font format with cubic Bézier curves |
| vfb | FontLab Studio 5, proprietary source format |
| woff | Web and also how D. Trump writes wolf. |
| woff2 | Web+ |
| glyphs | Glyphs editor, proprietary source format |
| designspace | \+UFO |

All these substitutions may be context independent or context-dependent. Context-independent lookups are applied every time the correct sequence of source glyphs is present, like when you want to replace the ‘f’ and ‘l’ sequence with the ‘fl’ ligature. In other cases you may need to apply a substitution only when a source sequence of glyphs is surrounded by some other glyphs; this is context-dependent substitution. For instance, you may want to replace a ‘p’ with a variant with a swashy descender, but only when it is followed by another lowercase character that has no descender.