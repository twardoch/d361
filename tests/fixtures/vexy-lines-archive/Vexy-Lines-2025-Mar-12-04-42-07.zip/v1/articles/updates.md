## Metadata_Start 
## code: en
## title: Updates 
## slug: updates 
## seoTitle: Updates 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab is updated regularly with bug fixes. It has a mechanism to check for updates, so you can always have the latest version. Learn more about the installation and requirements of the [release version](https://help.fontlab.com/fontlab/7/manual/Installation-and-Requirements/).

Just launching the app should trigger a check for updates, but you can manually do a check in FontLab menu \> Check for Updates.

The FontLab 8 \> About FontLab 8 screen shows the version of the current build. This is a normal version such as 8.2.5600. The last few digits are a **build number**.

<picture> About FontLab 8

If FontLab finds an update, it suggests you download and install it, but you can postpone this operation if you prefer. The update alert dialog also presents the release notes for the new version, usually very useful information about improvements and changes.

When you choose to download, the download link is passed to your default web browser, and the download starts. The file will be downloaded to your browser’s default download location, typically a *Downloads* directory, or your Desktop.

Navigate to your downloads location. Double-click the downloaded file: this will run the FontLab Installer on Windows, or mount the disk image on macOS. The process of the update install is the same as the initial install. The updated app doesn’t need to be activated again; it should work without asking for your serial number.

> After each update, macOS GateKeeper will again alert you that FontLab is an application downloaded from the internet. Just confirm you want to run FontLab. 