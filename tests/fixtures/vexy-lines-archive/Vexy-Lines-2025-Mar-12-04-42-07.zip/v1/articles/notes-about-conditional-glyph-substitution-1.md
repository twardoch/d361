## Metadata_Start 
## code: en
## title: Notes about conditional glyph substitution 
## slug: notes-about-conditional-glyph-substitution-1 
## seoTitle: Notes about conditional glyph substitution 
## description:  
## contentType: Markdown 
## Metadata_End

Conditional glyph substitution in variable fonts works like any other 1:1 OpenType substitution (for example for small caps). In static instances, FontLab reassigns the Unicode codepoint from the input glyph to the output glyph. Both glyphs that participate in conditional glyph substitution remain in your font, and you can use them in other OpenType features. If you want kerning, you need to assign them to kerning classes, and kern them as you wish. FontLab does not to any “magic” here.

You can only specify conditional glyph substitutions where one glyph is replaced by another glyph. To use ligature substitutions, you need to manually write the conditions into the GSUB table using the TTX notation in the Tables panel.

Conditional substitutions only work when the input glyph has a Unicode codepoint. This is because with variable OpenType fonts, text layout apps execute the rvrn feature at the beginning of the OpenType processing, immediately after Unicode codepoints are converted to the default glyphs. So you cannot, for example, substitute an oldstyle nine.onum by nine.onum.rvrn if nine.onum is the result of a substitution in the onum feature. With static fonts, FontLab also only remaps glyphs with Unicode codepoints, so the behavior is consistent.

There is a way to work around this limitation: create a conditional glyph nine.rvrn that is identical to nine and is substituted when the conditions are met. Then in onum, substitute nine with nine.onum that has one shape, and nine.rvrn with nine.rvrn.onum that has another. This is similar to the popular technique for Turkish ligatures, where you create i.loclTRK as an identical duplicate of i, substitute it in the locl feature for Turkish, and then, in the liga feature, only form ligatures with i but not with i.loclTRK.

Only those glyphs that have the tilde tags will be substituted — not the composite glyphs that use them. If you want to use an alternate “a” above weight 650, and you also want to use the same alternate shapes for “àáâä” etc., you can do two things:

* Create a full set of target composites, the same as you’d do for a stylistic set. Use the same suffix (such as .rvrn or perhaps something like .ss05 if you also want to make these alternates explicitly available in a stylistic set. Then create a tag \~wt\>650 in the Classes panel, and drag all the .rvrn glyphs to it. This will assign the tilde tag to each of those glyphs. If the glyph name portion before the suffix matches the full glyph name of another glyph, the glyph with the suffix will replace the glyph without the suffix when the conditions are fulfilled.
* Alternatively, only create one alternate glyph with the base letter (such as a.rvrn) and assign the tilde tag to it. Then, use anchors so that FontLab generates mark attachment. Caution: if you wish to export a variable font with mark attachment, you need to duplicate the default Variable TT or Variable PS export profile, and in the customized profile, turn on Features and Kerning \> OpenType mark attachment \> Always create \[mark/mkmk\] code. You need matching anchors in all masters, otherwise the export of the variable font may fail.

If you assign the tilde tag \~wt\>650 to a.rvrn, the a glyph will be replaced by a.rvrn when the weight is 650 or more. But you can assign multiple tilde tags to the target glyph:

* To specify different source glyphs, enter the source glyph name before the tilde. So if you assign the tilde tags \~wt\>650, b\~wt\>650, c\~wt\>650 to a.rvrn, then a, b and c will be replaced by a.rvrn when weight is 650 or more.
* To specify alternate conditions, assign multiple tags. For example, in a two-axis font, assign the tags \~wt\>650 and \~wt\>600&wd\>110 to a.rvrn, and a will be replaced with a.rvrn when weight is 600 or more and width is 100 or more, or when weight is 650 or more regardless of width. The conditions are processed from the most specific to the most general one. It’s not possible to create “diagonal” conditions, but by combining more and less specific conditions, so you can create “staircase” patterns of conditions.