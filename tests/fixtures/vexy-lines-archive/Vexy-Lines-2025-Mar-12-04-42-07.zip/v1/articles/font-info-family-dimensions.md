## Metadata_Start 
## code: en
## title: Font Info > Family Dimensions 
## slug: font-info-family-dimensions 
## seoTitle: Font Info > Family Dimensions 
## description:  
## contentType: Markdown 
## Metadata_End

**Font Info \> Family Dimensions**

In the Family Dimensions section of Font Info you can edit those font metrics that must be identical in all fonts of the same font family:

Units Per em is the number of font units that defines the font height and the coordinate grid on which the glyphs are drawn. To modify the UPM, press the Change button, which will bring up a dialog where you can enter the new UPM value. Choose Scale glyphs and metrics to the new UPM value option and all the font data will be scaled automatically.

Enter the position of the font’s ascender line in the Ascender field. 

Enter the position of the font’s descender line in the Descender field.

In the Line Gap field, enter the line gap value, i.e. the distance between bottom line of the upper line of text and top line of the lower line of text.

In the Safe Top field, define the topmost line of all non-exceptional characters in the font. 

In the Safe Bottom field, define the lowermost line of all non-exceptional characters in the font. 

Enter the topmost position of all characters in the font in the BBox top field.

Enter the lowest position of all characters in the font in the BBox bottom field.

You can use the Copy dimensions and Paste dimensions buttons on the bottom-right of the dialog to copy/paste all the family dimensions from another font.