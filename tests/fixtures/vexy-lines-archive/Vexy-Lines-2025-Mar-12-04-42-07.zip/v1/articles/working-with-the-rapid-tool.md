## Metadata_Start 
## code: en
## title: Working With the Rapid Tool 
## slug: working-with-the-rapid-tool 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

#### \#\# Working With the Rapid Tool

The Rapid tool has a simple point-and-click interface. 

The tool tries to find the smoothest curve possible between two smooth nodes, producing quadratic Bézier curves with a special interface.

On tool change, or once another element is created, the outline is converted to cubic Bézier curves.