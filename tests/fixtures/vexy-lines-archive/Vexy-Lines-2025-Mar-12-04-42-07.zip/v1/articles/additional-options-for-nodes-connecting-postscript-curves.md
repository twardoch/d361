## Metadata_Start 
## code: en
## title: Additional options for nodes connecting Postscript curves 
## slug: additional-options-for-nodes-connecting-postscript-curves 
## seoTitle: Additional options for nodes connecting Postscript curves 
## description:  
## contentType: Markdown 
## Metadata_End

If you are moving a node that is connecting two PostScript (Bézier) curves you have the following additional options:

*If the connection is smooth*

To constrain movement to a line between the node’s control points, while leaving the handles in place, press and hold the Alt key while moving the point. The node moves, but the handles do not:

![][contour_tool_04]

To move the node such that the connection’s curvature is unchanged as much as possible, press and hold the Alt and Cmd keys while dragging the node. All four control points will be involved in the process:

![][contour_tool_08]

To slide a node along a curve, press the Alt and Shift keys while dragging it. The node’s own handles and the two adjacent handles will be recalculated to maintain the current shape of the curve, as much as possible:

![][contour_tool_06]

*If the connection is sharp*

To move a node without moving its handles or control points, press and hold the Alt key when you drag it. The node will move, leaving its handles and control points at their original positions:

![][contour_tool_05]

[contour_tool_04]: contour_tool_04.png width=119px height=80px

[contour_tool_08]: contour_tool_08.png width=119px height=80px

[contour_tool_06]: contour_tool_06.png width=114px height=80px

[contour_tool_05]: contour_tool_05.png width=108px height=50px