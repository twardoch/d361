## Metadata_Start 
## code: en
## title: Editing a composite glyph layer 
## slug: editing-a-composite-glyph-layer 
## seoTitle: Editing a composite glyph layer 
## description:  
## contentType: Markdown 
## Metadata_End

A composite glyph layer is manually editable. You can add, remove and manually position each element, and you can apply other \[geometric transformations\](Geometric-transformationselement-level-transformation) to it.

In a composite glyph, constituent elements can also be \[references\](Detecting-Element-References). If you try to edit an element reference, depending on whether it is locked or not, either its original (or primary) version will open for editing or you’ll be able to edit it in place. Remember that in both cases, the changes you make to the element reference will be propagated across the font because it is linked to references in other glyphs.