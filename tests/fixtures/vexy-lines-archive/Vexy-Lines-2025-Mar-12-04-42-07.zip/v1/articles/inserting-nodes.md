## Metadata_Start 
## code: en
## title: Inserting Nodes 
## slug: inserting-nodes 
## seoTitle: Inserting Nodes 
## description:  
## contentType: Markdown 
## Metadata_End

To insert a new node on a segment with the Contour tool:

1\. Position the mouse cursor on the segment where you want to insert the node.

2\. Ctrl+Alt-click where you want the node to be inserted or Shift+Ctrl+Alt-click a segment to add an extremum node to that segment.

You can also use the Knife tool to insert nodes.