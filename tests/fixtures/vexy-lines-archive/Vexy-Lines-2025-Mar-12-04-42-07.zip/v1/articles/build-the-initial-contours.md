## Metadata_Start 
## code: en
## title: Build the initial contours 
## slug: build-the-initial-contours 
## seoTitle: Build the initial contours 
## description:  
## contentType: Markdown 
## Metadata_End

The Autotrace dialog has three sliders that control the building of the initial contours:

* Trace tolerance is the distance from the image edge to the outline. The default 1 follows the image edges closely. Higher values follow the edges more loosely and give more straight lines.
* Curve fit distance is the permitted curve approximation error. 0 gives many nodes, higher values give fewer curve nodes and flatter segments. The default is 2.
* Straighten angle is the permitted line approximation error. 0 gives almost no straight lines, higher values prefer lines over curves. Default is 5.
* In the Trace result is, you can decide what form the initial contours will have: PS contours (PostScript curves and lines), TT contours (TrueType curves and lines) or Lines only.