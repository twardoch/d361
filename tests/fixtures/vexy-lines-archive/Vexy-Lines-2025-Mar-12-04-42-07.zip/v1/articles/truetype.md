## Metadata_Start 
## code: en
## title: TrueType 
## slug: truetype 
## seoTitle: TrueType 
## description:  
## contentType: Markdown 
## Metadata_End

Also known as: Windows PostScript, PC PostScript, PC Type 1

File extension: .pfb + .pfm, with supplementary files .afm, .inf

NOTE: FontLab does not support:

* saving Mac suitcase-based Type 1 fonts (but can open them)
* Type 1 Multiple Master fonts (opening or saving, whether Mac or Windows)
* FontLab can, however, open a VFB or UFO representation of multiple master data

Pros: Works on Windows and Linux. Works on all PostScript output and printing devices. Uses the same curve system (cubic Bézier) as drawing applications such as Illustrator and Freehand, so letterforms are easy to edit when converted to curves. Type 1 hinting is comparatively easy to create and edit.

Cons: Does not work on Mac OS (it has its own distinct Mac-only flavor of Type 1), not cross-platform. Contains two parts, the outline file (.pfb) and the metrics font (.pfm), both of which must be in the same folder. Does not contain class kerning so kerning tables are large. Type 1 hinting does not allow precise control for very small screen sizes. Cannot include more than 256 encoded characters and lacks advanced layout features such as ligatures, making the format unsuitable for multilingual or non-Latin fonts. One family cannot contain more than four styles.