## Metadata_Start 
## code: en
## title: Content Sidebar 
## slug: content-sidebar-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

#### \#\# Content Sidebar

From the static portion of the Property bar, you can open the \[Content Sidebar\](Glyph-Window\#content-sidebar). Through the Content Sidebar, you can access texts from the Text Library, modify the text formatting in the Glyph Window and control previewing OpenType features.

content-sidebar\_16.png