## Metadata_Start 
## code: en
## title: DesignLocation 
## slug: designlocation 
## seoTitle: DesignLocation 
## description:  
## contentType: Markdown 
## Metadata_End

The DesignLocation is a number that corresponds to the location of the axis instance on the axis using the axis location “design coordinates”, that is, the coordinates that you, as the designer, use inside FontLab for defining the location of the masters, or when using the sliders in the Variations panel. The progression of the locations in design coordinates is always constant, and the scale can be anything you want — for example, you can set the Light master to have the design location 0 and the Black master to have the design location 1000, but you can also use numbers that correspond, for example, to the thickness of the vertical stems of the letter “n” in font units.