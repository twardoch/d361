## Metadata_Start 
## code: en
## title: Glyphs format 
## slug: glyphs-format 
## seoTitle: Glyphs format 
## description:  
## contentType: Markdown 
## Metadata_End

TBA.

**.glyphs files**

When you open a .glyphs file, FontLab now handles the \| metric key in a compatible way (“opposite sidebearing”).

Export to the .glyphs format is improved in several areas including export of Unicode codepoints assigned to glyphs.

Glyphs (.glyphs)

Glyphs format is the proprietary format of Glyphs 2. FontLab can import fonts in Glyphs format.