## Metadata_Start 
## code: en
## title: Activating components in Glyph window 
## slug: activating-components-in-glyph-window-1 
## seoTitle: Activating components in Glyph window 
## description:  
## contentType: Markdown 
## Metadata_End

**Activating components in Glyph window.**

When you navigate to a composite glyph in the Glyph window, you can now use PgUp/PgDn (Fn+↑/Fn+↓ on the Mac) to activate the components and walk through them.