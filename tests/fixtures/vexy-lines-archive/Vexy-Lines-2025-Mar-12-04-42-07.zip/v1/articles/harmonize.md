## Metadata_Start 
## code: en
## title: Harmonize 
## slug: harmonize 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

**Harmonize** (which can be found in ==Contour > Harmonize==) can be used to make PostScript curves ultra-smooth, or mathematically speaking, G2 curvature continuous. This means that not only will the angle (direction) of the handles on both sides of any node be the same, but also the curvature. 

The **curvature** of a node can be visualized via ==View > Show > Curvature==. This will display a “curvature comb” that shows the speed at which the shape of the curve progresses at each point. You can tell that a node has G2 continuity if the height of the curvature comb on either side of the node is the same.

When you run Harmonize on one or more selected nodes, each selected node is repositioned between its handles so that it now has G2 continuity. But since this is a one-time operation, if the handles of these nodes are moved afterwards, the nodes won’t reposition automatically to achieve G2 continuity again.

Ultra-smoothness can be made permanent by making a node a [Genius](Points#genius-node), which adjusts position to retain its smoothness even when the handles are moved. “Genius” is as if you selected Harmonize again after every movement of the handles/node.
