## Metadata_Start 
## code: en
## title: Release Notes Current 
## slug: release-notes-current 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

# Release Notes Current {: .uk-h5 }

In the release notes, we describe changes from earlier versions. ${beta} indicates changes from the last beta version. ${new} indicates changes from the last stable version.

[View 7.2.0.7644 Release Notes](Release-Notes-7644){.uk-button .uk-button-primary}
{.uk-text-center}

!!! note
> Also see [[Release Notes]] for the [latest beta versions](Release-Notes-Beta) and the [previous versions](Release-Notes-Archive). [Download older](https://download.fontlab.com/) versions of FontLab if needed.
