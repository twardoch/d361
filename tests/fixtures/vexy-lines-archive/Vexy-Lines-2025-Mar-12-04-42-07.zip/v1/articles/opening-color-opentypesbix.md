## Metadata_Start 
## code: en
## title: Opening color OpenType+sbix 
## slug: opening-color-opentypesbix 
## seoTitle: Opening color OpenType+sbix 
## description:  
## contentType: Markdown 
## Metadata_End

![Image](https://i.fontlab.com/fl8/rn/fl8-rn9-apple-SBIX.png){ .plain data-scale='50%' }

You can open OpenType+sbix fonts that contain embedded images in the `emjc` flavor that uses LZFSE compression. One such font is the Apple Color Emoji font bundled with iOS. 
