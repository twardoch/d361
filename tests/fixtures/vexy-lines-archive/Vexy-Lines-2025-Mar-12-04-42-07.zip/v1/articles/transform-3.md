## Metadata_Start 
## code: en
## title: Transform 
## slug: transform-3 
## seoTitle: Transform 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:transform-->
The **TRANSFORM** section lets you precisely move, resize, and rotate your selected objects with numerical control.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28655%29.png){height="" width="300"}

To access these options, click the "Expand" button.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28664%29.png){height="" width="300"}

### Reference Point
<!--qh:center-->
Use this control to set a point on the bounding box of your selected objects. All transformations will happen relative to this point, and its coordinates will be shown in the corresponding input fields.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28656%29.png){height="" width="300"}

### Positioning
<!--qh:transformXY-->
These fields display the coordinates of your selected objects, determined by the currently set reference point. You can directly enter new values to reposition your objects.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28657%29.png){height="" width="300"}

<!--qh:transformOffset-->
When relative positioning mode is active, the values you enter will be added to or subtracted from the current coordinates, shifting your objects accordingly.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28658%29.png){height="" width="300"}

### Size
<!--qh:transformWH-->
The width and height fields control the dimensions of your selected objects. Any changes will be applied relative to the chosen reference point.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28659%29.png){height="" width="300"}

<!--qh:transformLink-->
The **Link** button maintains proportional scaling. When enabled, changing either width or height will automatically adjust the other dimension to preserve the original aspect ratio.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28660%29.png){height="" width="300"}

### Rotation
<!--qh:transformAngle-->
The **Rotate** field lets you turn your selected objects around the specified reference point by entering an angle in degrees.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28661%29.png){height="" width="300"}

### Flip
<!--qh:flip-->
These buttons let you mirror your objects horizontally or vertically with a single click.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28663%29.png){height="" width="300"}

