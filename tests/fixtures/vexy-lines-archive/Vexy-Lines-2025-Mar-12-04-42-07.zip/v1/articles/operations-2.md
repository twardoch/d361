## Metadata_Start 
## code: en
## title: Operations 
## slug: operations-2 
## seoTitle: Operations 
## description:  
## contentType: Markdown 
## Metadata_End

![][operations-r]

Operations are a number of different commands from Font, =Glyph and Element menus:

[operations-r]: operations-r.jpg width=362px height=299px