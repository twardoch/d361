## Metadata_Start 
## code: en
## title: Positional features 
## slug: positional-features-1 
## seoTitle: Positional features 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 7.2 now lists the positional features (init, medi and fina) in the Features panel + menu, so you can easily add them. FontLab can also auto-generate the feature code for those features if your font uses one of the standard naming schemes for the glyphs. If you’re building these features for Arabic, you’ll need to make a small manual correction to the auto-generated code.

If you add one of the three positional features in the Features panel and click the star in the panel’s top bar, FontLab will build the FEA code like so:

feature init \{

\# Initial Forms

\#\> feature

sub uni0626 by uni0626.init;

sub uni0628 by uni0628.init;

\# ... (omitted)

sub uni076D by uni076D.init;

\#\< feature

\} init;

For the Arabic script, you need to add a bit of code before the \#\> feature line. If your font supports additional languagesystems, also add simple code after \#\< feature line. Ultimately, your code should look like this:

feature init \{

\# Initial Forms

script arab; \# Register the features for the Arabic script only

lookup init\_arab \{ \# Create a named lookup

lookupflag IgnoreMarks RightToLeft; \# Supply the lookup flags

\#\> feature

sub uni0626 by uni0626.init;

sub uni0628 by uni0628.init;

\# ... (omitted)

sub uni076D by uni076D.init;

\#\< feature

\} Init\_arab;

language URD ; \# Add this if you have an Urdu-specific locl feature

language FAR ; \# Add this if you have a Persian-specific locl feature

\} init;

With the code above, FontLab will still be able to update the FEA code between the special lines.

To add *isol*, create an empty feature and name it accordingly. Currently, FontLab does not auto-generate isol.