## Metadata_Start 
## code: en
## title: Additional selection for tags 
## slug: additional-selection-for-tags 
## seoTitle: Additional selection for tags 
## description:  
## contentType: Markdown 
## Metadata_End

A glyph can have several tags. In those cases, the select command from the context menu may be not so useful if you want to only select glyphs with a given tag. A better alternative is to use the Classes panel, which also offers a select command:

![][selectfromclasses-r]

1\.	Select Tags in the drop down menu.

2\.	Choose the desired tag from the list at left.

3\.	Hit the select button (⬚) in the footer. In the Font Window, all the glyphs with the tag are select.

[selectfromclasses-r]: selectfromclasses-r.jpg width=280px height=161px