## Metadata_Start 
## code: en
## title: Working with instances 
## slug: working-with-instances 
## seoTitle: Working with instances 
## description:  
## contentType: Markdown 
## Metadata_End

An instance is a “snapshot” of the interpolation process at a chosen location within the design space. In FontLab, you can have two types of instances: predefined or virtual. A predefined instance is a location in the design space, defined by one coordinate per axis. It is not a real font, but a “plan” to create a real font. When you export a variable OpenType font, predefined instances are stored in the font as “named design space locations”. However, to the end-user, choosing a predefined instance of a variable font (in apps that support variable fonts, such as Adobe Illustrator CC 2018, Adobe Photoshop CC 2018, Apple Keynote or Apple Pages) feels very similar to choosing different styles in an extended font family. A dynamic instance is not a real instance, instead you can use it to see how glyphs look at any particular position in the design space.