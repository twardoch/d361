## Metadata_Start 
## code: en
## title: APPLICABLE LAWS 
## slug: applicable-laws 
## seoTitle: APPLICABLE LAWS 
## description:  
## contentType: Markdown 
## Metadata_End

This agreement is governed by the laws of the State of Washington of the United States, including patent and copyright laws.

In the event of a dispute related to this Agreement, the parties shall first attempt settlement of such dispute using International Chamber of Commerce amicable dispute resolution (ADR) procedures.

If the dispute has not been settled within 45 days after the first request for ADR or within such other period as the parties may both agree in writing, such dispute shall be finally settled under the International Chamber of Commerce Rules of Arbitration. The parties shall each propose a resolution, and the arbitrator shall choose the most equitable of the proposals.