## Metadata_Start 
## code: en
## title: Close 
## slug: close 
## seoTitle: Close 
## description:  
## contentType: Markdown 
## Metadata_End

**Vexy Lines**'s **Close** option is a useful feature that ensures users do not lose any unsaved changes in their document. When attempting to close a document with unsaved changes, the program prompts the user to save the changes before closing.
By providing this prompt, **Vexy Lines** allows users to have control over their changes and decide whether to save or discard them before closing a document. This helps prevent accidental loss of work and improves productivity. To quickly access the **Close** option, you can select **File** from the menu and then choose **Close**, or use the shortcut **cmd+W**.