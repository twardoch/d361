## Metadata_Start 
## code: en
## title: HIGHLIGHTS 
## slug: highlights-3 
## seoTitle: HIGHLIGHTS 
## description:  
## contentType: Markdown 
## Metadata_End

120 new or improved features • New Rotate, Scale and Slant tools • Adaptive freeform grid with Suggest distance • Per-font rounded or fractional coordinates • Flexible dynamic instance and 30× faster interpolation • Powerful attached and variable components • Visual proofing and better editing of features • Microsoft VOLT integration • Font window filtering by color flag and glyph name suffix • Better UFO 3 and .glyphs 2 and 3 interchange • 80 fixes

**FontLab 7.2 uses an updated VFC/VFJ file format. If you save/export a VFC or VFJ in FontLab 7.2, you may not be able to open it in an older version of FontLab.**

| :-----: |
| See our [video](http://www.youtube.com/watch?v=bFimb4a6VnE) presenting the new FontLab 7.2. |