## Metadata_Start 
## code: en
## title: Handle 
## slug: handle 
## seoTitle: Handle 
## description:  
## contentType: Markdown 
## Metadata_End

* CLICK handle: select ‣ SHIFT­·CLICK: add to/remove from selection ‣ SHIFT­·ALT­·CLICK handle: retract
* 2×CLICK handle of sharp node: align angle to opposite ‣ SHIFT­·2×CLICK handle: align angle to H/V axis ‣ ALT­·2×CLICK handle of smooth node: slide node to extremum
* DRAG handle(s): move ‣ SHIFT­·DRAG handle: move & keep angle ‣ SHIFT­·DRAG handles: move along H/V axis ‣ ALT­·DRAG handle: move & move opposite handle, of sharp node: align opposite angle, of smooth node: make opposite handle length equal ‣ ←↑↓→: move, SHIFT/\<sup\>M\</sup\>CMD: faster
* BKSP/DEL handle(s): convert curve to line segment