## Metadata_Start 
## code: en
## title: When the Free Transform tool is active 
## slug: when-the-free-transform-tool-is-active 
## seoTitle: When the Free Transform tool is active 
## description:  
## contentType: Markdown 
## Metadata_End

[![][flvi_GW-PropertyBar_free_transform]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/flvi_GW-PropertyBar_free_transform.png)

When the [Free Transform tool](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/Free-Transform-operation/) is active, which can be done by double-clicking the selected contours or by pressing CmdT, the Property bar shows the following buttons and input fields:

1. Shift left and Shift right.
2. Scale up and Scale down. Using this operation, you can scale your selection proportionally or non-proportionally.
3. Rotate left (CCW) and Rotate right (CW).
4. Rotate left (CCW) and Rotate right (CW).
5. Slant left and Slant right.
6. Horizontal flip and Vertical flip

[flvi_GW-PropertyBar_free_transform]: flvi_GW-PropertyBar_free_transform.png width=498px height=25px