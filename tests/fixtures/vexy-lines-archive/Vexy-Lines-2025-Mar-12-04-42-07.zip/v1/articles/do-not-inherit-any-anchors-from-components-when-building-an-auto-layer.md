## Metadata_Start 
## code: en
## title: Do not inherit any anchors from components when building an auto layer 
## slug: do-not-inherit-any-anchors-from-components-when-building-an-auto-layer 
## seoTitle: Do not inherit any anchors from components when building an auto layer 
## description:  
## contentType: Markdown 
## Metadata_End

If you append `#?noanchors` to a recipe, FontLab does not inherit any anchors from the component sources into the auto layer when you export the font.

However, if you decompose the glyph manually, FontLab still inherits the anchors.

For example, if you build the `aacute` glyph with the recipe `=a+acutecomb@top`, then the `aacute` glyph will inherit anchors like `bottom` from `a`. But if you use the recipe `=a+acutecomb@top #?noanchors`, the `aacute` glyph will not have any anchors.

In the recipe syntax, anything that follows `#` is interpreted in a special way:

- a special “task keyword” that immediately follows `#?` performs a particular task; currently, the only supported task keyword is `#?noanchors`
- text that immediately follows `#!` is inserted as a glyph note; this should last in the recipe
- other text that follows `#` is treated as an internal comment and ignored