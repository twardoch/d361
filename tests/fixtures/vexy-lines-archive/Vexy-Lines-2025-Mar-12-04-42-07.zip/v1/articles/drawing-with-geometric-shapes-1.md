## Metadata_Start 
## code: en
## title: Drawing with Geometric Shapes 
## slug: drawing-with-geometric-shapes-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

Sometimes, it can be helpful or faster to draw with basic geometric shapes, and then modify them to achieve the contours you would like. Rectangles/squares and ovals/circles are the basis of many shapes in type design. Note that the contours created by the [Rectangle](Rectangle-tool) and [[Ellipse tool]] will be added to the current [element](Elements). To start drawing in a new element, press ==Esc== or use the ==Glyph > New Element== command before drawing.


## Using the Rectangle tool


**To activate the [[Rectangle tool]]**, select it in the toolbar or press the ++I++ key.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-rectangle_in_toolbar.png)

**To draw a rectangle**, click and drag, and **to create a square**, click and drag while holding down ++Shift++.

Use the ++Ctrl++ key while drawing to make underlying filled areas of existing contours unfilled:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-rect_draw.gif)

Alternatively, click in the position where you want to place the center or the corner of the rectangle and enter the rectangle size in the **Add Rectangle** dialog box:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-drawing_geometric_shapes_01.png)

Choose [filled or unfilled](Contours#contour-direction) rectangle and click ==OK==. 


## Using the Ellipse tool


**To activate the [[Ellipse tool]]**, select it in the toolbar or press the ++O++ key.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-ellipse_in_toolbar.png)

**To draw an ellipse**, click and drag, and **to create a circle**, click and drag while holding down ++Shift++.

Use the ++Ctrl++ key while drawing to make underlying filled areas of existing contours unfilled:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-ellipse_draw.gif)

Alternatively, click in the position where you want to place the center or the “corner” of the ellipse, enter the ellipse size and choose the ellipse form in the **Add Oval** dialog box:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-drawing_geometric_shapes_02.png)

Choose [filled or unfilled](Contours#contour-direction) ellipse and click ==OK==.
