## Metadata_Start 
## code: en
## title: Guides tool 
## slug: guides-tool-2 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

The **Guides tool** (++G++ key) is used for creating [pins, anchors](Anchors-and-Pins), element [guidelines](Using-Guidelines), and for measuring distances between different objects in the drawing area.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-guides_in_toolbar.png)

### Creating anchors and pins

**To create an anchor**, select the Guides tool and ++Shift++-click anywhere in the drawing area. A new [anchor](Anchors-and-Pins) will appear. Anchors are represented by a red rhombus. The default name of the new anchor will depend on where you ++Shift++-click in the glyph advance width. Based on location, the anchor will be called “top”, “bottom”, “left”, “right” and “center,” with numbers appended to the name if you add more than one anchor in a particular location.

**To create a pin**, select the Guides tool and ++Alt++-click anywhere in the drawing area. A new [pin](Anchors-and-Pins) will appear. Pins are represented by a blue circle.

### Performing measurements

**To perform a measurement**, select the Guides tool and click and drag the mouse pointer. This will make the Guides tool work like the Meter tool in FontLab Studio 5.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-guides3.gif)

### Creating guidelines

**To create a local/glyph guideline**, select the Guides tool, and drag the mouse pointer from either the vertical or horizontal [[Rulers]]. By default, a glyph guideline will be depicted by a red line that is not attached to the rulers.

**To create a global/font guideline**, select the Guides tool, hold down ++Shift++ and drag the mouse pointer from either the vertical and horizontal [[Rulers]]. By default, a font guideline will be depicted by a dotted purple line attached to the ruler perpendicular to it.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-guides1.gif)

Unlike the glyph and font guidelines, element guidelines are not created from the rulers. **To create a vector element guideline** in the current element, select the Guides tool, hold down ++Alt++ and drag anywhere in the [[Glyph Window]]. By default, an element guideline will be depicted as a blue line (with an arrowhead on one end when selected). Hold ++Shift++ while dragging to maintain the vertical or horizontal direction. Element guidelines belong to elements: moving or deleting the element also moves or removes its guidelines. If the guideline starts in a node, moving that node also moves the guideline.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-guides2.gif)

To remove a guideline, select it with the [Contour](Contour-tool), [Element](Element-tool) or [[Guides tool]] and hit delete.
