## Metadata_Start 
## code: en
## title: Manual text wrap 
## slug: manual-text-wrap 
## seoTitle: Manual text wrap 
## description:  
## contentType: Markdown 
## Metadata_End

If you set ==Text > Wrap== to ==Manual== or you turn off the ==Auto / Manual text wrap== button in the ==Metrics== or ==Text== tool property bar, the Glyph window text without manual line breaks forms one line. The canvas width is infinite.

Type ++Enter++ with ==Text== tool or `\n` in glyphtext to add manual line breaks.
