## Metadata_Start 
## code: en
## title: Make existing glyphs blank 
## slug: make-existing-glyphs-blank-1 
## seoTitle: Make existing glyphs blank 
## description:  
## contentType: Markdown 
## Metadata_End

*Make existing glyphs blank*

**NEW** To make existing glyphs blank, i.e. to remove content (elements, components, contours) from them, select the glyphs in Font window, then choose Tools \> Actions… \> Adjust \> Remove layer content.

* On top of the dialog, choose the glyphs and layers in which FontLab should remove the content.
* Turn on Remove metrics expressions to keep existing metrics expressions
* Turn off the option to also remove existing metrics expressions