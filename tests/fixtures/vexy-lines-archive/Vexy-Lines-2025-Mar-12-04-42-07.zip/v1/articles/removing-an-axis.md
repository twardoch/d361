## Metadata_Start 
## code: en
## title: Removing an axis 
## slug: removing-an-axis 
## seoTitle: Removing an axis 
## description:  
## contentType: Markdown 
## Metadata_End

To remove an axis, select it in the list and click the - button.