## Metadata_Start 
## code: en
## title: Corner skin 
## slug: corner-skin 
## seoTitle: Corner skin 
## description:  
## contentType: Markdown 
## Metadata_End

![corner](https://i.fontlab.com/fl8/rn/fl8-rn5-corner-skin.png){ .plain .r data-scale='50%' }

Apply **corner** skin to a node, and FontLab will attach the skin content to that node. FontLab joins the segments adjacent to the body node with the first and last segment of the skin source’s open contour, and optionally rotates the skin content. Corner skins are most useful when you want to add a serif to a stem.

The corner skin source glyph must have a name that starts with `_corner`. It should contain one open contour. Both the source and body glyphs must contain a layer with the same name.

If you select a **node** in the current glyph, choose ==Element > Add Skin Filter== and pick a glyph prefixed with `_corner`, FontLab inserts the skin source so that its **origin** is on that selected **body** node. The skin source’s origin is the anchor named `origin` in the `_corner` glyph, or the (0, 0) point if the anchor does not exist. Then, FontLab uses the first node, the first segment, the last node, and the last segment of the skin source’s open contour in a special way.

The corner skin property bar has settings for aligning the skin (==Left==, ==Center==, ==Right== and ==No alignment==), and for scaling / flipping the skin horizontally and vertically.

If the skin has **no alignment**, FontLab:

- adjusts the “left side” of the skin: changes the **incoming** segment of the body node so that it joins with the **first** node of the skin source, rather than with the body node
- adjusts the “right side” of the skin: changes the **outgoing** segment of the body node, so that it joins with the **last** node of the skin source

![corner](https://i.fontlab.com/fl8/rn/fl8-rn5-corner-skin-properties.gif){ .plain .r data-scale='100%' }

The contour directions in both the skin source and the body contour should be the same.

If you **flip** the skin horizontally in the skin property bar, FontLab reverses the meaning of first and last node of the skin source: the incoming segment joins with the last node, and the outgoing segment with the first node.

If you **left-align** the corner skin, the left side of the skin becomes “fixed”. This is the default alignment after you add a corner skin. FontLab:

- **joins** the **first** node of the skin source so that the angle of the first handle or line segment matches the angle of the handle or line segment that is **incoming** into the body node
- **rotates** the skin, so that the angle (direction) between the origin and the **last** node of the skin source matches the angle of the handle or line segment that is **outgoing** from the body node

If you **right-align** the corner skin, the right skin side becomes “fixed”: FontLab matches the last node and outgoing segment for joining, and matches the first node with the incoming segment for rotation.

If you **center** the corner skin, FontLab matches rotation and joining equally on both sides.

Use the text fields or their associated sliders in the property bar to change the width and height of the corner skin (scale it horizontally or vertically). Use the flip buttons to flip them. Flipping uses scale, for example horizontal flip is the same as setting the width to –100%.

To modify how corner skin joins with the body on the left side, add an anchor named `left` to the skin source. The angle and distance between that anchor and the origin influence the location of the join. The modify the joining on the right side, add an anchor named `right`.

!!! note

> The skin source glyph may also may have additional closed contours. FontLab rotates them accordingly if you use corner skin alignment.

!!! note

> Corner skins are compatible with [corner components](https://glyphsapp.com/learn/reusing-shapes-corner-components) used [in the `.glyphs` format](https://glyphsapp.com/media/pages/learn/3ec528a11c-1634835554/glyphs-3-handbook.pdf#section.9.3).

