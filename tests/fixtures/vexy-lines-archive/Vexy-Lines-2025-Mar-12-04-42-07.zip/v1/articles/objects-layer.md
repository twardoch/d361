## Metadata_Start 
## code: en
## title: Layer 
## slug: objects-layer 
## seoTitle: Layer 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:layersAdd
Clicking on this button results in the creation of a new **Layer**.
-->
<!--qh:layersAdd-->
A **Layer** in the Vexy Lines graphic editor is similar to a transparent film on which fills are created and edited to form images. Layers provide flexibility and efficiency when working with an image. You can change the order of layers, adjust transparency, modify mask properties, add or remove fills and masks, and group layers together.
<!--qh-->

### Layer Structure
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-WH3OQ82G.png){height="" width="285"}

<!--qh:layersAdd-->
A single layer can contain multiple fills and one mask. In other words, several fills of different types with varying properties can be on one layer and can be constrained by a single mask. If there is no mask, the fills cover the entire document.
<!--qh-->

### Creating a Layer

To create a new layer, use the **Layer -> New -> Layer** menu option.

Alternatively, you can use the button on the Layers panel.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-RDK39GJI.png){height="" width="236"}

<!--qh:layersAdd-->

If there is no currently selected layer, a new layer will be created when adding a new fill. Even if you start drawing a mask or use the [Pencil](/v1/docs/pencil-1) tool without a selected layer, a new layer will be created. In the first case, with the drawn mask, and in the second case, with a new Handmade fill.

> Note that a new layer is always created in the selected group. If no group is selected, it will be created in the root group, in other words, in the document.
<!--qh-->

### Mask

A mask allows you to hide or reveal parts of an image on a layer. 

| Layer: No Mask | Layer: Masked |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-LMLUZ6OB.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-5F6NFOR7.png){height="" width="300"}|

The layer has a Mask Overlay property. When enabled, the mask becomes solid and opaque for layers positioned below the current layer.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-O42L4F32.png){height="" width="239"}

| Layer: Top, Overlay: On | Layer: Bottom | Top + Bottom |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-0C28BCY6.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-TZQG4MHQ.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-HO15ZB3H.png){height="" width="300"}|

Layers can be organized into groups. It's beneficial to structure the document as a set of thematic groups with meaningful names.
> Learn more about groups in the [Group](/v1/docs/group-1) article.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-QI7LYWSB.png){height="" width="285"}

### Mesh

In Vexy Lines, the Mesh mode provides an advanced level of flexibility and creativity by allowing users to manipulate the fills of a Layer using a grid-based system. This feature is particularly useful for artists and designers who want to achieve unique effects and transformations without altering the original structure of the Layer.

The following predefined mesh shapes are available for use:

![mesh-rect.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mesh-rect.svg) Rectangle
![mesh-donut.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mesh-donut.svg) Donut
![mesh-rising-wave.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mesh-rising-wave.svg) Rising wave
![mesh-falling-wave.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mesh-falling-wave.svg) Falling wave
![mesh-rising-ribbon.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mesh-rising-ribbon.svg) Rising ribbon
![mesh-falling-ribbon.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mesh-falling-ribbon.svg) Falling ribbon

Each of these shapes can be customised to match your specific design goals.

#### Activating Mesh Mode:

1. Select the layer you want to work with.
2. In the toolbar of the Layers Panel, click on the **Mesh** button.![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-PM5NWXZY.png){height="" width="218"}
3. Choose one of the available predefined mesh shapes.
4. Once selected, the **Mesh** mode will be activated for the selected layer. In the Layer row, a property is available to toggle the mesh on or off. 
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-JER9NHUO.png){height="" width="218"}

#### Working with Mesh:

1. **Manipulate the Grid**: With the Mesh grid visible, you can click and drag the grid points to transform the fills within the Layer. This allows for intricate and detailed adjustments to achieve the desired effect.
2. **Add or Remove Grid Points**: Depending on your design needs, you can add additional grid points for more detailed transformations or remove existing points for broader adjustments.

> For a more in-depth exploration of the Mesh tool and its capabilities, refer to the dedicated article on [Mesh](/v1/docs/mesh-3).

$~~~$

### Removing the Mesh

In **Vexy Lines**, while the **Mesh** mode provides advanced transformation capabilities, there might be situations where you'd want to revert to the standard Layer mode. Here's how to easily remove the **Mesh** mode and return to the regular Layer structure:

1. Ensure that the Layer currently in **Mesh** mode is selected.
2. Navigate to the menu: **Layer -> Mesh -> Remove**.
3. Alternatively, click on the **Mesh** icon in the Layer row within the **Layers Panel**.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-U4CIIXOL.png){height="" width="215"}


This will remove the **Mesh** mode and restore the layer to its standard state. 

To re-enable the **Mesh** mode, simply click on the **Mesh** icon again.
   
