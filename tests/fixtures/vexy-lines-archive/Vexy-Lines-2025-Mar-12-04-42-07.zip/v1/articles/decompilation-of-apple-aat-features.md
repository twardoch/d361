## Metadata_Start 
## code: en
## title: Decompilation of Apple AAT features 
## slug: decompilation-of-apple-aat-features 
## seoTitle: Decompilation of Apple AAT features 
## description:  
## contentType: Markdown 
## Metadata_End

If you open an OpenType font that contains Apple AAT layout features in the `morx` or `mort` table, FontLab now converts these features into OpenType Layout people, and decompiles them into the FEA notation in the ==Features== panel.

!!! note

> This functionality is somewhat limited. Not all `morx` features can be expressed in OpenType Layout. Also, FontLab does not export AAT features.