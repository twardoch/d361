## Metadata_Start 
## code: en
## title: Standard,nam mapping 
## slug: standardnam-mapping 
## seoTitle: Standard,nam mapping 
## description:  
## contentType: Markdown 
## Metadata_End

The built-in standard.nam mapping file that provides Friendly, Alternative and Synonym glyph names is now at version 4.3.1, with 53,102 entries. See the release notes to details about changes of standard.nam.

**TBA: code sample.**