## Metadata_Start 
## code: en
## title: Class glyphs behind exception glyphs 
## slug: class-glyphs-behind-exception-glyphs 
## seoTitle: Class glyphs behind exception glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

☆ FontLab will now no longer show class glyphs behind an exception glyph if you have View \> Kerning Classes on.

So if you’ve created a \_T ydieresis class:glyph exception with Alt, and you have the Tÿ text in Kerning mode (so T is a class glyph and ydieresis is the exception glyph), then the \_T class glyphs will still appear behind T, but the \_y class glyphs will no longer appear behind ÿ. Previously, the contents of a kerning class was shown behind any glyph that belonged to a class, regardless of whether the glyph was part of a class pair or an exception pair.