## Metadata_Start 
## code: en
## title: Navigating a Font 
## slug: navigating-a-font-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

<!--- Process -->

The [[Font Window]] shows all glyphs of the opened font in _glyph cells_. Each glyph cell has a caption which can be located above or below the cell, and shows identification information – either the name of the glyph, its Unicode, index or other character information:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-the_font_window_04.png)

The glyph cells may have different colors. But by default, the background of the glyph cell will be grey or white, and the caption will be grey or yellow. You can change the default white background color in Preferences. This might be useful when working on a color font with “white” glyphs. Additional colors may appear if you used color flags to color-mark the glyph cells. 

### Background colors

A **grey cell** background means an **empty glyph cell**. This means that the glyph does not exist in the font, and the glyph cell is displaying a glyph placeholder: a template image with a drop shadow. The default glyph template images should not be used as a direct source of information about the typographically correct shape of glyphs. They are merely a reminder of what the expected character is for that glyph. You can change the font used for the placeholder in Preferences > Font Window.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-the_font_window_06.png)

A **white cell** background means that a glyph exists in the font. If the glyph cell background is white, it is called a **blank glyph**. A blank glyph exists in the font, but does not contain any outlines or components.

### Caption colors

A **yellow caption** for a glyph cell means that the glyph is part of the currently selected set of glyphs. Glyphs that are not part of the current glyphset (filtered) have a **grey caption** instead.


## Navigating


One of the glyphs in the Font window is always the “current” glyph. It is selected (although there may be other selected glyphs), and is specially highlighted:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-using_the_font_window_01.png)

You can see the current glyph name and its Unicode codepoint in the footer:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-using_the_font_window_02.png)

**To view different parts of the font** in the Font window, you can either use the vertical scroll bar, or the auto-scroll mode: press the mouse button while the cursor is very near the bottom, or move the mouse cursor above the top or bottom of the chart, and it will scroll up or down while selecting additional glyphs.


## Selecting Cells


In addition to the current glyph, you can select sets of glyphs in the font chart. These selections behave similarly to selected text in a text editor – you can copy selected glyphs to another place in the font or to a different font; you can apply different effects to the selection; open them for editing, etc. Selected glyphs have inverted colors. One of the selected glyphs is the “current” glyph:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-using_the_font_window_03.png)

**To select one or more cells**, press the mouse button on the first or last cell of your selection and drag the cursor across the cells you want to select. You will see the selection highlighted. If you drag the cursor outside the visible part of the chart, it will scroll accordingly.

**To cancel your selection**, click any glyph cell. Selection does not have to be continuous; if you press the ++Cmd++ key, you can select and deselect cells in any order and combination.

Double-click to open selected glyphs for editing. See [Drawing and Editing Glyphs](index#drawing-and-editing-glyphs) section.
