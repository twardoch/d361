## Metadata_Start 
## code: en
## title: Vertical Metrics 
## slug: vertical-metrics 
## seoTitle: Vertical Metrics 
## description:  
## contentType: Markdown 
## Metadata_End

TBA