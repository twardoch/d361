## Metadata_Start 
## code: en
## title: Comparing Glyph Sets 
## slug: comparing-glyph-sets 
## seoTitle: Comparing Glyph Sets 
## description:  
## contentType: Markdown 
## Metadata_End

To compare font glyph sets, select two or more fonts in the Fonts panel and choose the Font \> Compare Fonts menu command. The dialog with comparing results will appear:

![][comparedialog-r]

Compare fonts dialog

To add missing glyphs to the current font, make sure the corresponding option is turned on and click OK. Use the Flag new glyphs option to mark created glyph cells with color tag. As a result you should get the same number of glyphs in both compared fonts. New added glyph cells will be colored by the selected color.

| :----- |
| The Compare Fonts command not only adds empty glyph cells, but also attempts to generate the glyphs that are being created. For example, if your font includes the basic Latin letters and some diacritic marks, and some accented Latin glyphs are added, they will be automatically generated with the appropriate Elements placed into the glyphs. You can switch this feature off in Preferences \> Operations \> New glyphs |

[comparedialog-r]: comparedialog-r.jpg width=361px height=150px