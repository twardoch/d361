## Metadata_Start 
## code: en
## title: Glyphs 
## slug: glyphs-1 
## seoTitle: Glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

Open the first glyph of your font in a Glyph Window, enable View \> Show \> FontAudit and walk through all your glyphs. Review and fix potential problems reported by FontAudit.