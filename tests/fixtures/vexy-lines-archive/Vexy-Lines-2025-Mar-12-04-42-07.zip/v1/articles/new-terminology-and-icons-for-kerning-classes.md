## Metadata_Start 
## code: en
## title: New terminology and icons for kerning classes 
## slug: new-terminology-and-icons-for-kerning-classes 
## seoTitle: New terminology and icons for kerning classes 
## description:  
## contentType: Markdown 
## Metadata_End

For kerning classes, FontLab now uses the terms ==Left class== and ==Right class== instead of ==1st class== and ==2nd class==.

A **left class** is used on the **left side of the kerning pair**, so it groups glyphs that share a similar design structure on their right side.

A **right class** is used on the **right side of the kerning pair**, so it groups glyphs that have their left side similar design-wise.

This change is necessary to properly support kerning in right-to-left (RTL) scripts like Arabic and Hebrew.

~~![Left Right Kerning Icons](https://i.fontlab.com/fl8/rn/fl8-rn-left-right-kerning-icons.png){ .plain .r title="Left Right Kerning Icons" }~~

The icons for left and right kerning classes are updated. They visualize two glyphs with a kerning pair between them:

- The icon for **left kerning** class has a small glyph drawing on the left side, and the right edge of that drawing has an irregular form.
- The icon for **right kerning** class has a drawing on the right, and its left edge has an irregular form.