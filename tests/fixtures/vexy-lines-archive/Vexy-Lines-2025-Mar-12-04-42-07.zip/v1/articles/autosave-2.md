## Metadata_Start 
## code: en
## title: Autosave 
## slug: autosave-2 
## seoTitle: Autosave 
## description:  
## contentType: Markdown 
## Metadata_End

When Save copy in Autosave folder is on FontLab automatically saves a copy of the open fonts in the Autosave folder in the interval specified in the field (0.2 will autosave every 12 seconds). After a crash, FontLab prompts you to open the autosaved files. When you open them, or when you quit the app, FontLab moves the contents of the autosave folder to the Trash/Recycle Bin. Click the new Reveal button to open the Autosave folder in Finder/File Explorer.