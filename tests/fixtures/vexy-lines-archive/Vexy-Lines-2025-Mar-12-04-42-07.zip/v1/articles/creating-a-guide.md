## Metadata_Start 
## code: en
## title: Creating a guide 
## slug: creating-a-guide 
## seoTitle: Creating a guide 
## description:  
## contentType: Markdown 
## Metadata_End

Before you create guides, be sure that they are visible. Use the View \> Glyph Guides and View \> Font Guides commands to switch them on. 

To add a new glyph or font guide:

1\. Position the mouse cursor on the horizontal ruler for a horizontal guide, or on the vertical ruler for a vertical guide. 

2\. Click the ruler and while holding down the button, drag away from it to create the guide. Release the button when the guide is in the desired place.

If you release the button inside the glyph canvas (the lighter active area in the glyph window), a glyph guide will be created. Otherwise, a font guide will be created. You can reverse this behavior by pressing the Shift key.

To create a new guide from nodes: when you have two nodes selected, choose Tools \> Add Guide to add a glyph guide that goes through those nodes.

To add a new element guide to the current element, use the Guides tool with the Alt key.

**Add Guide**

When you select two points (nodes or handles) in Glyph window, choose Add Guide from context menu to add a glyph guide that goes through both points. Previously, this operation was only available in the Tools menu.