## Metadata_Start 
## code: en
## title: Number of stems and zones 
## slug: number-of-stems-and-zones 
## seoTitle: Number of stems and zones 
## description:  
## contentType: Markdown 
## Metadata_End

the Font Info sections list now shows how many ==Stems== and ==Zones== are defined in the current font master.