## Metadata_Start 
## code: en
## title: Toolbar and dropdown text buttons are easier to click 
## slug: toolbar-and-dropdown-text-buttons-are-easier-to-click 
## seoTitle: Toolbar and dropdown text buttons are easier to click 
## description:  
## contentType: Markdown 
## Metadata_End

You can now activate a Toolbar button or an underscored dropdown text button by clicking the area slightly outside the button, so it’s easier not to miss it.