## Metadata_Start 
## code: en
## title: Single Positioning 
## slug: single-positioning 
## seoTitle: Single Positioning 
## description:  
## contentType: Markdown 
## Metadata_End

A Single Pos rule is specified as:

==

pos \<glyph\|glyphclass\> \<valuerecord\>;

==

Here, the \<glyph\|glyphclass\> is adjusted by the \<valuerecord\>. For example, to reduce the left and right sidebearings of a glyph each by 80 design units:

==

pos one \<-80 0 -160 0\>;

==

To shift the glyph up by 100 units:

==

position A \<0 100 0 -100\>;

==

Note that we changed the placement by 100 units but compensated for that with a -100 change applied to advance. This is needed to shift only the current glyph and not the following glyphs in the string.