## Metadata_Start 
## code: en
## title: Attributes 
## slug: attributes 
## seoTitle: Attributes 
## description:  
## contentType: Markdown 
## Metadata_End

The design attributes of a font or master describe its typographic properties. They are declared by the font vendor. The three important attributes are: \_Weight class\_, \_Width class\_ and \_Slope class\_. There is also \_Other\_ for custom attributes. Apps and operating systems use the design attributes to identify similar or corresponding fonts between font families.

When the text uses a font with a particular weight, width and slope class, and the user inputs a character not covered by the font’s character set, the OS will render the character using a fallback font, and will pick the fallback font that matches the design attributes closely. Also, when the user switches the font family, many apps will use the design attributes to maintain the styling of the text by picking fonts from the new family that closely match the previously used fonts. In addition, FontLab uses the design attributes to automatically build style names.

FontLab uses these values when you export the current layer or the masters. When you export static instances, FontLab ignores the design attributes of the masters and uses design attributes set in Font Info \> Instances. When you export a variable OpenType font, FontLab uses the design attributes of the main master for the default instance of the variable font, and ignores the info in other masters.

Weight class describes the typographic weight (stroke thickness) of a typeface, ranging from Thin to Extra Black, and defaulting to Regular. We recommend to set this attribute to a value which truly reflects the typographic weight of each font. Alternatively, if a family consists of a single font, you may set the Weight attribute to Regular, and if a family consists of just two weights, you may set the Weight attribute to Regular for the lighter weight, and to Bold for the bolder weight. When you choose a weight class from the dropdown, FontLab writes a corresponding numerical value in the next field — from 100 for Thin to 950 for Extra Black. For highest compatibility with apps and OSes, you should create font families with no more than 9 weight classes (100, 200,... up to 900). If your family has more than 9 weights, you can use additional number from the 1–1000 range. FontLab exports this value as OS/w.usWeightClass.

Width class describes the typographic width of a typeface, ranging from Ultra Condensed to Ultra Expanded, and defaulting to Normal for most fonts. You should set this attribute to a value which truly reflects the typographic width of the typeface. FontLab exports this value as OS/w.usWidthClass

Slope class describes whether the font acts as an upright or italic font. Most fonts (including true upright fonts and also script fonts which are cursive) should have a Plain slope. You should set the Slope to Italic only if a font should act as an italic companion to an upright font. Advanced users may set the Slope to Oblique instead of Italic.

Other is your chance to specify some way in which a style of your font differs that is not weight, width or slope. You may use phrases here such as Display or Swash or Simplfied or Caption. FontLab will not export the content of this field into fonts directly, but will append it to the automatically built style names.