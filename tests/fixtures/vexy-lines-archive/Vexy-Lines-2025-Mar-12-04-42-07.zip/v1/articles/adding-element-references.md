## Metadata_Start 
## code: en
## title: Adding element references 
## slug: adding-element-references 
## seoTitle: Adding element references 
## description:  
## contentType: Markdown 
## Metadata_End

When you add or paste an element reference, FontLab now always inserts it as an unlocked element, so you cannot edit its content in-place.

If you turn on ==Preferences > Operations > Element references > Lock all element references except the primary element== and insert an element reference from the ==Gallery== panel or using ==Element > Element Reference > Add Element Reference==, FontLab will insert it as a locked element. To edit the element content in-place, turn off ==Element > Locked==.