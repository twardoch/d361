## Metadata_Start 
## code: en
## title: Save and restore windows, tabs, panels and font filters 
## slug: save-and-restore-windows-tabs-panels-and-font-filters-1 
## seoTitle: Save and restore windows, tabs, panels and font filters 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 6.1.2 saves your entire workspace in the VFC or VFJ file: the contents, sizes and positions of windows and tabs, and now *also* the positions of visible panels. Use Preferences \> Open Fonts \> Restore workspace from VFC/VFJ to decide what should happen when you open a saved file: by default, FontLab will restore the windows and tabs, but you can also decide to restore panel positions.

FontLab 6.1.2 now also saves (to VFC/VFJ) and restores filters and sorting settings for all open Font windows.