## Metadata_Start 
## code: en
## title: Instances 
## slug: instances-1 
## seoTitle: Instances 
## description:  
## contentType: Markdown 
## Metadata_End

If your source font has multiple masters, and your masters are interpolable, you will most likely want to choose Instances as the font content. Exporting the Instances content allows you to quickly generate fonts for an entire font family in one step.

The Instances list shows all predefined instances that you have defined in the \[Font Info dialog box\](Font-Info-Dialog-Boxinstances) File \> Font Info \> Instances. Use the left-side toggles to enable the predefined instances you wish to export (filled toggle), or disable some (unfilled toggle). All enabled instances will be generated via interpolation, and then exported as separate fonts.

Before you invoke File \> Export Font As you can edit your predefined instances in the \[Font Info dialog box\](Font-Info-Dialog-Boxinstances) File \> Font Info \> Instances.