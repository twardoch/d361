## Metadata_Start 
## code: en
## title: A segment is a part of of the [contour](Contours) between two neighboring [nodes 
## slug: a-segment-is-a-part-of-of-the-contourcontours-between-two-neighboring-nodes 
## seoTitle: A segment is a part of of the [contour](Contours) between two neighboring [nodes 
## description:  
## contentType: Markdown 
## Metadata_End

A segment is a part of of the \[contour\](Contours) between two neighboring \[nodes\](Points\#nodes).

Segments between two sharp (corner) nodes are called \_line segments\_.

Segments between sharp and smooth or between two smooth nodes and are called \_curve segments\_.

Curve segments can be of two types: PostScript (PS, cubic Bézier) curves and TrueType (TT, quadratic) curves. A single contour cannot mix different kinds of segments in \[final font formats\](Font-Formats\#final-font-formats)—indeed, it is not acceptable to even have both kinds of outlines in a single font. However, FontLab allows you to do so for design purposes, and can convert at output time.