## Metadata_Start 
## code: en
## title: Glyph Metrics 
## slug: glyph-metrics-5 
## seoTitle: Glyph Metrics 
## description:  
## contentType: Markdown 
## Metadata_End

