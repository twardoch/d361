## Metadata_Start 
## code: en
## title: Design coordinates 
## slug: design-coordinates 
## seoTitle: Design coordinates 
## description:  
## contentType: Markdown 
## Metadata_End

Design coordinates are the coordinates that type designers use internally when they create a font with multiple masters. You can use user coordinates as your design coordinates, but you can also use more meaningful numbers.

[![fl7-variation-model-03.png](fl7-variation-model-03.png)](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-variation-model-03.png)

Insert masters at design coordinates of your choice

For example, many designers use the thickness of the vertical stem in the n glyph in font units as their design coordinates for the Weight axis. This is helpful because you can measure some contours in some glyphs visually, and use those same numbers for axis coordinates. The design coordinates are only used in development font formats — they’re never exported into any end-user fonts.

[![fl7-variation-model-04.png](fl7-variation-model-04.png)](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-variation-model-04.png)

Use the design coordinates to interpolate the desired instances