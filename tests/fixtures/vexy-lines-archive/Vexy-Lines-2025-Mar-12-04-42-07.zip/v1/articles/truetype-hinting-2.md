## Metadata_Start 
## code: en
## title: TrueType Hinting 
## slug: truetype-hinting-2 
## seoTitle: TrueType Hinting 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab now exports TTH commands into UFO in a new format com.fontlab.ttcommands, and correctly reads back the newer format and the older com.fontlab.ttprogram format. See below for details.