## Metadata_Start 
## code: en
## title: Manually linking metrics 
## slug: manually-linking-metrics 
## seoTitle: Manually linking metrics 
## description:  
## contentType: Markdown 
## Metadata_End

To manually link glyph metrics, select the glyph and enter the glyph you want to link to, i.e. key glyphname, in the width, left or right sidebearing field in the Metrics window property bar:

![][linking_metrics_03]

In the image above, after manual linking the glyph D is assigned the same LSB as the B. Now when you change the LSB for B, it will be changed for D as well.

Linking can also be done using expressions (see above).

[linking_metrics_03]: linking_metrics_03.png width=320px height=237px