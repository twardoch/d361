## Metadata_Start 
## code: en
## title: Font Info > Parameters 
## slug: font-info-parameters-1 
## seoTitle: Font Info > Parameters 
## description:  
## contentType: Markdown 
## Metadata_End

**Font Info \> Parameters**

In Font Info › Parameters, you can manage parameters, which are named numeric variables that are used in expressions. Values you can reference in expressions font-wide — parameters, font guidelines and selected variables — are listed in this section. Variables are preceded by three grey dotted horizontal lines; parameters by a calculator; and font guidelines by two horizontal blue dotted line intersected by a vertical one. 

To define a new parameter, click the plus-shaped Add parameter button, name the variable and DRAG the slider to define its value.

To remove an existing parameter, select it in the list and click the minus-shaped Remove parameter button.

To modify the value of a parameter, enter the new value in the input area, use the number steppers or the slider. Note that changing the value of a pre-defined variable will also change your font’s dimensions listed on other pages.