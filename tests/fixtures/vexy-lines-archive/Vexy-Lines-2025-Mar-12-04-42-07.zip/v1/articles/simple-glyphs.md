## Metadata_Start 
## code: en
## title: Simple glyphs 
## slug: simple-glyphs 
## seoTitle: Simple glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

A simple glyph consists of one \[simple element\](Elements) — either a set of contours or an image. If the glyph has a contour element, it has a simple black fill, no stroke, no \[element-level transformation\](Geometric-transformationselement-level-transformation) and is not referenced anywhere else in the font. Such a glyph can be created using FontLab’s vector drawing tools, and will be natively exported into common font formats. If the simple glyph is made up of an image, it will be exported into bitmap-based color font formats. In either case, a simple glyph can contain anchors as well as other objects, which are not included in the common exported font formats, such as glyph guides and stickers.