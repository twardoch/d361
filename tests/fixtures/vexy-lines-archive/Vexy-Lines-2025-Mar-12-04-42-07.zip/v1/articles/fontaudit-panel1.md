## Metadata_Start 
## code: en
## title: FontAudit panel-1 
## slug: fontaudit-panel1 
## seoTitle: FontAudit panel-1 
## description:  
## contentType: Markdown 
## Metadata_End

**FontAudit panel**

The FontAudit panel lists the FontAudit problems for the current glyph and layer. The list shows the name of the problem, the x,y coordinate the problem exists, and has a Fix button that tries to fix the problem. 

Turn on View › Show › FontAudit (\<sup\>M\</sup\>SHIFT­·CMD­·F \<sup\>W\</sup\>SHIFT­·CTRL­·F) to visualize the problems in the Glyph window using colorful FontAudit markers. CLICK in the list to highlight the problem marker in the Glyph window.

To see a description of the problem, hold F1 over a problem in the panel list, or click a problem marker in the window (which opens a FontAudit problem popup).

To try to fix an individual FontAudit problem, click the Fix button in the popup at the right side of the list entry. Fixing may not be successful and may produce other problems.

To try to fix all the FontAudit problems in the current glyph layer, click Fix All in the popup or in the panel footer.

To change which tests are run by FontAudit, use the panel gear-button or Preferences › FontAudit.