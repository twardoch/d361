## Metadata_Start 
## code: en
## title: Curve Types 
## slug: curve-types-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

<!--- Reference -->

Curves are of two types: PostScript curves segment or TrueType curve segments. In FontLab, you can [convert between the two types](Outline-Conversion).


## PostScript curves


**PostScript curves**, also called Type 1 curves, are Bézier curves (3rd order, cubic B-splines). A PostScript curve is defined by two **nodes** and **control points** (also called **handles**), one coming out of each node. Vectors that connect a node with its handle are called **control vectors**. Each handle is associated with just one node, and one node has at most two handles. 

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-contours_04.png)

If there is a PostScript curve segment with two handles, and you delete one of them, the curve immediately turns into a line.

In the [[Glyph Window]], nodes can have [different appearances](Points#visual-appearance-of-nodes). Straight segments end in sharp nodes displayed as squares, and curves end smooth nodes displayed as circles. A connection between a straight and curve segment is shown as a tangent node displayed as a triangle.


## TrueType curves


**TrueType curves** are 2nd order curves (i.e. quadratic B-splines). They are defined by two **nodes** (or on-curve points) and one **control point** (or off-curve point).
![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-contours_05.png)

Some TrueType curves may appear linked together and form a long curve with off-curve points only. In such curves, the intermediate nodes do not exist explicitly, but are implied by the rasterizer. Each handle is connected to both the points before and after it, whether those are nodes or handles.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-contours_06.png)

Off-curve points of the TrueType curves are light-blue in color mode appearance.
