## Metadata_Start 
## code: en
## title: Export Font As Export single masters or instances as VFCVFJ 
## slug: export-font-as-export-single-masters-or-instances-as-vfcvfj-1 
## seoTitle: Export Font As Export single masters or instances as VFCVFJ 
## description:  
## contentType: Markdown 
## Metadata_End

#### Export Font As: Export single masters or instances as VFC/VFJ

In the File \> Export Font As dialog, the FontLab (.vfc) and FontLab JSON (.vfj) profiles at the top of the list export the entire multiple-master source font as one file. This is equivalent to File \> Save As, i.e. exports your font source losslessly.

The same-named profiles in the lower portion of the list are different: they allow you to export the current layer, all or some predefined instances or each master as separate single-master files. This may be particularly useful if you wish to perform some external processing of those files, or export them to other formats.