## Metadata_Start 
## code: en
## title: Autotrace 
## slug: autotrace 
## seoTitle: Autotrace 
## description:  
## contentType: Markdown 
## Metadata_End

The Autotrace filter traces bitmap images trying to create smooth and quality outlines. It can be customized in \[Preferences \> Operations\](Preferences\#operations). See Autotracing for more details.