## Metadata_Start 
## code: en
## title: Add new elementscomponents to a group 
## slug: add-new-elementscomponents-to-a-group-1 
## seoTitle: Add new elementscomponents to a group 
## description:  
## contentType: Markdown 
## Metadata_End

#### Add new elements/components to a group

Now you can add another element or component to an existing group of elements. To do so, select the group and the additional element/component, then choose Element \> Group (Cmd+G). The new element will be added, preserving the group name. This is particularly important when the element group is referenced by other glyphs because the reference is fully preserved this way.

Previously, you needed to ungroup and then regroup the elements with the extra element included, losing references to the group.