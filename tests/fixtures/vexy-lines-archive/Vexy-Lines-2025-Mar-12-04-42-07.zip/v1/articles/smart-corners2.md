## Metadata_Start 
## code: en
## title: Smart corners-2 
## slug: smart-corners2 
## seoTitle: Smart corners-2 
## description:  
## contentType: Markdown 
## Metadata_End

**Smart corners**

You can now add Smart Corners to one or more selected nodes in the Node panel, and change their radius.