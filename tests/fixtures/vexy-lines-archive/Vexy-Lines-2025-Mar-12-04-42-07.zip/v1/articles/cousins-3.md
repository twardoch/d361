## Metadata_Start 
## code: en
## title: Cousins 
## slug: cousins-3 
## seoTitle: Cousins 
## description:  
## contentType: Markdown 
## Metadata_End

![][cousins-r]

In this section, you can decide whether \[Cousins\](Using-the-Glyph-Windowcousins)\~\~TODO move to Glyphs in Context $$$\~\~ should be rendered filled (with adjustable transparency), or as outlines. 

You can also decide how the Cousins should be placed in relation to the current glyph: aligned to the LSB, RSB or the center, and optionally shifted by a X/Y unit distance. 

With Use metrics, the Cousins will be placed to the left or right of your current glyph, shifted by their advance width (this works best if you only have one glyph in your Glyph window).

[cousins-r]: cousins-r.jpg width=362px height=301px