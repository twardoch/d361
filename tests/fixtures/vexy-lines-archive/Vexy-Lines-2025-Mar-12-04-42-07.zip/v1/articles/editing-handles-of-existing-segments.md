## Metadata_Start 
## code: en
## title: Editing handles of existing segments 
## slug: editing-handles-of-existing-segments 
## seoTitle: Editing handles of existing segments 
## description:  
## contentType: Markdown 
## Metadata_End

If you turn on the ==Pen > Edit handles== sub-tool:

- Click and drag a node to make it a smooth node and set both opposite handles.
- ++Alt++-click and drag a node to set one of its handles.
- Click a smooth node to retract the handles, or to remove the node if there are no handles to retract.

If you draw with the Pen tool, and press ++Cmd+Z++{ .M} ++Ctrl+Z++{ .W} to undo, FontLab removes the last-drawn segment along with the handle. Previously, FontLab left the handle.
