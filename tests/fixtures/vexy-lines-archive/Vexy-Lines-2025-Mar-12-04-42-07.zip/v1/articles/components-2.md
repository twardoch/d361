## Metadata_Start 
## code: en
## title: Components 
## slug: components-2 
## seoTitle: Components 
## description:  
## contentType: Markdown 
## Metadata_End

When you open a UFO or .glyphs font file, or modify components via scripting or the Source panel, a glyph contains a component that points to a glyph that does not exist in the font, or does not contain a corresponding glyph layer. This may be legitimate, as you may want to create component glyphs before the base glyphs exist.

[![][fl712-component-sadface]](file:///Volumes/Igor/Manual/Github/docs/fontlab/7/manual/img/fl712-component-sadface.png)

A “sad face” appears in place of invalid components

If the current glyph layer contains an invalid component, the Glyph window now shows a pale red placeholder. If the component represents a “known” character, FontLab shows the corresponding character from the Preferences \> Font window \> Placeholder font, otherwise it shows a “sad face” graphic.

[fl712-component-sadface]: fl712-component-sadface.png width=306px height=212px