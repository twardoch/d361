## Metadata_Start 
## code: en
## title: Simple stickers 
## slug: simple-stickers-1 
## seoTitle: Simple stickers 
## description:  
## contentType: Markdown 
## Metadata_End

**NEW** FontLab 7.1.4 adds a set of simple stickers: arrow, circle, square, plus (cross), line and star.

* To add a simple sticker in the current glyph layer, choose Element \> New Sticker and choose the sticker type, or hold G to temporarily activate the Guides tool and click the appropriate sticker button on the right side of the Glyph window property bar. The new sticker will have the same size as the last simple sticker of the same type that you scaled. Hold Alt when adding a simple sticker and the new sticker will have the default size (5% UPM).
* Click the sticker outline on the canvas to activate it. Drag the outline or fill of the active sticker to move it. Click – in the Elements panel or tap BkSp to remove the sticker.
* Drag the circular unfilled sticker handle to scale the sticker (change its size) and to rotate it. Shift+drag: scale & rotate by 45°. The scaling will also affect all new stickers of the same type unless you hold Alt when adding them.
* Change the sticker outline color in the last column of Elements panel. For circle, square and star stickers, change the sticker fill color in Color or Swatches panel.