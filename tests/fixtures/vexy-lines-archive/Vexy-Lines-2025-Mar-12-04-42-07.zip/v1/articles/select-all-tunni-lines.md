## Metadata_Start 
## code: en
## title: Select All Tunni Lines 
## slug: select-all-tunni-lines 
## seoTitle: Select All Tunni Lines 
## description:  
## contentType: Markdown 
## Metadata_End

If ==View > Tunni Lines== is turned on, you click a Tunni line and choose ==Edit > Select All==, FontLab now selects all Tunni lines in the current element. Previously, ==Select All== selected the contours even if the Tunni line was active.