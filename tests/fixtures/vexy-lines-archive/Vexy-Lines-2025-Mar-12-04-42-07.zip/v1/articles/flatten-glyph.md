## Metadata_Start 
## code: en
## title: Flatten Glyph 
## slug: flatten-glyph 
## seoTitle: Flatten Glyph 
## description:  
## contentType: Markdown 
## Metadata_End

This action can be used to expand all element transformations and filters, disconnect element references and combine contours to one element for all elements in the current layer. Note that this action does not merge glyph layers, and if there are bitmap images, or SVG elements, or color elements (fill or stroke) in the current layer, then combining to one element is not performed.