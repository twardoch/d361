## Metadata_Start 
## code: en
## title: Optical separation 
## slug: optical-separation 
## seoTitle: Optical separation 
## description:  
## contentType: Markdown 
## Metadata_End

The OCR system used in FontLab can recognize characters of two languages: English and Russian. This is used in Element \> Image \> Separate and Trace when you need to transform a bitmap image to the number of outline glyphs. You can switch one or both languages on; or turn OCR off if needed. More languages can be added later without a special notice.