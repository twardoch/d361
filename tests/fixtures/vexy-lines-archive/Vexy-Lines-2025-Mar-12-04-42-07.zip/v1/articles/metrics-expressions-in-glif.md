## Metadata_Start 
## code: en
## title: Metrics expressions in GLIF 
## slug: metrics-expressions-in-glif 
## seoTitle: Metrics expressions in GLIF 
## description:  
## contentType: Markdown 
## Metadata_End

When you export UFO, FontLab 7.2 writes the metrics expressions into the GLIF lib as com.fontlab.metricsWidth, com.fontlab.metricsLeft, com.fontlab.metricsRight. Previously, FontLab used non-prefixed lib keys width, lsb, rsb. FontLab reads both types of lib keys.