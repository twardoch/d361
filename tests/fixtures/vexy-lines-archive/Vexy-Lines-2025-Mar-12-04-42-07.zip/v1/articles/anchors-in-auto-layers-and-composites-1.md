## Metadata_Start 
## code: en
## title: Anchors in auto layers and composites 
## slug: anchors-in-auto-layers-and-composites-1 
## seoTitle: Anchors in auto layers and composites 
## description:  
## contentType: Markdown 
## Metadata_End

Auto-layers inherit anchors from their source glyphs automatically, composites inherit anchors when you generate or decompose them —but none of them inherit glyph guides.

Previously, if glyphs inherited anchors that had expressions linking them to the source glyphs’ guides, FontLab produced error messages in the Output panel. FontLab now removes expressions when it inherits the anchors.