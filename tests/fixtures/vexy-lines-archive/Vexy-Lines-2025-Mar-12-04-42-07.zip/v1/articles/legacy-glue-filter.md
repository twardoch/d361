## Metadata_Start 
## code: en
## title: Legacy Glue filter 
## slug: legacy-glue-filter 
## seoTitle: Legacy Glue filter 
## description:  
## contentType: Markdown 
## Metadata_End

If you have used the ==Glue== filter in FontLab VI or 7, and you open the VFC/VFJ in FontLab 8, FontLab uses the legacy ==Glue== engine on existing glued elements. The legacy ==Glue== consists of an element labeled ==glued group== in the ==Elements== panel. This element contains an element labeled ==glued== that contains the open contour. It also contains the remaining elements which serve as the body with which the glued element is joined. The legacy ==Glue== filter has two context menus:

- ==Glue== point context menu: right-click a glue point with ==Element== tool, or left- or right-click with ==Contour== menu, then choose how the glue joins the corresponding start / end node of the glued contour into the base.
- ==Glue== filter context menu: left-click with ==Element== tool, then choose how the glued element behaves when you move the glued element or the base.

These context menus made the legacy ==Glue== unnecessarily complex, so the new ==Glue== filter no longer has these options. You cannot apply the legacy ==Glue== filter to new elements.
