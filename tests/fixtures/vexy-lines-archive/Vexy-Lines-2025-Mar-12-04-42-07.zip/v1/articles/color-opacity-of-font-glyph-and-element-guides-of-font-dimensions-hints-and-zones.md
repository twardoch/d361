## Metadata_Start 
## code: en
## title: Color opacity of font, glyph and element guides, of font dimensions, hints and zones 
## slug: color-opacity-of-font-glyph-and-element-guides-of-font-dimensions-hints-and-zones 
## seoTitle: Color opacity of font, glyph and element guides, of font dimensions, hints and zones 
## description:  
## contentType: Markdown 
## Metadata_End

![Zones & hints opacity preference](https://i.fontlab.com/fl8/rn/fl8-rn7-pref-zones-opacity.png){ .r data-scale='25%' title="Zones & hints opacity preference" }

In ==Preferences > Grid, Guides and Hints==, you can now change the opacity at which the Glyph window shows alignment zones (if ==View > Show > Zones== is turned on) and hints (if ==View > Show > Hints== is turned on). If the opacity is set to less than 50%, the hints and zones and the Glyph window do not show their numerical values.

By default, the various types of guides have reduced opacity so they’re not too distracting:

- ==Font dimensions==: 30%
- ==Alignment zone==: 20%
- ==Font guide==: 50%
- ==Hint==: 50%
- ==Glyph guide==: 50%
- ==Element guide==: 80%

To make them fully visible, go to ==Preferences > Grid, Guides and Hints== and move their opacity sliders fully to the right.