## Metadata_Start 
## code: en
## title: Preparing Bitmap Artwork 
## slug: preparing-bitmap-artwork-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

Bitmap images can be used in several ways in FontLab. First, color bitmap images can be exported directly to fonts in [[Color Font Formats]]. Second, they can be used for creating traditional outlines via the [Autotrace](Autotracing) feature. FontLab can accept bitmap images in any common image format like PNG, JPG, BMP, TIFF. If you have your drawings on paper you must scan and save them into one of these formats first.


## Preparation of the Source Image


There are several steps that you must perform to prepare and scan your image. The scanning stage is very critical for the quality of the resulting characters in the font, so please read this section carefully and take the time to experiment with your scanner and adjust the scanning sequence for the best results.

To get best results we recommend that you prepare a source image (on paper) with the following considerations in mind:

- The paper must be white and smooth.

- The images of characters or symbols that you want to place into a font must be large. The real size of the symbols that you want to scan depends on the optical resolution of your scanner. We recommend that the size of the symbols be at least 2 inch/5 cm in height. If you want to get a very precise result, you can prepare bigger characters, even one huge character on a page. FontLab can process such a character, but our experiments have shown that characters bigger than mentioned above do not really improve the quality of the resulting outlines.

- If you want to scan your signature, write it as usual. The more natural it is, the better the result.

- If you are preparing a font of your handwriting, do not choose a thin pen. A pen with 0.7mm thickness is best.

- Never use a pencil! The image will look high-contrast on paper, but not when scanned. As a result you will get noise in the black areas of the image and holes in the characters’ strokes.

- If you are creating a handwriting font, try to align the characters on a baseline. You can use a light-yellow pen to draw guidelines before you write the characters. Low contrast yellow lines will not show up in a scanned image, but they will help you to align characters properly. 

- The distance between each string of characters is not important, but it must be large enough so the characters don’t overlap:

  | Wrong                                                                                  | Right                                                                                  |
  | -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
  | ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scanning_00.png) | ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scanning_01.png) |

- If you are not sure which shape of a character is best, write several versions, and then scan. Later, in FontLab, you can select the best version. It is much better to have several versions of a symbol on one paper than to make an additional scan, because even if the scanner settings are the same, the position of the paper in the scanner will differ, so the result will be different.

- Do not overlap characters. FontLab includes advanced algorithms that can separate characters of any form, but not when characters “touch” each other. In FontLab, overlapping or touching characters are treated as just one character. Manual separation of overlapping characters is possible, but is very time-consuming.  
   Here is what we mean by “touching” and “overlapping” characters:

  | Wrong                                                                                  | Right                                                                                  |
  | -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
  | ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scanning_02.png) | ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scanning_03.png) |
  | ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scanning_04.png) | ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scanning_05.png) |


## Scanning an Image


The optimal size for a bitmap is 700 pixels tall. If you are scanning an image to create a bitmap, a good rule of thumb is to scan the image at 2–3 inches tall and 300 dpi. Higher resolutions may pick up artifacts which can create unwanted results.

We also recommend that you scan the source picture in grayscale mode even when it appears black & white. This method allows you to get smoother glyph edges that will help create smooth outlines later. If you used light-yellow lines to align characters properly on paper, you should scan in color RGB mode.

Do not choose a resolution that is higher than the optical resolution of your scanner. For FontLab, this is not necessary and can significantly decrease the quality of the resulting outlines.

Once you have scanned your image or prepared it with an image editing application, you must save it in a format that FontLab can open: TIFF, JPEG, BMP, GIF or PNG.

See [[Importing Artwork]] for more details on importing images in FontLab.

When you have an image in the Sketchboard or Glyph window you can process it using basic filters from the ==Element > Image== menu. See the [[Bitmap Effects]] page for details.

Also see the [[Autotracing]] page to learn how to turn bitmaps into outlines.
