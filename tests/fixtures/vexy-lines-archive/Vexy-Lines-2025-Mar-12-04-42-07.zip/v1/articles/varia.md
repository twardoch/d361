## Metadata_Start 
## code: en
## title: Varia 
## slug: varia 
## seoTitle: Varia 
## description:  
## contentType: Markdown 
## Metadata_End

The History panel now has the Forget History button that lets you clean the undo stack if you wish to stop the ability to undo operations done before clicking the button. 

When exporting OpenType fonts, FontLab uses the Adobe FDK for OpenType (AFDKO) to compile the feature definitions and to create the CFF table contains PostScript glyph descriptions. FontLab 7 now uses AFDKO version [2.8.9](https://github.com/adobe-type-tools/afdko/blob/develop/NEWS.md#289-released-2019-04-29) that improves this process and fixes some problems.