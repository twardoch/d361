## Metadata_Start 
## code: en
## title: Synchronize in matching masters 
## slug: synchronize-in-matching-masters 
## seoTitle: Synchronize in matching masters 
## description:  
## contentType: Markdown 
## Metadata_End

These settings allow you to perform an editing action on the current master and have the same action “replayed” on all other masters that match the current master. As a result, your editing actions affect all compatible masters at once. Note that if any master doesn’t match the current master, it will not be affected.

Insert node keeps masters compatible when you add a node to a contour on one of the masters. The new interpolated node is added on the corresponding contour in other masters automatically. But if you add a new contour masters will lose their compatibility.

Rename node renames nodes across masters.

Remove node keeps masters compatible when you delete a node on one of the masters. The corresponding node is deleted in other masters automatically. If you delete a contour, the corresponding contour is removed on other masters as well.

Add, rename and remove guide adds a guide on all matching masters whenever you add a guide in the current master. If you rename a guide in one master, the guides with the same old name on other matching masters will get the same new name. If you remove a font guide in one master, the font guides with the same name on other matching masters will be removed.

Add hint allows you to add a hint on all matching masters.

Add or remove anchor allows you to add an anchor on all matching masters in the same position, and removes anchors from all matching masters that have the same name as the anchor you’re removing from the current master.