## Metadata_Start 
## code: en
## title: Title Case text conversion 
## slug: title-case-text-conversion 
## seoTitle: Title Case text conversion 
## description:  
## contentType: Markdown 
## Metadata_End

If you have multiple glyphs in your Glyph window, you can use ==Text > Change Case== or the buttons at the top of the Glyph window sidebar to change the case of the text between ==UPPER CASE==, ==lower case==, and now also ==Title Case==. 

This is very useful when checking spacing and kerning between uppercase and lowercase glyphs. 
