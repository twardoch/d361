## Metadata_Start 
## code: en
## title: Switching Workspaces 
## slug: switching-workspaces 
## seoTitle: Switching Workspaces 
## description:  
## contentType: Markdown 
## Metadata_End

To open a workspace, that is to change the arrangement of panels and windows to one of your saved versions, use the Window \> Workspaces menu where all workspaces that were stored are listed. Select the workspace name and it will be applied.