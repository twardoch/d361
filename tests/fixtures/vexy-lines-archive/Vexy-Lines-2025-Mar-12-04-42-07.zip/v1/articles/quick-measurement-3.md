## Metadata_Start 
## code: en
## title: Quick measurement 
## slug: quick-measurement-3 
## seoTitle: Quick measurement 
## description:  
## contentType: Markdown 
## Metadata_End

Quick measurement dynamically measures the distance between opposing paths as you move your mouse pointer. It is now more intuitive, and you can use keyboard shortcuts to influence it.

When you turn on View \> Show \> Quick Measurement and you move your pointer around the canvas, the automatic measurement shows the distance between two points on a contour or the contour and the sidebearing, and FontLab automatically decides which points to pick. This may be the horizontal distance, the vertical distance, or distance at an angle.

If you turn on Preferences \> Glyph Window \> Quick measurement \> Everywhere and move the pointer outside the filled area, FontLab now picks the closest distance for Quick measurement more smartly.

* Hold Shift to show either the horizontal distance, or the “vertical” distance, which follows Preferences \> Grid slant settings (explicit slant angle, or slant angle that follows the italic angle).
* Hold Shift+Alt to show the horizontal distance. If the Quick measurement preference is set to everywhere and you move the pointer outside the contour, FontLab shows the distance to the closest sidebearing.
* Hold Shift+Ctrl to show the vertical distance, taking the slant settings into account.