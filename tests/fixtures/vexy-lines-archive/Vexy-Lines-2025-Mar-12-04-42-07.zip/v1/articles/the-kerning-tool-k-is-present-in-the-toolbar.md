## Metadata_Start 
## code: en
## title: The Kerning tool (K), is present in the Toolbar 
## slug: the-kerning-tool-k-is-present-in-the-toolbar 
## seoTitle: The Kerning tool (K), is present in the Toolbar 
## description:  
## contentType: Markdown 
## Metadata_End

The Kerning tool (K), is present in the Toolbar. 

kerning\_in\_toolbar.png 

It activates the Kerning mode of the Glyph Window, where you can make specific adjustments in the spacing between a pair of glyphs that don’t fit well otherwise. If there is no open Glyph window, clicking the Kerning tool (note that here K will lead to the glyph for the Latin letter “k” being selected) opens the new Glyph window with currently selected glyph(s) in it, and activates the kerning mode. This behavior is the same as when Window \> New Kerning Window (or New Kerning Tab) menu item is selected.

kern\_tools.png

See the \[Glyph Window Modes\](Glyph-Window\#spacing-modes-metrics-kerning) for more information about Kerning mode in the glyph window, Kerning for the fundamentals of kerning and Editing Kerning for details.