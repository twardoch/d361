## Metadata_Start 
## code: en
## title: Better decompilation of contextual OpenType features 
## slug: better-decompilation-of-contextual-opentype-features 
## seoTitle: Better decompilation of contextual OpenType features 
## description:  
## contentType: Markdown 
## Metadata_End

If ==Preferences > Open Fonts > OT features > All lookups to Prefix== is turned _on_ and you open an OpenType font that contains contextual `GSUB` substitutions, FontLab decompiles the substitutions into the `FEA` syntax in the ==Features== panel as follows:

1. In the ==Prefix== section of the ==Features== panel, FontLab writes the lookup definition for the simple substitution:

```fea
lookup calt_2 {
  sub D by D.ss01;
} calt_2;
```

2. In the feature section of the panel (e.g. `calt`), FontLab writes the contextual substitution that references the simple substitution:

```fea
sub D' lookup calt_2 C;
```

!!! note

> Previous versions of FontLab always used this notation. It closely follows the internal structure of the OpenType font, many users don’t find it readable.

If turn **off** ==Preferences > Open Fonts > OT features > All lookups to Prefix== and open the font, FontLab now produces a simpler, more intuitive `FEA` notation for contextual lookups, like:

```fea
sub D' C by D.ss01;
```