## Metadata_Start 
## code: en
## title: Use Auto-meter to view corner angles 
## slug: use-autometer-to-view-corner-angles 
## seoTitle: Auto-meter for corner angles 
## description:  
## contentType: Markdown 
## Metadata_End

If the zoom level of the window is close enough, the Glyph window shows the angles between the line segments or curve handles adjacent to a sharp node:

- if the ==Corner angles== toggles in the ==View panel== is turned on,
- or if ==View > Measurement > Corner angles== is turned on,
- or if the ==Guides== tool is active