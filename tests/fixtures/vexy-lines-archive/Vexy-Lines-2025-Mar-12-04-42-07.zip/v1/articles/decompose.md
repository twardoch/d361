## Metadata_Start 
## code: en
## title: Decompose 
## slug: decompose 
## seoTitle: Decompose 
## description:  
## contentType: Markdown 
## Metadata_End

If you choose Decompose, FontLab will delete all glyphs you’ve selected.

In the affected composite glyphs, it will decompose the affected components, i.e. convert them to simple independent contours. (This was the behavior on FontLab Studio 5).

*Note: Some glyphs may become “partial composite glyphs” that will have both components and simple contours as a result. When you export them into OpenType TT, they will be decomposed.*