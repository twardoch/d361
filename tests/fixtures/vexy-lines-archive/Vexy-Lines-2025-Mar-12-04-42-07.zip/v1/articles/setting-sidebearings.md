## Metadata_Start 
## code: en
## title: Setting Sidebearings 
## slug: setting-sidebearings 
## seoTitle: Setting Sidebearings 
## description:  
## contentType: Markdown 
## Metadata_End

![][metrics_actions_04]

To set/modify the left and right sidebearings, use the Tools \> Actions \> Set Sidebearings operation. It offers five options for how each sidebearing can be set/modified:

1\. 	Set equal to: Enter the exact value you would like the sidebearing to be

2\. 	Auto + adjust: Let FontLab to automatically space glyphs and enter some amount to increase or decrease the results of autospacing

3\. 	Increase by: Enter the value by which you would like to increase the sidebearing

4\. 	Decrease by: Enter the value by which you would like to decrease the sidebearing

5\. 	Do nothing: Set this option to not modify the sidebearing

| :----- |
| Increasing or decreasing any of the sidebearings also increases or decreases the glyph advance width. |

If you check the Slanted sidebearings checkbox, FontLab makes all calculations as if the sidebearings are slanted by the slant angle set in \[Font Info\](Font-Info-Dialog-Box). This is very useful if you are designing an italic typeface. Note that if the slant angle is set to zero in Font Info, your preference in the checkbox doesn’t make any difference.

[metrics_actions_04]: metrics_actions_04.png width=183px height=120px