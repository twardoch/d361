## Metadata_Start 
## code: en
## title: Stroke panel 
## slug: stroke-panel-2 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

The **Stroke panel** ==Window > Panels > Stroke== shows stroke attributes for selected [[Elements]]. Most contours have the attribute “no strokes”. Stroked contours can be useful in font design, and in color fonts (where the stroke can have a different color than the fill), so FontLab supports them. 

This allows construction of an outline font drawing only the “skeleton” or centerline of each stroke. During export to traditional output formats, the stroke will be expanded/flattened into a conventional outline having the same visual effect. (At this time, the only FontLab output format that directly supports strokes is OpenType-SVG, which is primarily used for color fonts.)

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Stroke_panel_01.png)

In the Stroke panel you can enter the width (thickness) of the stroke. Additionally, you can select how strokes are started and finished. Select the starting and finishing element of the stroke by activating one of the buttons.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Stroke_panel_02.png)

You can also select the style of the connection between two sequential segments of strokes. It can be round, flat or miter. Select one in the dialog box. Tool tips on the buttons give an explanation of the styles of connections.

Finally, click the ==Apply== button to apply stroke attributes to all elements in the glyph.

To set the attribute back to “no stroke” for multiple selected elements or glyphs, use the ==Element > Remove Stroke== command.
