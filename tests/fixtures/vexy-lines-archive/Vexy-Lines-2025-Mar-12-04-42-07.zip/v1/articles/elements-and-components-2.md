## Metadata_Start 
## code: en
## title: Elements and components 
## slug: elements-and-components-2 
## seoTitle: Elements and components 
## description:  
## contentType: Markdown 
## Metadata_End

* Dragging in element group. When you dragged a selection by a segment rather than by a node, especially if the segment was in an element that was inside an element group, the contour could erroneously snap to itself. This no longer happens.
* Nodes in element groups. FontLab will now correctly show nodes in non-active grouped elements if Edit across Elements is on.
* Crash with composites. FontLab no longer crashes when decomposing certain composite glyphs or when generating certain composite glyphs with Generate Glyphs. 
* Stickers. You can now delete stickers that you create with Element \> New Sticker, and when you click them to edit, the text editing field appears in the correct location.