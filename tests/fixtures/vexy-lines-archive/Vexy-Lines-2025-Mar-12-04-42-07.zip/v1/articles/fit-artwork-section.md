## Metadata_Start 
## code: en
## title: Fit artwork section 
## slug: fit-artwork-section 
## seoTitle: Fit artwork section 
## description:  
## contentType: Markdown 
## Metadata_End

When you File \> Import \> Artwork a .pdf , .ai or bitmap image file, or when you copy-paste from an image editing app, from a vector graphics app, or from another font editor, choose these settings to place (align) the bottom of a bitmap image or vector artwork at a specific Font Dimension line, and to scale (fit) the vector artwork: Descender to UPM, Descender to Ascender, Baseline to Caps Height or Descender to Caps Height.

Bitmap images are not scaled. When you drag-drop, FontLab places the artwork where you drop it.