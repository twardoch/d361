## Metadata_Start 
## code: en
## title: Exporting feature definitions to VOLT 
## slug: exporting-feature-definitions-to-volt 
## seoTitle: Exporting feature definitions to VOLT 
## description:  
## contentType: Markdown 
## Metadata_End

Before you export your feature definitions as a VOLT project file (\*.vtp):

1. Sort your Font window by Index and make sure your first 4 glyphs in the font are .notdef, NULL, CR and space. This is because you’ll need to export the font as OpenType, and FontLab will put these glyphs first in the font.
2. Switch to the master you want to export.
3. You may want to Add Auto Features in the Features panel ☰ menu.
4. If you want GPOS features, then in the same menu, choose Create \[kern\] and Create \[mark\] and \[mkmk\] to create the FEA code for your kerning and mark attachment for the current master. When you export the features into the VOLT project file, FontLab will include these feature definitions, and you’ll be able to visually refine kerning and mark positioning in VOLT.
5. If your Lookups panel is not empty (i.e. it contains an older lookups data), Shift-click the Import from Features panel button at the top of the Features pane of the Lookups panel.

To export your features as VOLT project file (\*.vtp):

1. Go to File \> Export \> Export Font As…, choose the OpenType TT (.ttf) or OpenType PS (.otf) profile, click Customize…. In Glyph organization, turn off Sort glyphs in optimal order and choose Use current glyph names. Export Current layer using that profile.
2. Go to File \> Export \> Features… and choose the VOLT project file (.vtp) format.
3. Navigate to the same folder as you’ve exported the font, and export the .vtp file.

In Microsoft VOLT, group names (class names) are **case-insensitive**. When you export feature definitions to a VOLT project file, FontLab 7.2 uses the [UFO user name to file name](https://unifiedfontobject.org/versions/ufo3/conventions/) convention to convert the FontLab or FEA class names into VOLT group names. Most importantly, it adds an _ after each uppercase letter in the name.

Microsoft VOLT does not accept glyph or anchor names that contain a hyphen (-). When you export features as a VOLT project file, FontLab replaces the - in glyph and anchor names with three periods (...). When you import features from a VOLT project file, FontLab replaces ... with - in glyph and anchor names.