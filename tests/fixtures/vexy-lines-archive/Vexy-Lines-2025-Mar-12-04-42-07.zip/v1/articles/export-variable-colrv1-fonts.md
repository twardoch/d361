## Metadata_Start 
## code: en
## title: Export variable COLRv1 fonts 
## slug: export-variable-colrv1-fonts 
## seoTitle: Export variable COLRv1 fonts 
## description:  
## contentType: Markdown 
## Metadata_End

You can now export many color variable fonts in the COLRv1 flavor, so they can include gradients. You need to turn on this ability:

- Open [Nabla](https://github.com/google/fonts/raw/main/ofl/nabla/Nabla%5BEDPT%2CEHLT%5D.ttf) by Arthur Reinders Folmer and Just van Rossum.
- Choose ==File > Export Font As…==.
- Choose the ==Variable TT== profile, click ==Customize…==.
- Change the ==Profile name== to ==Variable TT color== and turn on ==OT+COLOR: Chrome, Windows== in the ==Export color font files== section, click ==OK==.
- Choose the ==Destination== and click ==Export==.
