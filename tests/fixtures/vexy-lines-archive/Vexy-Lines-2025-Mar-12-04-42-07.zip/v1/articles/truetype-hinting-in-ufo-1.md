## Metadata_Start 
## code: en
## title: TrueType hinting in UFO 
## slug: truetype-hinting-in-ufo-1 
## seoTitle: TrueType hinting in UFO 
## description:  
## contentType: Markdown 
## Metadata_End

If your font had visual FontLab TTH commands and you exported it into UFO, previous versions of FontLab stored the TrueType Hinting commands in the GLIF lib in the com.fontlab.ttprogram format. This format was problematic: it used XML outside the Apple Property List namespace. Therefore, the GLIF files were, strictly speaking, not valid. Example:

\<key\>com.fontlab.ttprogram\</key\>

\<data\>

\<ttProgram\>

\<ttc code="alignt" point="at01"/\>

\<ttc code="alignb" point="ab01"/\>

\<ttc code="alignb" point="ab02"/\>

\<ttc code="doublev" point1="dv01" point2="dv02" round="true"/\>

\</ttProgram\>

\</Data\>

FontLab 7.2 still can read the old com.fontlab.ttprogram format, but it now exports visual TrueType Hinting commands in a new com.fontlab.ttcommands format. Example:

\<key\>com.fontlab.ttcommands\</key\>

\<array\>

\<dict\>

\<key\>code\</key\>

\<string\>alignt\</string\>

\<key\>point\</key\>

\<string\>at01\</string\>

\</dict\>

\<dict\>

\<key\>code\</key\>

\<string\>alignb\</string\>

\<key\>point\</key\>

\<string\>ab01\</string\>

\</dict\>

\<dict\>

\<key\>code\</key\>

\<string\>alignb\</string\>

\<key\>point\</key\>

\<string\>ab02\</string\>

\</dict\>

\<dict\>

\<key\>code\</key\>

\<string\>doublev\</string\>

\<key\>point1\</key\>

\<string\>dv01\</string\>

\<key\>point2\</key\>

\<string\>dv02\</string\>

\<key\>round\</key\>

\<string\>true\</string\>

\</dict\>

\</array\>