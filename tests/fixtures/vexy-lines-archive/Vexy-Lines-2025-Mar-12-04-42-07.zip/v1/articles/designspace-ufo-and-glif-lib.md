## Metadata_Start 
## code: en
## title: DesignSpace, UFO and GLIF lib 
## slug: designspace-ufo-and-glif-lib 
## seoTitle: DesignSpace, UFO and GLIF lib 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 7.2 reads, stores and exports:

* the font lib that corresponds to the [DesignSpace](https://github.com/fonttools/fonttools/tree/master/Doc/source/designspaceLib#user-content-31-lib-element) lib element
* the font master lib that corresponds to the [UFO](https://unifiedfontobject.org/versions/ufo3/lib.plist/) lib.plist file
* the glyph lib and glyph layer lib that corresponds to the [GLIF](https://unifiedfontobject.org/versions/ufo3/glyphs/glif/#lib) lib element

When you open a DesignSpace+UFO project or a UFO Package, or when you import a GLIF file, FontLab *interprets* certain lib keys and converts them into native FontLab data. In those cases, FontLab does not store them in the FontLab lib.

When you export into DesignSpace+UFO or into an UFO package, FontLab exports the lib keys accordingly.  When the glyph and the glyph layer have a lib, FontLab will combine the libs on UFO export, with the glyph layer lib taking precedence for the same lib keys.

| :----- |
| FontLab 7.2 does not read or export lib keys for instance definitions in DesignSpace files. |