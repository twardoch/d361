## Metadata_Start 
## code: en
## title: Expand Contour 
## slug: expand-contour 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

The ==Contour > Expand Contour== command will use the selected contours as a trajectory for drawing parallel contours, one on either side of the selection:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Expand_contour_1.png)  
: Source open contour

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Expand_contour_2.png)  
: Path is expanded with parallel contour

To use this operation, first select the contours you want to expand. Note that all contours that have at least one node selected will be processed. If nothing is selected, the expansion will be applied to whole element contour. Select the ==Contour > Expand Contour== command in the menu. You will see a dialog box that allows you to select options:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Expand_contour_3.png) 

Here you can set the **Distance** between parallel contours, and the way you would like corners and ends of open contours to be treated:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Expand_contour_4.png)![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Expand_contour_5.png) 

: Flat contour ends vs. round ends

There are three types of **Joins**: round, bevel and miter. Miter joins extend the outer edges of the lines until they meet at an angle, similar to the corners of a picture frame. Round joins draw a circle with a diameter equal to the stroke width at each bend. Bevel joins are drawn as if the joining segments were stroked with butt cap ends and the resulting notch is filled with a triangle.

When you finish selecting options, click ==OK== to expand the selected contours.

See also the [[Create Parallel Contour]] operation which is similar but doesn’t close the created contours.
