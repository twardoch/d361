## Metadata_Start 
## code: en
## title: Generate Glyphs 
## slug: generate-glyphs-3 
## seoTitle: Generate Glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

In Font \> Generate Glyphs \> Custom, the Use legacy (FLS5) code setting is now called Use simple (FLS5) syntax. The Quick Help text that appears when you hold F1 over the setting is now updated to reflect the way the option currently works:

* *Off:* You can put one glyphname=recipe entry per line in [extended](https://help.fontlab.com/fontlab/7/manual/Glyph-Recipe-Syntax/) syntax, like Aacute = A + acute@top
* *On:* You can put one or more space-separated recipe=glyphname entries per line in [simple](https://help.fontlab.com/fontlab/7/manual/Glyph-Recipe-Syntax/) syntax compatible with FontLab Studio 5, like A+acute=Aacute, or put one !glyphname=recipe entry per line in extended syntax, like !Aacute = A + acute@top

Regardless of the setting, you can put multiple glyph names in one or more lines to use built-in glyph recipes. For syntax reference, close the Generate Glyphs dialog, tap Shift+F1 to open the Help panel, and reopen Font \> Generate Glyphs \> Custom.