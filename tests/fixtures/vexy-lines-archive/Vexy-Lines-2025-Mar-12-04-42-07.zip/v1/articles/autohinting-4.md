## Metadata_Start 
## code: en
## title: Autohinting 
## slug: autohinting-4 
## seoTitle: Autohinting 
## description:  
## contentType: Markdown 
## Metadata_End

In addition to manually adding hints, you can always use Tools \> Autohint (F7) to *automatically* create hints, or let FontLab create them on export.

In Preferences \> Autohinting, you can decide whether FontLab should *remove existing* hints when it automatically creates hints, and whether it should link the automatically created hints to nodes. These options are now *on* by default.