## Metadata_Start 
## code: en
## title: Outline Conversion 
## slug: outline-conversion-1 
## seoTitle: Outline Conversion 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab can convert outlines between TrueType and PostScript curves.

To convert selection from TrueType to PostScript, use the Contour \> Convert \> To PS Curves menu command. Conversion of curves from TrueType to PostScript can be “perfect” (lossless), using all the TrueType nodes and adding more as needed. However, the setting at Preferences \> Curve Conversion allows you to control how much approximation is allowed, and a slightly liberal setting can make for a conversion with far fewer points:

![][outline_conversion_03]

To convert selection from PostScript to TrueType, use the Contour \> Convert \> To TT Curves menu command. Conversion of curves from PostScript to TrueType is always something of an approximation since the Bézier curves used to describe Postscript outlines are more complex than those used for TrueType outlines. Again, the tradeoff between accuracy and keeping a minimal number of points can be controlled at Preferences \> Curve Conversion.

![][outline_conversion_03-1]

Outline conversion commands can be applied both from the Glyph Window and Font Window (or Font Map panel). 

In the Glyph window, if no selection is made and the operation is run, all the outlines in that glyph will be converted. Note that while you can make a selection within a glyph, you cannot convert only a segment of an outline. If you select a segment and run the operation, the entire contour to which it belongs will be converted.

In the Font window, all the selected glyphs will be converted if you run the operation. Select several glyphs at the same time by clicking the glyphs of your choice while holding down Cmd, or if they are in a continuous range, by clicking the first and last glyph of the range while holding down Shift. 

There is a method to convert a segment to TrueType/PostScript curve: simply Alt-click the segment. If it is a TrueType segment it will be converted to PostScript. If it is a PostScript segment Alt-click will show a small dialog box:

![][outline_conversion]

Click 1, 2 or 3 to select how many TrueType off-curve point should be used. Click Auto to let FontLab make a decision. Revert will reset the curve back to PostScript. Click OK or press Return when you are satisfied by the result.

[outline_conversion_03]: outline_conversion_03.png width=198px height=50px

[outline_conversion_03-1]: outline_conversion_03.png width=198px height=50px

[outline_conversion]: outline_conversion.png width=73px height=91px