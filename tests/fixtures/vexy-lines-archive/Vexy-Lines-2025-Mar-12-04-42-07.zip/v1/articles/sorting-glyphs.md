## Metadata_Start 
## code: en
## title: Sorting Glyphs 
## slug: sorting-glyphs 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

Sometimes you may want to sort the glyphs in a font file in some order other than their current order. This changes the physical order of glyphs stored in future output fonts from the current file. There are two typical reasons to do this:

1. You may need to sort glyphs to optimize a font’s performance – if you place glyphs that are used most often at the beginning of the glyph collection in some cases it may improve performance. 
2. You may need to sort glyphs according to some logical sequence. Some programs (for example, Adobe InDesign) have a “glyph insert” feature (the Glyphs panel) which shows the collection of glyphs sorted exactly as it is in the font file.

Please note that sorting of the glyphs has no effect on glyph encoding or names. It is simply the physical order of glyphs in the file, also called “Glyph ID” or “glyph index” order. To see the effects of sorting, or to sort glyphs manually, switch the Font window to the Index mode:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-sorting_glyphs-01.png)

Also note that in Index mode, moving glyphs does not replace the glyphs at the destination location but instead the moved glyphs will be inserted in front of the existing glyphs. What is changed is the glyph index — the physical order of glyphs in the font.

If you are **not** in Index mode, sorts still work fully (affecting glyph index), but you may not see the full results, because some or all of the glyphs are being displayed in some other order.

**To sort the glyphs** choose one of the commands in the ==Sort Glyphs== submenu of the ==Font== menu:

| Command       | Description                                                                                                                                                                        |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Current Order | Glyphs are sorted in the order you currently see in the Font window. For example, glyphs may be sorted according to the encoding table currently selected in the ==Encoding== menu |
| Unicode       | Glyphs are sorted by the assigned Unicode codepoints in ascending order. Glyphs that don’t have Unicode codepoints are stored at the end of the glyph collection                   |
| Name          | Glyphs are sorted alphabetically by their names in ascending order.                                                                                                                |
