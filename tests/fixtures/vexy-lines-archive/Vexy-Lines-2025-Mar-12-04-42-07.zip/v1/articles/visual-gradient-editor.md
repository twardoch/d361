## Metadata_Start 
## code: en
## title: Visual gradient editor 
## slug: visual-gradient-editor 
## seoTitle: Visual gradient editor 
## description:  
## contentType: Markdown 
## Metadata_End

![Image](https://i.fontlab.com/fl8/rn/fl8-rn7-visual-gradient-editor.png){ .plain title="Visual gradient editor"}

If the visual gradient editor is visible, you can edit the gradient directly in the Glyph window:

- Click a gradient point to edit its color in the color editor in the ==Color== panel.
- Click a gradient point and tap ++Backspace++ to remove it.
- Click the gradient line to add a gradient point.

To open the visual gradient editor, activate one of the gradient types in the ==Color== panel, then choose ==Element > Edit Gradient==, or click either the gradient bar or the ==Stroke==/==Fill== portion of the ==Color== panel. 