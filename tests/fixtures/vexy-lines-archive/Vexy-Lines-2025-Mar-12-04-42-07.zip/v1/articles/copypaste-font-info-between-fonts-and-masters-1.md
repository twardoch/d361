## Metadata_Start 
## code: en
## title: Copy-paste Font Info between fonts and masters 
## slug: copypaste-font-info-between-fonts-and-masters-1 
## seoTitle: Copy-paste Font Info between fonts and masters 
## description:  
## contentType: Markdown 
## Metadata_End

You can now copy-paste Font Info data between fonts and masters with the new set of buttons at the bottom-left of the Font Info dialog. You can copy-paste data for one Font Info page (except the Masters page, which is intended), or for all Font Info pages:

* from one single master to another single master in the same or in another font
* from one single master to all masters in the same or in another font
* from all masters in a source font to one or more corresponding masters in another font; corresponding masters are masters in the font *into* which you are pasting, which have the *same names* as masters in the font *from* which you have copied font info;

When you copy font info for a single master, you can paste font info into any other single master of the current font or of another font:

![][fl7-fontinfo-copy-all-pages]

Copy all Font Info pages for current or all masters

* To copy *all pages* or the *current master*, click Copy all pages (the 2nd button). Now switch to another master or another font. Since the clipboard contains info of all pages, you can change the page and click Paste page (the 3rd button) to paste into the current page of the current master.

![][fl7-fontinfo-copy-page]

Copy current Font Info page for current or all masters

* To copy the *current* Font Info *page* of the *current master*, click Copy page (the 1st button). Now Paste page will only work if you switch the font or master but stay on the same page.
* When you copy font info for a single master, you can also paste font info into all masters of the current font or of another font:
* Click Copy all pages or Copy page, then Alt-click Paste page to paste the copied info to all masters of the current font, or switch to another font and Alt-click Paste page to paste the info to all masters of that font.
* When you copy font info for all masters, you can paste font info to corresponding masters in other fonts.
* To copy *all pages* of *all masters*, Alt-click Copy all pages. Switch to another font. Click Paste page to replace the current page of the current master if it is “corresponding” to the copied data (i.e. the copied info has data for a master that has the same name as the current master). Alt-click Paste page to replace the current page of all corresponding masters.
* To copy the *current page* of *all masters* of the current font, Alt-click Copy page. As long as you stay on the same page, Paste page and Alt-Paste page will work for corresponding masters.
* If you clicked Copy all pages (current master) or Alt-clicked it (all masters), you can paste info to corresponding masters in multiple fonts: click the Paste to fonts… button and in the Paste Font Info Data dialog select one or more currently open fonts.

![][fl7-fontinfo-paste-fonts]

Paste copied Font Info into one or more fonts

[![][fl7-fontinfo-paste-fonts-dlg]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-fontinfo-paste-fonts-dlg.png)

Paste copied Font Info into one or more fonts

* If Paste to all masters is off and you click OK, FontLab will paste info for all pages into the current corresponding master of the selected fonts.
* If Paste to all masters is on, OK will paste all pages into all corresponding masters of the selected fonts.

| :----- |
| Since this copy-paste uses our new JSON-based system, you can turn on Preferences \> Editing \> Copy FontLab JSON data as plain text, use one of the new buttons, then paste Font Info data info a text editor, edit it there, and paste it back into a font or master. This way, you can paste font info between fonts with multiple masters even if their masters don’t match by name —just edit the master names in the intermediate JSON so that they correspond to your target font, and duplicate some portions of the data if needed, before pasting. |

[fl7-fontinfo-copy-all-pages]: fl7-fontinfo-copy-all-pages.png width=153px height=25px

[fl7-fontinfo-copy-page]: fl7-fontinfo-copy-page.png width=153px height=25px

[fl7-fontinfo-paste-fonts]: fl7-fontinfo-paste-fonts.png width=153px height=25px

[fl7-fontinfo-paste-fonts-dlg]: fl7-fontinfo-paste-fonts-dlg.png width=171px height=112px