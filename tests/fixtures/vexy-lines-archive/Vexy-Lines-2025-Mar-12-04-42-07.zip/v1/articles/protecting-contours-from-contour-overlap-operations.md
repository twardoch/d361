## Metadata_Start 
## code: en
## title: Protecting contours from **Contour: Overlap** operations 
## slug: protecting-contours-from-contour-overlap-operations 
## seoTitle: Protecting contours from **Contour: Overlap** operations 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab performs the ==Contour > Overlap== on closed contours in the current element, removes overlaps in the “front” and “back” contour before the operation, and always ignores open contours even if they’re selected.

To “protect” contours, that is, to exclude them from being merged into the “back” contour (especially: to protect them from overlap removal), you can do one of two things:

- Make each contour that you wish to skip an **open contour**: right-click a node on the contour and choose ==Break==, then perform the overlap operation. Next, use ==Contour > Join== to close it again.
- Move all contours that you with to skip into a **new element**: select the contours and choose ==Contour > Convert > To New Element== and click ==Create==, then activate the previously selected element and perform the overlap operation. Next, activate the ==Element== tool (second arrow), select all elements, choose ==Element > Contours > Combine to Element==, and activate the ==Contour== tool (first arrow).
