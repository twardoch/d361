## Metadata_Start 
## code: en
## title: Slanted sidebearings (glyph metrics) 
## slug: slanted-sidebearings-glyph-metrics 
## seoTitle: Slanted sidebearings (glyph metrics) 
## description:  
## contentType: Markdown 
## Metadata_End

In FontLab 7.1, the View menu now has an Italic Angle submenu that contains three entries that affect how the italic angle is used in connection with sidebearings and with the user-defined grid. Previously, FontLab had a 3-state menu item that had the same purpose but was less easy to use.

* When you choose Apply to Metrics or Apply to Metrics and Grid, FontLab 7.1 visually slants the sidebearing lines (Spacing Controls) in the Glyph window by the master italic angle, and shifts them by the caret offset. FontLab also adjusts the numerical sidebearing values by the caret offset. When you use View \> Measurement Line, FontLab shows the numeric values for sidebearings based on the intersections of the measurement line with the sidebearing lines that are slanted and offset.
* When you choose Do Not Apply, FontLab 7.1 renders the sidebearing lines as upright, and does not use the italic angle or the caret offset for the numerical sidebearing values.

FontLab 7.1 will use italic angle defined in the main master when you edit metrics for a font-less glyph master.