## Metadata_Start 
## code: en
## title: Blended Fill 
## slug: blend-fill 
## seoTitle: Blended Fill 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:customBlend-->
To create and evenly distribute strokes between the contours you have drawn (the basic ones), the **Blend** mode is provided in the **Handmade** fill. Using the parameters of this fill, you can control the smoothness and density of the strokes distribution. There is also an **Extending** parameter in the fill, when enabled, strokes will extend beyond the base contours. When using this option, even one basic contour may be sufficient.

If you move one of the original contours or change the reference point of the original contour, the strokes in the distribution will change accordingly. In addition, new strokes in the transition between the base contours will not have their own reference points.
> If needed, you can break down the strokes into individual contours that will be available for editing.

<!--qh-->

## Enable and Customize a Blended Fill
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28291%29.png){height="" width="280"}

To enable the **Blended** mode in the **Handmade** fill, follow these steps:

1. Make sure that you have selected the Handmade fill type.
2. Go to the **HANDMADE FILL** tab.
3. Activate the blending mode by toggling the **Blended** button.

<!--qh:customBlend-->

| blended: off |  blended: on |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28297%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28296%29.png){height="" width="300"}|

<!--qh-->

### Fill Parameters:
![image298.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image298.png){height="" width="300"}

<!--qh:dispersion-->
![Randomization](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-dispersion.svg) **Randomization** (%): Introduces a random variation to the interval distances, enhancing the strokes' natural appearance.
<!--qh-->

<!--qh:customInterval-->
![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) **Interval** ([units](/v1/docs/units)): Controls the distance between strokes. Smaller values bring the strokes closer, while larger values space them out.
<!--qh-->

<!--qh:customMiddle-->
![Shift](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-middle.svg) **Shift** (%): Adjusts the "phase" of the fill pattern by offsetting the first stroke in a direction orthogonal to the strokes. This nuanced adjustment alters the pattern's overall layout.
<!--qh-->

<!--qh:customSmooth-->
![Smoothness](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/wireframe-smooth.svg) **Smoothness**: Use this parameter to refine the flow of lines and curves, eliminating jagged edges for a polished look.
<!--qh-->

<!--qh:customExpand-->
![Extending](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/custom-expand.svg) **Extending**: extends the strokes beyond the basic curves.
<!--qh-->

<!--qh:customBlend-->
In the **Handmade** fill with **Blend** mode, **Allocation Controls** come into play. These are small triangles situated directly on the base curves. Each base curve can have only one such control. The spacing between the lines in the fill is determined by invisible lines connecting these controls. Specifically, the gap between two adjacent strokes is set by the distance between their intersection points with this invisible line. 

You have the freedom to move these controls along the contour, allowing you to fine-tune the fill density between each pair of base contours.
<!--qh-->

### Interval
1. Locate the **Interval** ![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) parameter.
2. Use the slider or manually enter a value.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28270%29.png){height="" width="300"}

<!--qh:customInterval-->
> Decreasing intervals darkens the image, while increasing intervals lightens it.
<!--qh-->

$~$

<!--qh:customInterval-->
| blended interval: 1 | blended interval: 1.5 | blended interval: 2 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28311%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28309%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28308%29.png){height="" width="300"}|
<!--qh-->


### Shift
1. Locate the **Shift** ![Shift](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-middle.svg) parameter.
2. Use the slider or manually enter a value.
3. The **Shift** adjusts the phase of the fill pattern, affecting the position of the first stroke relative to its original position.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28269%29.png){height="" width="300"}

<!--qh:customMiddle-->

| shift: 10% | shift: 50% | shift: 90% |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28279%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28277%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28278%29.png){height="" width="300"}|

<!--qh-->

### Smoothness
1. Find the **Smoothness** option in the **HANDMADE FILL** tab.
2. Modify the smoothness level by sliding the slider or inputting a desired value.
3. Increasing this setting will result in smoother transitions between strokes in the fill.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28261%29.png){height="" width="300"}

<!--qh:customSmooth-->

| smoothness: 0 | smoothness: 15 | smoothness: 30 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28314%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28316%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28315%29.png){height="" width="300"}|

<!--qh-->

### Extending

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28256%29.png){height="" width="300"}

1. Locate the **Extending** option in the HANDMADE FILL tab.
2. Activate this feature by toggling the button.
3. When enabled, the strokes in the fill will no longer be restricted by the basic contours and will extend beyond them.

<!--qh:customExpand-->

| extending: off |  extending: on | extending: on |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28317%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28318%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28319%29.png){height="" width="300"}|
<!--qh-->

### Allocation controls

<!--qh:customBlend-->
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28283%29.png){height="" width="92"}
<!--qh-->

1. Ensure that the selected **Handmade** fill is set to **Blend** mode.
2. Use your mouse to drag the control along the base contour.
3. As a result, the fill will update to reflect the adjusted intervals.
<!--qh:customBlend-->
> Note: Allocation controls are only available if there is more than one base contour in the fill.
<!--qh-->

$~$

<!--qh:customBlend-->

|  |  |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28281%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28282%29.png){height="" width="300"}|
<!--qh-->

