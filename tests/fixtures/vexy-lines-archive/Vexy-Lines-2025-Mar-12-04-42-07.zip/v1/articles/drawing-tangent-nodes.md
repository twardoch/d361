## Metadata_Start 
## code: en
## title: Drawing tangent nodes 
## slug: drawing-tangent-nodes 
## seoTitle: Drawing tangent nodes 
## description:  
## contentType: Markdown 
## Metadata_End

![image](https://i.fontlab.com/fl8/rn/fl8-rn2-drawing-tangents.gif){ .plain .r data-scale='66%' }

If all Rapid sub-tools are turned off, you can hold ++Cmd+Alt++{ .M} ++Ctrl+Alt++{ .W} and click to add a tangent node. If the previous node was a smooth node, a tangent node makes the previous segment a curve segment and the next segment a line segment. If the previous node was sharp, a tangent node makes the previous segment line, and the next segment curve.

If you turn on the ==Rapid > Tangent== sub-tool, you can click to add a tangent node.
