## Metadata_Start 
## code: en
## title: Context Dependent Substitutions 
## slug: context-dependent-substitutions 
## seoTitle: Context Dependent Substitutions 
## description:  
## contentType: Markdown 
## Metadata_End

A context-dependent rule can be any of the rules described above with one important difference: it defines a context that must include a target sequence of glyphs (or glyph classes).

In the simple form of, say, ligature substitution we simply write:

==

sub a b c by D;

==

In context-dependent substitution we can declare that “abc”, which is a target sequence of glyphs for a ligature substitution rule, must be a part of a larger context:

==

sub period a' b' c' period by D;

==

Only when “abc” is surrounded by two period glyphs will substitution take place. Note that we have marked the target glyphs with the single quote character positioned immediately after the glyph name.

The rule is specified as follows:

==

sub \<marked glyph sequence\>  Target sequence with marked glyphs 

by \<glyph sequence\>; 		 Sub-run replacement sequence 

==

A \<glyph sequence\> comprises one or more glyphs or glyph classes.

\<marked glyph sequence\> is a \<glyph sequence\> in which a set of glyphs or glyph classes is identified, i.e. “marked”. We will call this marked set of glyphs a sub-run. A sub-run is marked by inserting a single quote (’) after each of its member elements.

This sub-run represents the target sequences of the lookups called by this rule. The lookup type of the lookup called by this rule is auto-detected from their target and replacement sequences in the same way as in their corresponding stand-alone (i.e. non-contextual) statements.

Example 1. This calls a lookup. The rule below means: in sequences a d or e d or n d, substitute d by d.alt. 

==

sub \[a e n\] d' by d.alt;

==

Example 2. This also calls a single substitution lookup. The rule below means: if a capital letter is followed by a small capital, then replace the small capital by its corresponding lowercase letter. 

==

sub \[A-Z\] \[a.smcp-z.smcp\]' by \[a-z\];

==

Example 3. This calls a ligature substitution lookup. The rule below means: in sequences e t c or e.init t c, substitute the first two glyphs by the ampersand. 

==

sub \[e e.init\]' t' c by ampersand;

==