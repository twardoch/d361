## Metadata_Start 
## code: en
## title: The Matchmaker tool helps prepare masters for better interpolation 
## slug: the-matchmaker-tool-helps-prepare-masters-for-better-interpolation 
## seoTitle: The Matchmaker tool helps prepare masters for better interpolation 
## description:  
## contentType: Markdown 
## Metadata_End

The Matchmaker tool helps prepare masters for better interpolation.

matchmaker\_in\_toolbar.png

Select the Matchmaker tool in the Toolbar. If you see a green circle for the status in the Property bar, it means that your masters are compatible. If the circle is red, the masters are incompatible.

matchmaker\_tool\_02.png

To remedy that, you can use the Matchmaker tool. Choosing Matchmaker switches the Glyph Window into a mode where contours and nodes are presented schematically:

matchmaker\_mov.gif)

Use the blue handle at the zero point to change your angle of view across the masters. Changing the view can help you to visually group matching nodes and see which nodes are extra, or align poorly across masters. You can turn on the Match masters width toggle match\_width\_alt.png in the Property bar to compensate the difference in width of the masters. This works better for masters across a width axis, and makes the schema view more compact.