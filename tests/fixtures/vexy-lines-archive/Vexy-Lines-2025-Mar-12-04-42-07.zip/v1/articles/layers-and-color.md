## Metadata_Start 
## code: en
## title: Layers and Color 
## slug: layers-and-color 
## seoTitle: Layers and Color 
## description:  
## contentType: Markdown 
## Metadata_End

The font that results from Font \> Overlay Fonts now includes anchors from the main source font.