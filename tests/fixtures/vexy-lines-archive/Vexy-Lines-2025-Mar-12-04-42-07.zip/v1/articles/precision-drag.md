## Metadata_Start 
## code: en
## title: Precision drag 
## slug: precision-drag 
## seoTitle: Precision drag 
## description:  
## contentType: Markdown 
## Metadata_End

In 7.0.0, you could drag a contour selection with high precision when you held Cmd (Mac) or Ctrl (Win) and you dragged a point (node or handle), but not when you dragged a segment. In 7.0.1, you can also drag the segment with Cmd/Ctrl.