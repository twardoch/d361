## Metadata_Start 
## code: en
## title: GSUB tables 
## slug: gsub-tables 
## seoTitle: GSUB tables 
## description:  
## contentType: Markdown 
## Metadata_End

TBA