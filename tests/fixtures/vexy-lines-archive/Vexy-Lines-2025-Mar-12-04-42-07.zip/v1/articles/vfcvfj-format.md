## Metadata_Start 
## code: en
## title: VFCVFJ format 
## slug: vfcvfj-format 
## seoTitle: VFCVFJ format 
## description:  
## contentType: Markdown 
## Metadata_End

#### VFC/VFJ format

FontLab 7.2 uses an updated VFC/VFJ file format. In VFJ, the version of the main dictionary is now 9.

| :----- |
| If you save/export a VFC or VFJ in FontLab 7.2, you may not be able to open it in an older version of FontLab. When you try to open the newer VFC in an older FontLab, in some cases the file will open, in other cases the file may not open and you will get a Block parser exception error. When you try to open the newer VFJ in an older FontLab, in some cases the file will open, in other cases the app may hang. |

FontLab 7.2 opens VFC files more than 2× faster.