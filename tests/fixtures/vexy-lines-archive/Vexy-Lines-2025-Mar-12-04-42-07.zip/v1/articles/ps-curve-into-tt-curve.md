## Metadata_Start 
## code: en
## title: PS Curve into TT curve 
## slug: ps-curve-into-tt-curve 
## seoTitle: PS Curve into TT curve 
## description:  
## contentType: Markdown 
## Metadata_End

To convert a PS curve into a TT curve, select it and then choose Contour \> Convert \> To TT Curve, or use the keyboard shortcut Cmd+2. To convert a TT curve into a PS curve, select it and then choose Contour \> Convert \> To PS Curve, or use the keyboard shortcut Cmd+3.