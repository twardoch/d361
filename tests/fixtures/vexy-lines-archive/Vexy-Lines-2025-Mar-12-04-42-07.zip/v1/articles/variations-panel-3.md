## Metadata_Start 
## code: en
## title: Variations panel 
## slug: variations-panel-3 
## seoTitle: Variations panel 
## description:  
## contentType: Markdown 
## Metadata_End

The sliders in the Variations panel now show the location of  masters (as short lines). Previously, the sliders only showed axis instances (as larger dots).

In the List view of the panel:

* When you click any of the Play buttons, FontLab animates the variations preview along the axis.  In FontLab 7.2, the animation goes back-and-forth (ping-pong style). Previously, it arrived at the end of the axis scale and restarted at the beginning, which resulted in unpleasant jumps.
* When you Alt-click or Cmd-click any of the Play buttons, FontLab animates the variations preview along all axes.  When you do that, FontLab now correctly toggles the play/stop state of all Play buttons. Previously, it only visually toggled the button you Cmd-clicked.