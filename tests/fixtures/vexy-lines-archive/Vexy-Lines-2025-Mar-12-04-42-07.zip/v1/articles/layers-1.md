## Metadata_Start 
## code: en
## title: Layers 
## slug: layers-1 
## seoTitle: Layers 
## description:  
## contentType: Markdown 
## Metadata_End

The Layers panel in Strokes Maker is a powerful tool for organizing and managing objects within your document. It provides a visual representation of the document structure in a tree format, with each element corresponding to a specific type of object.

The order of the elements in the Layers panel tree reflects the order of objects in the document, allowing for easy navigation and organization. The three main types of elements are Group, Layer, and Fill, each with its own set of properties and functions.

Common properties such as Visibility and Lock are available for all object types, allowing you to control the visibility and locking of objects as needed. Additionally, specific properties and functions are available for each object type. For example, the Mask Overlay function is available for Group and Layer objects, allowing you to apply masks and overlays to these elements. The Overlap Control mode, on the other hand, is available for Fill objects, enabling precise editing and manipulation. It can have one of the following values:

    * "Cut through the fills below": This option allows the fill object to cut through any fills that are positioned below it.
    * "Allow to be cut by the fills above": With this option, the fill object can be cut by any fills that are positioned above it.
    * "Both above": This value allows the fill object to both cut through fills below it and be cut by fills above it.
    * "Either within the current layer": This option restricts the overlap control to only apply within the current layer of the document.
    * "Throughout the entire document": This value enables overlap control for the fill object throughout the entire document, regardless of layers.

Please note that these values determine how the fill object interacts with other fills in terms of cutting and being cut.

In the Layers panel of the graphic editor "Strokes Maker," there are a set of buttons located at the bottom that allow for managing the document structure. These buttons provide convenient options for various tasks such as adding new objects, deleting selected elements, creating clones of fills, and toggling the Mask Overlay mode for Group and Layer objects.

The following general commands are available:

    * Add new group: This button adds a new group to the document or within a selected group.
    * Add new layer: This button adds a new layer to the document or within a selected group.
    * Add new fill: This button adds a fill of the selected type to the selected layer. If no layer is selected, it creates a new layer with the chosen stroke type and adds it to the document or within a selected group.
    * Lock selected objects: This button locks the ability to edit the properties of the selected objects.
    * Remove selected objects: This button deletes the selected objects.

For a selected group or layer, the following commands are available:

    * Mask opacity: This button enables the opacity property of the mask. When this property is enabled, all objects within the group will exclude the fill from the area defined by the higher-level non-transparent mask.

For a selected fill, the following command is available:

    * Clone selected fill: This button creates a clone of the selected fill within the same layer.
    
    

In addition to managing the structure and properties of objects, you can also rearrange their order and position within the structure by simply dragging and dropping them with your mouse.

Overall, the Layers panel is an essential tool for organizing and managing your projects in Strokes Maker. It allows for easy structuring of your document, precise control over object visibility and locking, and the application of specific functions for each element type.