## Metadata_Start 
## code: en
## title: Editing deltas 
## slug: editing-deltas 
## seoTitle: Editing deltas 
## description:  
## contentType: Markdown 
## Metadata_End

- Click a delta (node or arrow) to select it. The delta is highlighted in red.
- Click a selected attachment delta, a horizontal delta or a vertical delta to convert it between bidirectional or unidirectional.
- Drag a delta (node or arrow) to change its value visually.
- Click a delta with ++Cmd++{ .M} ++Ctrl++{ .W} to specify its value numerically, or use the boxes in the property bar.
- Click a delta and tap ++Backspace++ to remove it. The node becomes untransformed.
- Select some nodes and ++Alt++-click an existing delta point to apply the same delta to the selected nodes.

When delta link is active:

- You can use the Glyph window property bar to edit the relative value of the delta on any point (how many units the point is shifted) or the absolute position of the final point.
- You can click the ==Copy to masters== button in the Glyph window property bar, and then choose ==Copy to all compatible masters==. FontLab will apply a delta filter with the same settings to all other matching masters for the glyph.

Click a unidirectional move delta to convert it to a bidirectional move delta. Click it again to make it a unidirectional move delta.