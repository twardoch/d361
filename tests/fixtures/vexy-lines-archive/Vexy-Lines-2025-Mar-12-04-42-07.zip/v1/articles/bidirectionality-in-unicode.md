## Metadata_Start 
## code: en
## title: Bidirectionality in Unicode 
## slug: bidirectionality-in-unicode 
## seoTitle: Bidirectionality in Unicode 
## description:  
## contentType: Markdown 
## Metadata_End

In Unicode, only some characters are associated with just one writing direction: Latin letters are always LTR, and Hebrew letters are always RTL, but digits or punctuation signs may be used in either direction.

The Unicode Standard categorizes characters used in horizontal writing into four directionality types:

| Type       | Example                                                                                  |
| ---------- | ---------------------------------------------------------------------------------------- |
| Strong     | LTR or RTL: letters, characters that are used in one script only                         |
| Weak       | LTR or RTL: numbers, some math signs, currency signs, nonspacing marks, some punctuation |
| Neutral    | spaces, some separators, most symbols and punctuation                                    |
| Formatting | small set of explicit directionality control codes                                       |

Read more about Unicode directionality:

- [Unicode Bidirectional Algorithm](https://unicode.org/reports/tr9/)
- [Unicode Character Database](https://www.unicode.org/reports/tr44/#Bidi_Class_Values)
- [Unicode Script Property](https://www.unicode.org/reports/tr24/)
- [Bidirectionality in Microsoft apps](https://learn.microsoft.com/en-us/dynamics365/fin-ops-core/dev-itpro/user-interface/bidirectional-support)
