## Metadata_Start 
## code: en
## title: Tag-based Font window filters are now case-sensitive 
## slug: tagbased-font-window-filters-are-now-casesensitive 
## seoTitle: Tag-based Font window filters are now case-sensitive 
## description:  
## contentType: Markdown 
## Metadata_End

If you assign tags such as `tag_a` and `tag_A` to different glyphs, these tags appear in the Font window sidebar ==Tags== section.

If you click one of the tags in the sidebar, or if you search for a tag in the Font window search box and choose ==Tags match== in the dropdown, the resulting Font window filter is now case-sensitive, as expected. Previously, tag-based filters ignored the case of the tag and returned too many results.