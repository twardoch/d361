## Metadata_Start 
## code: en
## title: Contour Direction 
## slug: contour-direction 
## seoTitle: Contour Direction 
## description:  
## contentType: Markdown 
## Metadata_End

Contours can be of two directions: clockwise or counterclockwise.

The basic rule that applies to PostScript (Type 1) contours is simple: clockwise-directed contours are unfilled and counterclockwise contours are filled. A simpler form of the rule, known as the rule of the left hand, is: if you face along the direction of a PS contour, black (fill) will be on your left side.

contours\_02.png

In the TrueType specification the opposite is the case, but this all doesn’t matter in FontLab anymore. You just fill or unfill contours as you wish with the \[Fill\](Fill-tool) (Bucket) tool and FontLab cares about the rest.

Use the View \> Show \> Contour Direction toggle to show/hide the gray contour-direction mark on a startpoint:

contours\_03.png