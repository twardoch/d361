## Metadata_Start 
## code: en
## title: Autosaving 
## slug: autosaving 
## seoTitle: Autosaving 
## description:  
## contentType: Markdown 
## Metadata_End

When you enable the **Autosave** option in Save Fonts Preferences, FontLab will automatically keep saving a backup copy of your working files as you work. When you close a file or quit FontLab normally, and choose to either save or not save the opened file, the autosaved file will be deleted. But if your FontLab crashes and you start it again, it will detect the autosaved files and offer to restore (reopen) them.

*Save copy in Autosave folder every X Minutes*

Use this option to activate *Autosave* and enter the time interval (in minutes) at which you want to save the font.

Font will be saved into the Autosave folder within the *FontLab user data* folder:

* macOS: Macintosh HD/Users/Your\_Name/Library/Application Support/FontLab/FontLab
* Windows: C:\\Users\\Your\_Name\\AppData\\Roaming\\Fontlab\\FontLab on Windows)

If *Autosave* was active and you have a system or program crash, you can open your last saved font from the Autosave folder.