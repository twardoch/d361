## Metadata_Start 
## code: en
## title: Keyboard shortcuts 
## slug: keyboard-shortcuts-7 
## seoTitle: Keyboard shortcuts 
## description:  
## contentType: Markdown 
## Metadata_End

Tools \> Commands is now called Tools \> Commands & Shortcuts, as this command serves both as a command launcher and as a place where you can customize keyboard shortcuts.

Press Shift+Cmd+P (Mac) or Shift+Ctrl+P (Windows), type a partial name of a command (e.g. pr p for Preview Panel) and press Enter, and FontLab performs the command. Think of the Shift+Cmd+P / Shift+Ctrl+P followed by a few typed characters and Enter as an “multi-keystroke shortcut”. It’s faster than mouse clicks. It’s slower than the direct shortcuts, but there’s typically a limit of the shortcuts you can memorize. Tools \> Commands & Shortcuts offers an excellent middle-way.

You can also use Tools \> Commands & Shortcuts to customize the keyboard shortcuts assigned to menu items. In recent FontLab 7 versions, the customizations were lost after the app restart on some computers. FontLab 7.1.2 remembers them correctly.