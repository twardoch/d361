## Metadata_Start 
## code: en
## title: Preferences > Grid 
## slug: preferences-grid 
## seoTitle: Preferences > Grid 
## description:  
## contentType: Markdown 
## Metadata_End

**Preferences \> Grid**

In Preferences \> Grid, you can customize the following:

* In Gridline distance, you can define the distance between vertical and horizontal gridlines.
* In Slant angle, you can define the angle for slanted vertical gridlines, which has to be within the -45˚+45˚ range. If you select Follow the font’s italic angle, an oblique font will be displayed with a slanted grid and sidebearings, and an upright font will be displayed with a vertical grid regardless of the slant angle that has been defined.

Use the Gridlines color dropdown let you to change the color of guidelines, and the use the slider to define their opacity.

Use the Dots opacity slider to change the opacity of gridlines intersections.

If Round nodes, guides and anchors to grid points is turned on, snapping to the grid becomes “strong” so that nodes, guides and anchors (but not handles) will snap to it immediately. If this setting is off, it will override the setting Show \> Snap \> Grid for nodes, anchors and guidelines. 

dialog.preferences.openfonts: Preferences \> Open Fonts; Options in Preferences \> Open Fonts are applied to fonts when they are opened and imported in the application:

* If Detect tags for alignment zones is on, FontLab will automatically assign tags to alignment zones when a font is imported.
* If Make friendly glyph names is on, glyphs with names like \\uniXXXX\\, \\uXXXXX\\ and \\afiiXXXXX\\ will be renamed to friendly names during import.
* If Change CID names to Unicode names when Unicode index in known is on, which is default, FontLab names glyphs using its regular glyph naming heuristics when importing CID-keyed PostScript fonts. If you want glyphs named by CID number turn this option off.
* If Detect element references is selected, FontLab will check glyphs in the font being opened or imported, and find identical elements. One of the found identical element will become the primary element, while others will be replaced by locked references to the primary one. If this option is unchecked, you can detect element references manually using Font \> Detect Element References.

In the Composite glyphs section you can choose how composite glyphs in the font being opened or imported should be handled:

1\. If you select Convert to elements, the components of the glyph will be converted to element references that can be manually unlocked and edited in place.

2\. If you select Keep as component elements, the components will be references to primary glyphs that change when the primary is modified and cannot be manually edited in the glyph. 

OpenType features controls the decompilation and compilation features:

1\. If Decompile binary features is checked, the application will decompile any OpenType features in the font being imported, and present them as text that can be edited in the Features panel.

2\. If Compile feature definitions is checked, FontLab will try to compile features imported from VFB and UFO file formats. This builds binary GPOS and GSUB tables (in memory), so they can be applied in the Glyph window.

In Glyph contours, if you check Convert TrueType curves into PostScript curves, the application will automatically convert the outlines on import. Curves are converted according to the settings set on the Curve Conversion section of the Preferences dialog.

FontLab can detect smart nodes automatically. In the Detect smart nodes, you can check whether you would like the application to detect Servant nodes, Genius nodes or both.