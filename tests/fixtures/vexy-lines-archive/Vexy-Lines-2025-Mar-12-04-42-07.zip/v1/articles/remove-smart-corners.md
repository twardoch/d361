## Metadata_Start 
## code: en
## title: Remove Smart corners 
## slug: remove-smart-corners 
## seoTitle: Remove Smart corners 
## description:  
## contentType: Markdown 
## Metadata_End

This action can be used to remove ink traps and Smart Corners, which have been added using the \[Add ink traps\](Contour-actionsadd-ink-traps) and \[Add Smart Corners\](Contour-actionsadd-smart-corners) operations. You can use the checkboxes in the panel to choose whether you would like to remove the ink traps, Smart Corners or both.