## Metadata_Start 
## code: en
## title: No style linking 
## slug: no-style-linking-1 
## seoTitle: No style linking 
## description:  
## contentType: Markdown 
## Metadata_End

In File \> Font Info, if you Alt-click Names \> Build Names, FontLab will build the names without style linking, so the typographic Style name such as “Bold Italic” gets appended to the Style group and the Style link always becomes Regular.

If you Alt-click From Axes or From Masters on the Instances page, the predefined instance names will be built without style linking (this only makes a difference if you export instances as static fonts, not in a variable font).