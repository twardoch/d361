## Metadata_Start 
## code: en
## title: Windows with multiple monitors 
## slug: windows-with-multiple-monitors 
## seoTitle: Windows with multiple monitors 
## description:  
## contentType: Markdown 
## Metadata_End

If you have more than one monitor and Preferences \> General \> Windows is chosen, when you open a new window, FontLab now opens it on the same monitor as the currently active window. Previously, FontLab always opened new windows on the main monitor.