## Metadata_Start 
## code: en
## title: Power Nudge 
## slug: power-nudge 
## seoTitle: Power Nudge 
## description:  
## contentType: Markdown 
## Metadata_End

**TBA: table**

Power Nudge mode is a special mode that affects the movement of nodes. Usually, when you move several selected nodes at the same time, only the selected nodes are moved, and the remaining (unselected) nodes stay in place. Sometimes, it is useful to move adjacent points proportionally. In these situations, the Power Nudge mode can help.

You can toggle Power Nudge on or off by choosing Contour \> Power Nudge (Shift-C). For turning it on more temporarily, hold down the C key: the mode is on until you release the key. With this mode on, select some nodes and move them. FontLab will automatically identify both additional nodes and handles, which should be nudged along with your selected nodes, and move them the amount it thinks will produce a good result.

There are also keyboard shortcuts to move nodes/contours and apply a nudge at the same time:

move by 1 unit & nudge

Mac: Ctrl+Alt plus arrow key

Windows: RightAlt plus arrow key

moves by 10 units & nudge

Mac: Shift+Ctrl+Alt plus arrow key

Windows: Shift+Ctrl+Alt (or Shift+RightAlt) plus arrow key

move by 100 units & nudge

Mac: Ctrl-Cmd+Alt plus arrow key

Windows: not available on Windows

| Mockup | Table |
| :----- | :----- |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |

(GIF)