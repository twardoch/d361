## Metadata_Start 
## code: en
## title: Anchors in Generated Glyphs 
## slug: anchors-in-generated-glyphs 
## seoTitle: Anchors in Generated Glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

Auto layers and composite glyph layers inherit anchors from all component glyphs used to generate the layer, but without duplicated anchors. 

For example: When FontLab generates the Aringacute manual or auto layer using the A+ringcomb+acutecomb legacy glyph recipe, and all three component glyphs have a top anchor, the final glyph will get the top anchor from acutecomb, placed accordingly. Anchors not present in acutecomb will be inherited from ringcomb, and finally, those not present there, from A.