## Metadata_Start 
## code: en
## title: Setting Up the New Font 
## slug: setting-up-the-new-font 
## seoTitle: Setting Up the New Font 
## description:  
## contentType: Markdown 
## Metadata_End

Go to the Font window. Select and drag your new color glyphs to the correct glyph cells, as needed. Add the space glyph: double-click it, and then open it and set its width to something that seems appropriate.

Open the File \> Font Info \[dialog\](Font-Info-Dialog-Box) and \[name your font\](Font-Naming). Fill in other relevant font attributes, such as the designer’s name, copyright string, version etc.