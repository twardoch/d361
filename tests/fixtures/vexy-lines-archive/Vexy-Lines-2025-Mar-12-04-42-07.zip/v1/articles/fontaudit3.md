## Metadata_Start 
## code: en
## title: FontAudit-3 
## slug: fontaudit3 
## seoTitle: FontAudit-3 
## description:  
## contentType: Markdown 
## Metadata_End

#### FontAudit

FontAudit is a set of algorithms that analyzes a glyph’s outline to easily spot odd points and suspicious curves or technical errors that may cause the glyph to not render as well on screen or in print.

To turn on FontAudit, go to the menu bar, and select View \> Show \> FontAudit. FontAudit will be visible in the Editor and Elements modes of the Glyph window.

You can check glyphs selected in the Font window as well: select several cells and choose Glyph \> FontAudit Glyphs.

If FontAudit finds what it thinks is an error, it shows a red arrow error pointer in the editing field of the Glyph window.

![][fontaudit_01]

Or it marks cells in the Font window with red marks in the right top corners:

![][fontaudit_04]

Hover the mouse pointer over the mark to see the short name of the error. For a full description, click the mark to see the FontAudit error details.

![][fontaudit_02]

This dialog has two buttons, Fix and Fix All, which you can use to try to automatically fix an error (Fix button) or all errors in the glyph (Fix All). Sometimes correcting one error causes others, so on occasion when you press the Fix (or Fix All) button you will see even more errors. Use the Fix feature carefully and be prepared to Undo an automatic fix.

Glyph \> Fix FontAudit Problems will do Fix All for all selected tests, applicable to currently selected glyphs or to the active glyph in the Glyph window.

Here is a short description of each test and the error that it detects. Tests that are new in FontLab are listed first.

\| Test \| Description \|

\| Curvature \| Node is located very close to the point of a smooth curvature connection. Use Genius connections to improve smoothness \|

\| Disproportional \| Control points of this curve are unbalanced. The shape of the contour may benefit from reconfiguration of the curve \|

\| Empty lines and curves \| Lines or curves that have no length (example: two nodes on top of each other) \|

\| Empty contours \| Contours consisting of one vector having only two nodes on its ends \|

\| Open contour \| Any contour which is not closed including empty contours. This test is off by default \|

\| Vectors on ClosePaths \| Unnecessary straight segment on a contour, leaving a zero-length “ClosePath” between the last point and the first point in the path. In fonts with PostScript outlines this error can cause problems with rasterization \|

\| Flat curves \| Curves that can be replaced with a straight segment without loss of quality (a “curve” that is really a straight line). Although if the curve is truly perfectly flat this will not cause rendering issues, but it makes the font file bigger for no reason, and makes it easier to cause the line to be accidentally curvy again \|

\| Collinear vectors \| Two sequential straight segments are collinear; therefore the first straight segment can be removed. Collinear refers to a single straight line with one or more extra nodes in the middle \|

\| Inflections on curves \| Detects curves that have inflections — points where the curve changes direction without a node present. It is better to break such a curve into two curves with a node at the inflection point \|

\| “Weak” extremum points \| There are “invisible” extreme points on curves. This error can cause problems with rasterization of the glyph \|

\| “Normal” extremum points \| Curves need nodes at extreme points \|

\| Incorrect smooth connection \| A straight segment and curve or two curves are connected very close to a smooth connection, but not precisely. This refers to what looks like a smooth connection but is labeled as a sharp connection \|

\| Cusp curve \| Сusp is a special version of the loop, where the curve loops as a single sharp point \|

\| Loop \| Intersecting handles make the curve segment to loop which is almost always unwanted \|

\| Zero-length handles \| Handles are present but have zero in their length field \|

\| Semi-horizontal and vertical vectors \| This refers to the direction of the straight segment is close to vertical or horizontal but is not parallel to one of the axes (i.e. not exactly horizontal or vertical) \|

\| Contour is not closed \| Contour visually appears to be closed but is defined as open \|

\| Object is too short \| Line or curve is short enough to be deleted. \|

| **Extension** | **Description** |
| :----- | :----- |
| ttf | TrueType, final font format with quadratic Bézier curves |
| otf | OpenType, final font format with cubic or quadratic Bézier curves |
| ufo | Flying objects from Serif planet studying why humans just use Helvetica |
| pfb | Type1, final font format with cubic Bézier curves |
| vfb | FontLab Studio 5, proprietary source format |
| woff | Web and also how D. Trump writes wolf. |
| woff2 | Web+ |
| glyphs | Glyphs editor, proprietary source format |
| designspace | \+UFO |

You can switch off any of the FontAudit tests by switching off their check boxes in the ☰ menu (FontAudit panel’s options):

![][fontaudit_03]

As you can see, FontAudit testing can detect errors that are invisible without you having to do a tough, lengthy analysis. On the other hand some errors are, in fact, warnings and do not necessarily impair the glyph’s outline quality.

[fontaudit_01]: fontaudit_01.png width=140px height=167px

[fontaudit_04]: fontaudit_04.png width=183px height=50px

[fontaudit_02]: fontaudit_02.png width=112px height=82px

[fontaudit_03]: fontaudit_03.png width=222px height=245px