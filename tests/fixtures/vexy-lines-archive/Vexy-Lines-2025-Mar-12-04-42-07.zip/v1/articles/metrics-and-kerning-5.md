## Metadata_Start 
## code: en
## title: Metrics and Kerning 
## slug: metrics-and-kerning-5 
## seoTitle: Metrics and Kerning 
## description:  
## contentType: Markdown 
## Metadata_End

* Link metrics for many glyphs in the Glyph panel
* Quickly autospace or autokern your glyph with the ; key
* Kern glyphs like other glyphs with Set Kerning Classes
* Define both-sided kerning classes
* Find visual conflicts (clashes) in class kerning and convert them into exceptions with Audit Kerning
* Kern most popular “kernable” combinations and easily manage word lists with the Pairs & Phrases panel
* Access common Metrics and Kerning operations from Glyph window context menu