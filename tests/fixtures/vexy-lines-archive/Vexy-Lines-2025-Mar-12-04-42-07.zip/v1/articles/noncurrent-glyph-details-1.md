## Metadata_Start 
## code: en
## title: Non-current glyph details 
## slug: noncurrent-glyph-details-1 
## seoTitle: Non-current glyph details 
## description:  
## contentType: Markdown 
## Metadata_End

If the Glyph window text has multiple glyphs, the **current glyph** is the glyph that you are currently editing. The other glyphs in the window are non-current glyphs. Non-current glyphs render and behave slightly differently than the current glyph. Depending on the window mode, click or 2×click a non-current glyph to make it current, or use the Text menu. Press Esc in the window several times to deselect the current glyph, so all glyphs in the window become non-current glyphs.