## Metadata_Start 
## code: en
## title: Unlink node 
## slug: unlink-node 
## seoTitle: Unlink node 
## description:  
## contentType: Markdown 
## Metadata_End

Since FontLab VI 6.0, the Fill tool in FontLab has allowed you to create filled areas within intersections of open or closed contours. You can, for example, draw four open paths in the shape of a  and use the Fill tool (F, ⬙) to only fill the rectangle inside. FontLab then creates a special compound “filtered element”. The compound element contains the result of the Fill operation (filter), and contains the source contours. When you edit the source contours, the filter automatically updates the result (the filled rectangle). When you export a font that contains such filtered element, it discards the unfilled portions of the paths, closes the contours and exports the inner rectangle.

The Fill tool works together with the Scissors tool (Q, ✄). Say you have a normal closed contour that forms a rectangle. Choose Unlink Corner from the context menu of one of the nodes, or use the Scissors tool to click the node. FontLab then unlinks the node: it cuts open the contour on that node, elongates the adjacent segments, and creates a compound element with the Fill filter applied.

Previously, you could only unlink a sharp node. Since FontLab 7.1, you can also unlink a smooth node. Choose Contour \> Unlink Corners to unlink all corner nodes (but not smooth nodes) in a contour selection.

The filtered result is identical to the original closed contour, but now, you have two independent “arms” that control the shape of the corner that is visible on the intersection of those arms. This gives you much more freedom in controlling the actual shape, because you can move one of the arm nodes to change the vertical edge of the rectangle, and keep the horizontal edge intact. This would be much more difficult to do with only one real corner node.

Shift+Alt-drag any of the arm nodes to elongate the arm segments further.