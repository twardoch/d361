## Metadata_Start 
## code: en
## title: Suggest distance 
## slug: suggest-distance-1 
## seoTitle: Suggest distance 
## description:  
## contentType: Markdown 
## Metadata_End

When you turn on View \> Suggest \> Distance, and you drag a node, handle, selection or anchor, FontLab now draws a temporary *suggested outline* at the distance defined in Font Info \> Other Values \> Contour properties \> Suggest distance. This is like having a freeform *grid that adapts* to your current drawing.

[![][fl72-suggest-distance-fontinfo]](https://help.fontlab.com/fontlab/7/manual/img/fl72-suggest-distance-fontinfo.png)

Suggest distance settings

* You can define separate horizontal (*x*) and vertical (*y*) distances, separately for each master.
* If the distance is a positive number, the suggested outline appears outside the existing closed contours, and to the right of open contours.
* If the distance is a negative number, the suggested outline appears inside the existing closed contours, and to the left of open contours.

[![][fl72-suggest-distance-use]](https://help.fontlab.com/fontlab/7/manual/img/fl72-suggest-distance-use.png)

Suggest distance in use

Use *Suggest Distance* to position anchors at a specified distance from existing contours, or to transform the existing drawing, especially if you turn on Contour \> Power Nudge, to quickly produce a bold or a condensed variant.

| :-----: |
| See our [video](http://www.youtube.com/watch?v=fjxUSlfbL9k) about this feature. |

* When you drag a point or anchor, it snaps to the suggested outline.
* When you select some points or segments and start dragging a point (node or handle) of that selection, that point snaps to the suggested outline.
* When you select some points or segments and start dragging the outline, FontLab chooses the nearest node of the selection as the *snap point*, and that snap point snaps to the suggested outline.
* When you select one or more anchors and start dragging one of them, that anchor snaps to the suggested outline.

| :----- |
| To quickly achieve consistency across your design, you can combine Suggest distance with View \> Suggest \> Stems. *Stem suggestions* are like an adaptive grid that appears at the horizontal or vertical distance equal to any stem defined in Font Info \> Stems. *Distance suggestions* are freeform: they use a predefined distance, and appear outside or inside an existing contour. |

[fl72-suggest-distance-fontinfo]: fl72-suggest-distance-fontinfo.png width=355px height=249px

[fl72-suggest-distance-use]: fl72-suggest-distance-use.png width=330px height=250px