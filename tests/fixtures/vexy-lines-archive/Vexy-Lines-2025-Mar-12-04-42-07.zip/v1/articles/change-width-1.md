## Metadata_Start 
## code: en
## title: Change width 
## slug: change-width-1 
## seoTitle: Change width 
## description:  
## contentType: Markdown 
## Metadata_End

*Change width*

Activate the master in which you want to change the width, open a Glyph window and type TBA.

**NEW** Choose Tools \> Actions \> Adjust \> Change width and choose Glyphs \> Window, and Layers \> Current. The Actions dialog preview will show the text.

The Actions dialog shows two sliders, and text boxes which preview the new thickness of the uppercase vertical stems, the thickness of the lowercase vertical stems, and the counter width.

These values are based on the content of the Measurements panel. When you open an OpenType font, FontLab automatically calculates these values. When you’re working on your own design, open Help \> Panels \> Measurements, click the top-left value on the first master, Shift-click the bottom-right value on the last master, and click the Recalculate button (♥) at the bottom. For non-Latin scripts or extended character sets, edit these values manually to match your design.

[![][fl714-change-width]](https://help.fontlab.com/fontlab/7/manual/img/fl714-change-width.png)

New Change width action and updated Actions dialog

* When the Keep vertical stem at checkbox if off, you can drag the Adjust width to slider to change percentage by which the width will change by plain horizontal scaling. When you drag the slider, FontLab updates all three measurement text boxes. Enter any value into one of the text boxes (or click the text box and use the ↑/↓ keys), and FontLab updates the position of the first slider — so you can scale the glyphs to a desired stem or counter width.
* When the Keep vertical stem at checkbox is on , you also can drag the second slider to change how much FontLab compensates the thickness of vertical stems when you make the horizontal scaling. When the checkbox is on and you drag Adjust width to, FontLab only changes the counter width. Drag Keep vertical stem at to update all three measurements. Enter any value into the stem thickness text boxes (or use ↑/↓), and FontLab updates the compensation. Change the counter width, and FontLab updates the Adjust width to slider.

If you want to apply the width change to all glyphs in the current master, now click Glyphs \> All. Finally, click OK. FontLab modifies the glyphs, and scales glyph metrics and anchors accordingly.

[fl714-change-width]: fl714-change-width.png width=481px height=325px