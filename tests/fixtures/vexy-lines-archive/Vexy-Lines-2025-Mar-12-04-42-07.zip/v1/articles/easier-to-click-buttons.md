## Metadata_Start 
## code: en
## title: Easier to click buttons 
## slug: easier-to-click-buttons 
## seoTitle: Easier to click buttons 
## description:  
## contentType: Markdown 
## Metadata_End

The buttons in the property bar are now easier to click — you can click slightly outside the button. This is consistent with Apple’s user interface guidelines.