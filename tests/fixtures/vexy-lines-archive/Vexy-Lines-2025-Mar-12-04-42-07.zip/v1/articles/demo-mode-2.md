## Metadata_Start 
## code: en
## title: Demo mode 
## slug: demo-mode-2 
## seoTitle: Demo mode 
## description:  
## contentType: Markdown 
## Metadata_End

If you or some of your friends, colleagues or students had installed the FontLab trial version, they could test and enjoy the app for 30 days. Many of you bought a license (thank you!). But some perhaps didn’t really like the early versions of the app (we admit, it used to be *rough around the edges*!). Or they didn’t have the budget at the time. After the trial expired —they couldn’t even get past the Activation screen. Well, *no more*!

Now, after the FontLab trial expires, the app switches to demo mode. While in the demo mode, you can still *open* all fonts, play and experiment with them, explore or learn the app —but you cannot *save*, *export* or *print*, and you cannot *copy* contours to *other apps*.

Many users told us that they recommended the demo version of FontLab Studio 5 to others as a powerful in-depth font viewer. FontLab in demo mode is, well, the *ultimate font viewer*!

You can use FontLab to open, proof and check fonts you made in another app, including TrueType-flavored variable OpenType fonts, color fonts in all flavors, fonts in development formats like .vfc, .vfj, .vfb, .fog, .ufo or .glyphs. You can check the curve quality, curvature, interpolation. You can test the kerning and OpenType Layout features. You can take the contours under the loupe with FontAudit. You can see if the automatic matching of masters helps you with the project you’re doing elsewhere. On the Mac, you can use FontLab’s TrueType Hinting tool to check how the font hinting produced elsewhere works in the built-in genuine Windows ClearType rasterizer.

And if you or your friends do need to *save* and *export* —the *buy* button is [right here](https://www.fontlab.com/VI/). 😊