## Metadata_Start 
## code: en
## title: Metrics Window 
## slug: metrics-window-1 
## seoTitle: Metrics Window 
## description:  
## contentType: Markdown 
## Metadata_End

There is no dedicated Metrics window in FontLab. When you choose the Window \> New Metrics Tab or Window \> New Metrics Window menu command, a new Glyph Window opens in the \[Metrics mode\](Metrics-tool), allowing you to \[edit glyph metrics\](Editing-Glyph-Metrics). When you choose Window \> New Kerning Tab or Window \> New Kerning Window menu command, a new Glyph window opens in the \[Kerning mode\](Kerning-tool).