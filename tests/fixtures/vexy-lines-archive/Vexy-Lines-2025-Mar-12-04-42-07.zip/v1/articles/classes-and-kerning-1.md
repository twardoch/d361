## Metadata_Start 
## code: en
## title: Classes and Kerning 
## slug: classes-and-kerning-1 
## seoTitle: Classes and Kerning 
## description:  
## contentType: Markdown 
## Metadata_End

Font \> Kerning \> Match Kerning now works much faster, especially on fonts with many masters.

**NEW** When you export classes with File \> Export \> Classes, you can now choose between two export formats: Legacy class files (\_.flc), which is single-master only and is compatible with FontLab Studio 5, and JSON classes files (\_.json), which supports multiple masters and is a subset of the FontLab JSON (VFJ) format.