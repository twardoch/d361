## Metadata_Start 
## code: en
## title: Glyph names 
## slug: glyph-names-3 
## seoTitle: Glyph names 
## description:  
## contentType: Markdown 
## Metadata_End

* When exporting to OTF: OpenType with PostScript outlines OpenType PS format, FontLab now correctly renames the glyphs to the AGLFN+uniXXXX convention if the Glyph names profile setting is Use standard PDF-compatible names. This affects he OpenType PS (.otf) profile and its derivatives. Previously, FontLab always exported the current glyph names into OTF. To export an OTF without renaming the glyphs, add a new profile based on OpenType PS in File \> Profiles…, set Glyph names to Use current glyph names, and export the font using the new profile. 
* You can now use glyph names that contain hyphens inside metrics expressions and auto layer recipes if you surround the glyph name with single quotes (e.g. 'A-cy') or double quotes (e.g. ="A-cy"-20). Font \> Link Glyph Metrics and Edit \> Paste Special \> as links now correctly use quotes with such glyph names when building metrics expressions.