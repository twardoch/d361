## Metadata_Start 
## code: en
## title: Layers & Masters in Font window sidebar 
## slug: layers-masters-in-font-window-sidebar 
## seoTitle: Layers & Masters in Font window sidebar 
## description:  
## contentType: Markdown 
## Metadata_End

The Font window sidebar has a Layers & Masters section that lists all unique layer names found in the font. When you click any of the layer names there, the Font window:

* Applies a filter that shows glyphs that have that layer
* Makes that layer current so you can see the glyph layers in the Font window cells

![][fl711-masters-fw]

Layers totals in Font window sidebar

* If a layer is not present in all glyphs, the Layers & Masters section now shows a number next to the layer name:
* If the layer exists in \<10% glyphs, shows in how many glyphs the layer is present, and is shown on gray background
* If the layer exists in 10–90% glyphs, shows that percentage
* If the layer is in \>90% glyphs, shows in how many glyphs the layer is missing (negative, relative to the total number of glyphs), and is shown on red background

The Non-matching entry in the section is now called Mismatch, and the number of glyphs where masters do not match is now shown on red background.

[fl711-masters-fw]: fl711-masters-fw.png width=98px height=100px