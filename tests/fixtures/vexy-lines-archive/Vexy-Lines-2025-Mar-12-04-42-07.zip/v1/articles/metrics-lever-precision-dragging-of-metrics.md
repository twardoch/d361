## Metadata_Start 
## code: en
## title: Metrics lever: precision dragging of metrics 
## slug: metrics-lever-precision-dragging-of-metrics 
## seoTitle: Metrics lever: precision dragging of metrics 
## description:  
## contentType: Markdown 
## Metadata_End

![Precision dragging preference](https://i.fontlab.com/fl8/rn/fl8-rn7-pref-metrics-dragging.png){ .r data-scale='25%' title="Precision dragging preference" }

The ==Preferences > Spacing== page now has a new setting ==Metrics and kerning editing changes value by 1/n of dragging distance==, where `n` can be up to `100`. A reasonable value is between `4` and `10`. ~~#6613~~

In the ==Metrics== mode of the Glyph window, if you drag a sidebearing line or a glyph and `n` is larger than `1`, the change in the metrics is more precise (smaller) than the distance of the dragging on screen. Hold ++Shift++ when you drag, and the change in the metrics will be the same as the distance of the dragging.

!!! tip

> ++Shift++-drag far to make larger changes. Then release the button and drag again by a small distance to make a precise adjustment.
