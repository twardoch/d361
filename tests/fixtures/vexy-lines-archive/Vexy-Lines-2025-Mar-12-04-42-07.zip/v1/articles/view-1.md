## Metadata_Start 
## code: en
## title: View 
## slug: view-1 
## seoTitle: View 
## description:  
## contentType: Markdown 
## Metadata_End

The "Document settings" control in the Strokes Maker graphic editor allows users to adjust various parameters related to the display of the workspace. This panel provides options for controlling the appearance of the working area in the editor.

One of the options available in the "Document settings" control is the "Visible image opacity." This parameter allows users to adjust the transparency of the original document. By adjusting this setting, users can make the underlying image more or less visible, depending on their preference.

Another parameter available in the "Document settings" control is the "Fill highlight color." This option allows users to choose a color that will be used to highlight selected strokes. When a stroke is selected, it will be filled with the chosen highlight color, making it easier for users to distinguish between selected and unselected strokes.

The "Mask highlight color" parameter is also included in the "Document settings" control. This option allows users to choose a color that will be used to highlight the selected layer when the mask is activated. By highlighting the selected layer, users can easily identify and work with specific layers in their design.

Users can also customize the background color of their workspace using the "Background color" option in the "Document settings" control. This allows users to personalize their workspace by selecting a color that suits their preferences or enhances their workflow.

The "Measurement unit for the current instrument" parameter allows users to set the default measurement unit used in the control elements and rulers of the current document. This ensures consistency and accuracy in measurements when working on different elements within the editor.

Additionally, the "Range for the fill parameters of the current document" option provides users with control over the minimum and maximum values for fill parameters. This includes the maximum length value for triangular end caps of curves, known as "Stroke Cups." By adjusting these ranges, users can fine-tune the fill parameters of their document to achieve desired effects.

Lastly, the "Document size" parameter displays the current size of the document. This information is important for users to have a clear understanding of the dimensions they are working with and to ensure that their design fits within the desired specifications.

In conclusion, the "Document settings" control in Strokes Maker offers a range of options for users to customize and manage the display of their workspace. From adjusting opacity and highlight colors to setting measurement units and document size, these settings provide users with the flexibility and control they need to create their desired designs.