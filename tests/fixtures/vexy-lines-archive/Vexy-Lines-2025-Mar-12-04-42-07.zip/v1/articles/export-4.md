## Metadata_Start 
## code: en
## title: Export 
## slug: export-4 
## seoTitle: Export 
## description:  
## contentType: Markdown 
## Metadata_End
The "Export Strokes as" option determines how strokes are exported to vector format:
  * **Normal**: Strokes are displayed as closed shapes with fill.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-NUJTDLZ9.png){height="" width="314"}
  * **Scribble**: Strokes are displayed as a simple zigzag line, evenly filling the fill line at a specified interval. The interval is determined by the number of vertical zigzag segments per 1mm of the fill line.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-Q4FS1K3J.png){height="" width="484"}

The SCRIBBLE mode can be useful if you intend to use the exported file for CNC machine output and similar purposes. 

| normal | scribble |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-HNVOB3BT.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3I2IOD2M.png){height="" width="300"}|

Scribble export is not applicable to Halftone, Traced, and Text fills.
