## Metadata_Start 
## code: en
## title: Copy kerning class assignment between glyphs 
## slug: copy-kerning-class-assignment-between-glyphs 
## seoTitle: Copy kerning class assignment between glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

![Paste Special kerning classes](https://i.fontlab.com/fl8/rn/fl8-rn-paste-special-kerning-classes.png){ .r data-scale='75%' title="Paste Special kerning classes" }

If you copy one or more glyphs in Font window, select other glyphs, then choose ==Paste Special...==, turn on ==Kerning classes== and click ==OK==, then for any source glyph that is part of any left and right kerning classes, the target glyph will also be placed in the same kerning classes.

If the source glyph is not in any kerning class, the duplicated glyph will not be placed in any kerning class.