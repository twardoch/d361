## Metadata_Start 
## code: en
## title: Font Map panel 
## slug: font-map-panel-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

The **Font Map panel** ==Window > Panels > Font Map== is the functional replacement for the [[Font Window]] in FontLab. If you have the Font window open you will see that the Font Map panel looks the same as the Font window. Like the Font window it contains the local toolbar, character cells, and status bar. All buttons and menus work the same way as in the Font window. If several fonts are opened in FontLab at the same time, the Font Map panel will show you the contents of the currently selected font.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Font_Map_panel_02.png)

**To leverage the advantages of the Font Map panel over the Font window**, switch off the ==Close font when its Font window is closed== option in ==Preferences > General==, and open the Fonts panel ==Window > Panels > Fonts. Now open several fonts in the application. You will see that the Fonts panel shows a full list of opened fonts. Even if you close all the Font windows or tabs, the list will still be available in the Fonts panel. With the combinations of the Font Map and Fonts panels, you can prevent your screen from becoming crowded with multiple open Font windows that are hiding behind each other.

**To switch the fonts you want to see in the Font Map panel**, select them accordingly in the Fonts panel.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Font_Map_panel-selecting_fonts.gif)

**To preview several fonts together in the Font Map panel**, select them in the Fonts panel using the ++Shift++ or ++Cmd++ key.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Font_Map_panel_03.png)

**To add the same color flag to a set of glyphs in more than one font**, select them in the Fonts panel using the ++Shift++ or ++Cmd++ key, and change their color flag. Cells of the selected fonts will get the same color flag.
