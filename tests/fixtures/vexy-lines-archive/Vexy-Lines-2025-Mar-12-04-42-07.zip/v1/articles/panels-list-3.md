## Metadata_Start 
## code: en
## title: Panels List 
## slug: panels-list-3 
## seoTitle: Panels List 
## description:  
## contentType: Markdown 
## Metadata_End

When you turn on Window \> Panels List, you can now resize that toolbar-like panel so that it is a vertical bar with all buttons in one column. To drag that panel, hold Cmd (Mac) or Ctrl (Win).