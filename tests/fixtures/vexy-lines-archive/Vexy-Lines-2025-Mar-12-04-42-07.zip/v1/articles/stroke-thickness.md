## Metadata_Start 
## code: en
## title: Stroke Thickness 
## slug: stroke-thickness 
## seoTitle: Stroke Thickness 
## description:  
## contentType: Markdown 
## Metadata_End

<!--qh:strokeThickness-->
Use the STROKE THICKNESS settings to adjust the thickness of fill lines and the size of Halftone fill dots.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28605%29.png){height="" width="300"}

<!--qh:strokeThickness-->
> Note: This setting is not applicable to Text and Trace fills.
<!--qh-->

### Options Panel
<!--qh:thicknessSlider-->
The panel displays the minimum (left) and maximum (right) thickness values. These correspond to the range of gray shades set by the Threshold parameter.

| thickness: 0 - 0.5 | thickness: 0 - 1 | thickness: 0.2 -  1 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28587%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28586%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28585%29.png){height="" width="300"}|

You can enter these values manually or adjust them using the sliders. You can move each slider individually or move both sliders simultaneously by dragging the area between them.

<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28589%29.png){height="" width="300"}

#### Inverted Mode
<!--qh:thicknessInverted-->
When using white strokes, you have the option to invert the thickness. By enabling this, the stroke thickness will increase for the white color.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28591%29.png){height="" width="300"}

<!--qh:thicknessInverted-->

| default thickness black strokes | default thickness white strokes |inverted thickness white strokes |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28592%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28593%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28594%29.png){height="" width="300"}|
<!--qh-->

### Additional Options

You can access the available additional options. To do this, click on the expand icon located to the right of the panel header.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28590%29.png){height="" width="300"}

### Thickness Transition

<!--qh:thicknessCurvature-->

Within the additional options, you can select how the shade of gray is converted to line thickness. Click on the control between the thickness value input fields to choose.

<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28588%29.png){height="" width="300"}

<!--qh:thicknessCurvature-->

The available modes are:

- **Norm** — the default mode with a linear transition.
- **Thick** — ease out, thickness first starts quickly, then slows down
- **Thin** — ease in, thickness starts slow, then speeds up

<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28584%29.png){height="" width="86"}

<!--qh:thicknessCurvature-->

When switching between modes, the minimum and maximum thickness values remain unchanged.

| linear | thick | thin |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28581%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28582%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28583%29.png){height="" width="300"}|
<!--qh-->

#### Smoothing

<!--qh:thicknessSmoothness-->

Use the thickness smoothing parameter to achieve smoother edges for strokes.

<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28595%29.png){height="" width="300"}

<!--qh:thicknessSmoothness-->

| 0 | 5 | 10 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28596%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28598%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28599%29.png){height="" width="300"}|
<!--qh-->

### Thickness at Line Break Point

<!--qh:breakStyle-->

The line break option can set two modes of thickness at the line break point:

* **Enabled** — starts the line with the actual thickness.
* **Disabled** — starts the line with the minimum thickness.

<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28604%29.png){height="" width="300"}

<!--qh:breakStyle-->

| on | off |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28603%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28602%29.png){height="" width="300"}|

<!--qh-->




