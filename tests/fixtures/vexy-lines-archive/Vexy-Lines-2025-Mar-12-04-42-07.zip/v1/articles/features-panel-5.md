## Metadata_Start 
## code: en
## title: Features panel 
## slug: features-panel-5 
## seoTitle: Features panel 
## description:  
## contentType: Markdown 
## Metadata_End

To enter a glyph name in the Features panel, type it. Alternatively, place your text cursor in the appropriate location, tap the / key, type a new glyph name, or a portion, or a synonym, choose the glyph from the visual list and press Enter.  When your text cursor is inside a glyph name and you use insert the glyph name via the / method, FontLab 7.2 now replaces the previous glyph name. If the cursor is inside a class name, FontLab inserts the glyph name after the class name. Otherwise, it inserts it at the cursor location.

[![][fl72-features-panel]](https://help.fontlab.com/fontlab/7/manual/img/fl72-features-panel.png)

Features panel

1. Place the text cursor in a glyph name, hold Alt and hold the mouse button: FontLab will show a small preview of the glyph.
2. Hold Cmd / Ctrl and click a glyph name: FontLab makes the glyph current in the Font or Glyph window, replacing the current glyph. Hold Cmd+Alt / Ctrl+Alt and click a glyph name: FontLab adds the glyph to the Glyph window text after the current glyph.
3. Place the text cursor in a class name (that starts with @), hold Alt and hold the mouse button: FontLab will show a list preview of the class. While you are holding the mouse button, you can scroll the list.
4. Hold Cmd / Ctrl and click a class name: FontLab opens the Classes panel and goes to that class (if the class is defined in the Classes panel).
5. Search in the Features panel in now case-sensitive.
6. When you choose ☰ \> Remove All Features in the Features panel, FontLab also removes the stored compiled features, so the change is immediately visible in the Glyph window and in the Preview panel.

When you select the Features section of the Features panel, you can see the code for all features, but you cannot edit it.  Previously, you could edit the code there but the edits were rejected. Now FontLab does not let you make any edits there.

To edit the code for a feature, choose the feature in the list on the left. To edit the particular feature, select it in the list at the left.

[fl72-features-panel]: fl72-features-panel.png width=390px height=246px