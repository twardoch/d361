## Metadata_Start 
## code: en
## title: Brush tool 
## slug: brush-tool-3 
## seoTitle: Brush tool 
## description:  
## contentType: Markdown 
## Metadata_End

When the Brush tool is active, the Property bar lets you change the size of the brush and choose one of the presents. Now you can double-click the brush shape preview in the Property bar to open the Brush panel, where you can tune additional aspects of the brush (the contrast and modulation).