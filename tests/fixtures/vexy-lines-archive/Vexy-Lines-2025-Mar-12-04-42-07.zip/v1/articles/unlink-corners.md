## Metadata_Start 
## code: en
## title: Unlink Corners 
## slug: unlink-corners 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

**Unlink Corners**, like the ==Contour > Break== command , breaks closed [[Contours]] or splits a closed contour into several open contours. However, instead of leaving the points right on top of each other at a break point, “Unlink Corners” breaks contours at each corner into separate overlapping sections, and adjusts each former corner vector a little (while maintaining their former shape) such that they cross. This allows FontLab to keep contours filled, and makes further element editing more comfortable than it would be after a Break operation.

To “Unlink Corners,” first select one or several corner nodes, and then choose the ==Unlink Corners== command in the ==Contour== menu or in the node’s context popup menu.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Unlink_Corners_01.gif)

When editing with unlinked corners, you may find that some areas occasionally change their fill (become black or white when you want the opposite). Use the [[Fill tool]] (++F++ key to activate, click in the area for white or ++Alt++-click for black) to fix these areas.
