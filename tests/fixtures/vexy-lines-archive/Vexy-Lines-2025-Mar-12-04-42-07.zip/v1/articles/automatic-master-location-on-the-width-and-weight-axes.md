## Metadata_Start 
## code: en
## title: Automatic master location on the width and weight axes 
## slug: automatic-master-location-on-the-width-and-weight-axes 
## seoTitle: Automatic master location on the width and weight axes 
## description:  
## contentType: Markdown 
## Metadata_End

In fonts with multiple masters, FontLab uses the Font Info \> Names \> Weight and Font Info \> Names \> Width style attribute values to automatically build the weight (wght) and width (wdth) axes, and to infer the location of the master on those axes — even if these axes are not defined in Font Info \> Axes. FontLab also makes glyph layers work as font masters if the glyph layers use names such as Regular, Bold or similar (using one of the registered weight or width keywords) — even if these font masters are not defined in Font Info.

This behavior was always on. Now, there is a new checkbox in Preferences \> Variations: Guess \[width \| weight \| width and weight\] axis location from master style attribute or layer name. When the checkbox is on and one of the entries (weight, width, width and weight) is chosen in the dropdown, FontLab will behave the same as it did in previous versions.

To disable this “guessing”, turn the checkbox off. If the Output panel reports errors like KeyError: : 'wght' when you export an OpenType Variations font, turn the checkbox off. Then, masters and layers will be variable along the weight and/or width axes only if the axes are defined in Font Info \> Axes and if the corresponding masters are defined and set to variable using the blue AAA toggle in Font Info \> Masters.