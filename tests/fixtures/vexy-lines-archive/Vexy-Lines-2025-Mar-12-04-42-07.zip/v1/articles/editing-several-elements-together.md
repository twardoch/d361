## Metadata_Start 
## code: en
## title: Editing several elements together 
## slug: editing-several-elements-together 
## seoTitle: Editing several elements together 
## description:  
## contentType: Markdown 
## Metadata_End

To see and edit the nodes of all the elements in the Glyph window, turn on Edit \> Edit Across Elements. When Edit Across Elements is turned off, you can see and edit the nodes of only the current glyph.

![][edit_across_elements]

[edit_across_elements]: edit_across_elements.png width=300px height=118px