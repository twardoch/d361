## Metadata_Start 
## code: en
## title: Welcome Dialog 
## slug: welcome-dialog-3 
## seoTitle: Welcome Dialog 
## description:  
## contentType: Markdown 
## Metadata_End

You can uncheck the option *Open this dialog at startup*, if you would like it to not open every time you start the application.

![][welcome-r]

Welcome Dialog

[welcome-r]: welcome-r.jpg width=304px height=225px