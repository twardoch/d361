## Metadata_Start 
## code: en
## title: Kerning Mode 
## slug: kerning-mode 
## seoTitle: Kerning Mode 
## description:  
## contentType: Markdown 
## Metadata_End

To adjust spacing between specific pairs or classes of glyphs, open a Glyph window in \[Kerning mode\](Glyph-Windowspacing-modes-metrics-kerning). Do this by clicking the Kerning tool (K) or by selecting the Window \> New Kerning Window (New Kerning Tab) menu item.

The Property bar of the Glyph window in the kerning mode looks like this:

![][kern_tools]

Use any of the methods described in Editing an Existing Glyph to add glyphs to the window. For example, while in the Kerning mode, press T. This will switch the window to the \[Text mode\](Glyph-Windowtext-mode) allowing you to type any glyph or text. Type glyphs which you are going to kern and press Esc to switch back to the Kerning mode.

You may also enter pairs using the Content sidebar by selecting the text-tool\_01.png button in the Property bar.

You can assign color backgrounds to Metrics and Kerning modes, independently of the general color background in use. This option is in \[Preferences \> Spacing\](Preferencesspacing).

[kern_tools]: kern_tools.png width=450px height=97px