## Metadata_Start 
## code: en
## title: Pasting vector artwork 
## slug: pasting-vector-artwork 
## seoTitle: Pasting vector artwork 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 7 supports two formats for clipboard exchange of vector artwork:

* AICB: The legacy AI clipboard format, which is a simplified subset of Encapsulated PostScript. It stores Bézier paths with coordinates relative to the original artboard, supports simple fills and strokes, but has limited support for clipping masks and some other features of vector graphics.
* PDF: The more modern clipboard format, which is used natively by many macOS apps. It handles more complex situations than AICB (such as clipping masks, complex fills and transparency), but stores Bézier path coordinates relative to the bounding box of the object. Support for PDF copy-paste is new in FontLab 7.

When you copy vector artwork (contours) in *FontLab Studio 5*, the app puts the representation of the artwork into the clipboard in its own native format and in AICB. *Adobe Photoshop* copies vector artwork as AICB. When you copy vector artwork in *Adobe Illustrator*, the app puts the representation of the artwork into the clipboard in AICB, in PDF and also in SVG. Apps like *Affinity Designer* and *Sketch* copy vector artwork only as PDF.

When both AICB and PDF representations are in the clipboard, FontLab VI and FontLab 7.0.0 for Windows always pasted AICB, while FontLab 7.0.0 for Mac pasted PDF. When the clipboard only had PDF, FontLab 7.0.0 for Mac pasted it, while FontLab VI and FontLab 7.0.0 for Windows pasted either a bitmap representation or nothing.

There is a setting in Preferences \> Paste & Duplicate: *Prefer legacy AI clipboard format when pasting vector artwork*. This setting in now on by default, and affects copy-paste into FontLab mainly from Adobe Illustrator.

* If *Prefer legacy AI clipboard* is on, FontLab 7 will use the AICB representation rather than PDF if both formats are in the clipboard. This is best for monochrome artwork. FontLab will combine all paths that have the same appearance (fill and stroke) into a single element, so you’ll get immediately editable contours. When the Scale artwork preference is set to Do not scale or align, the artwork will be pasted at the same position in font units as the artwork had in points on Illustrator’s artboard when using global rulers. In Illustrator, you can control where the artwork will be pasted: in View \> Rulers, choose Change to Global Rulers and turn on Show Rulers, then click the top-right corner of the rulers (where the horizontal and vertical rulers meet), and drag to the new origin point — this will define the placement of the 0,0 point.
* If *Prefer legacy AI clipboard* is off, FontLab 7 will use the PDF representation rather than AICB if both formats are in the clipboard. This is generally better for multi-color and complex artwork, especially if it uses clipping masks. FontLab will the artwork as a group of elements, in which each compound path as an individual element (choose Element \> Combine Contours to Element to make them all editable contours within a simple element). Also, if *Do not scale or align* is chosen, FontLab will place the artwork so that its bottom-left corner is at 0,0 —because PDF does not store artboard-based coordinates.

When only PDF is available (for artwork copied in Affinity Designer or Sketch), or only AICB is available (for vector artwork copied in FontLab Studio 5 or Photoshop), FontLab 7 will use the available format. Prefer legacy AI clipboard only affects situations when both AICB and PDF are in the clipboard.