## Metadata_Start 
## code: en
## title: Here is where you set the type of sample texts you wish to use, such as Lorem 
## slug: here-is-where-you-set-the-type-of-sample-texts-you-wish-to-use-such-as-lorem 
## seoTitle: Here is where you set the type of sample texts you wish to use, such as Lorem 
## description:  
## contentType: Markdown 
## Metadata_End

Here is where you set the type of sample texts you wish to use, such as Lorem Ipsum…

You actually have titles at the left and texts at the right. Double-click a title to edit it. Use + to add more samples or - to remove the sample which you do not need.

These sample texts appear in the Text drop down menu in the Property bar of the Glyph window.

![][texts-r]

[texts-r]: texts-r.jpg width=359px height=299px