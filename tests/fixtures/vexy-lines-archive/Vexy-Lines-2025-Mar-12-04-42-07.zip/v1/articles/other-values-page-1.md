## Metadata_Start 
## code: en
## title: Other Values page 
## slug: other-values-page-1 
## seoTitle: Other Values page 
## description:  
## contentType: Markdown 
## Metadata_End

The new Contours \> Unfill looped corners setting turns on automatic unfilling of outer looped corners (see above).

At the bottom of Font Info \> Other Values, there is now an Auto button. Click it to automatically calculate the content of the Other Values section. This includes a very simple calculation of the new PANOSE identifier.