## Metadata_Start 
## code: en
## title: Synonyms 
## slug: synonyms-1 
## seoTitle: Synonyms 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 7 also includes a list of about 10,000 fallback synonyms, curated by the FontLab team. Fallback synonyms are glyph names for a given Unicode characters that are not in any of the built-in naming schemes, but have been used in some shipping fonts. FontLab uses fallback synonyms when you generate Unicode codepoints based on glyph names with Font \> Generate Unicode.

FontLab 7 has a Find glyph name synonyms toggle next to many text boxes where you can search glyphs by name: Edit \> Find Glyphs (Cmd+F/Ctrl+F), Quick Find Glyphs (/), Glyph \> Add Component, and Filter by glyph in the Classes panel. When this toggle is on and you type a glyph name, FontLab will find a glyph even if the glyph uses a different naming scheme —for that, FontLab uses all four built-in naming schemes and fallback synonyms.