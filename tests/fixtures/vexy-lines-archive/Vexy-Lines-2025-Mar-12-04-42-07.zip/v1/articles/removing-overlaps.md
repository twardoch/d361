## Metadata_Start 
## code: en
## title: Removing overlaps 
## slug: removing-overlaps 
## seoTitle: Removing overlaps 
## description:  
## contentType: Markdown 
## Metadata_End

Often, when drawing glyphs, you may end with several overlapping Contours. 

Static font formats (not Variable Fonts or Multiple Masters) such as OpenType PS, TrueType or Type 1 theoretically allow you to keep overlaps in the final fonts, but many font rasterizers, especially those built into some printers, may show the overlapping contours as reversed (unfilled), which is undesirable. Therefore, when building static fonts, it is desirable to remove overlaps. FontLab will automatically get rid of the overlap at font generation time, for those formats where overlapping contours are considered improper.

However, often there is no reason to keep overlapping contours and it is sometimes easier to work with the contours merged. The Remove Overlap operation merges overlapping closed and opened contours. It respects the filled/unfilled state of contours and removes unnecessary orphan nodes and open contours.

OpenType Variable Fonts support overlaps in closed contours, so you don’t need to remove them. The operating systems and apps that support Variable Fonts should remove the overlaps when sending the font to a printer. Also, if your fonts are masters from which you will generate static instances via interpolation, you should not remove the overlaps in the masters, but only in the final instances. Removing overlaps changes the composition of the contours, so it may change the way your masters interpolate, or might even make the masters incompatible and break the ability to interpolate at all. 

If you work with open contours, the overlaps will need to be removed at some point in any case, because no final font format supports open contours. In these cases, you can remove the overlaps manually, and review the results; or you can let FontLab remove the overlaps automatically when the font is generated. 

BEFORE: 

![][remove_overlap_01]

AFTER: 

![][remove_overlap_02]

If you select two or more contours only these selected contours will be merged. If all contours or no contours are selected, all contours in the current \[element\](Elements) will be merged. To apply Remove Overlap to another element in the glyph, switch to that element first.

Like most other contour operations, Remove Overlap can be applied to all glyphs selected in the Font window (or Font Map panel).

[remove_overlap_01]: remove_overlap_01.png width=220px height=148px

[remove_overlap_02]: remove_overlap_02.png width=220px height=148px