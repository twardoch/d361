## Metadata_Start 
## code: en
## title: PostScript hinting in UFO 
## slug: postscript-hinting-in-ufo 
## seoTitle: PostScript hinting in UFO 
## description:  
## contentType: Markdown 
## Metadata_End

If your font had PostScript hints and you exported it into UFO Package, previous versions of FontLab stored the hints in the GLIF lib in the com.adobe.type.autohint format. This format was once used by AFDKO but was problematic is no longer recommended: it used XML outside the Apple Property List namespace. Therefore, the GLIF files were, strictly speaking, not valid. Example:

\<key\>com.adobe.type.autohint\</key\>

\<data\>

\<hintSetList\>

\<hintset pointTag=""\>

\<hstem pos="0" width="140" /\>

\<hstem pos="560" width="140" /\>

\<vstem pos="50" width="160" /\>

\<vstem pos="360" width="162" /\>

\</hintset\>

\</hintSetList\>

\</Data\>

FontLab 7.2 now exports hints in a more modern format [public.postscript.hints](https://unifiedfontobject.org/versions/ufo3/glyphs/glif/), which is an official part of UFO3. FontLab writes the pointTag key only if it is needed for hint replacement (the current UFO spec is not clear whether this key is required).

Example:

\<key\>public.postscript.hints\</key\>

\<dict\>

\<key\>formatVersion\</key\>

\<string\>1\</string\>

\<key\>id\</key\>

\<string\>4dfb94e2f06558a476220e...\</string\>

\<key\>hintSetList\</key\>

\<array\>

\<dict\>

\<key\>stems\</key\>

\<array\>

\<string\>hstem 0 140\</string\>

\<string\>hstem 560 140\</string\>

\<string\>vstem 50 160\</string\>

\<string\>vstem 360 162\</string\>

\</array\>

\</dict\>

\</array\>

\</Dict\>

FontLab now imports hints from the com.adobe.type.autohint.v2 structure, which is identical to public.postscript.hints, and also imports the older com.adobe.type.autohint format.

If you customize the UFO export profile and turn on Use legacy format version, FontLab will export version 2 of UFO, and will write the new-style hinting data, but it will use the com.adobe.type.autohint.v2 key.