## Metadata_Start 
## code: en
## title: Using integers 
## slug: using-integers 
## seoTitle: Using integers 
## description:  
## contentType: Markdown 
## Metadata_End

To instantly round coordinates of all items (nodes, guidelines, hints, zones, anchors etc.) in the current glyph, use the Contour \> Coordinates \> Apply Rounding command. This one has a one-time immediate effect. For example, this will change the fractional size (17.5) of our sample square to 18 units; so scaling at 200% will now end up at 36 units.