## Metadata_Start 
## code: en
## title: @ current glyph placeholder 
## slug: current-glyph-placeholder-1 
## seoTitle: @ current glyph placeholder 
## description:  
## contentType: Markdown 
## Metadata_End

In the Custom text and Context content settings of the Preview panel, the @ character is a placeholder for the current glyph.

**NEW** You can now also use \\@ as current glyph placeholder.

* Click the Preview panel canvas and type some text including @. Type another glyph, and @ will be replaced by the current glyph. Whenever you switch the current glyph in the window, the @ placeholder will update to show the new current glyph.
* In the Preview panel sidebar, choose Custom text and turn on Show glyph names. In the top text box type @ for the same effect.
* To actually preview “@” (the at glyph), type @ twice (@@) or **NEW** type /@ followed by a space or another escaped glyphtext character.
* When you choose Context in the sidebar, click ☼ to customize the text, use @ as the placeholder for current glyph, e.g. nn@oo@HH@OO. The result is the same as using this text in the Custom text content setting, but the context string is stored in preferences so it’s more “permanent”.