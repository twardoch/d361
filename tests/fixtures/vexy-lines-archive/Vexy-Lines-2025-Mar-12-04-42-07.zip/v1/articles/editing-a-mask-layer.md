## Metadata_Start 
## code: en
## title: Editing a Mask Layer 
## slug: editing-a-mask-layer 
## seoTitle: Editing a Mask Layer 
## description:  
## contentType: Markdown 
## Metadata_End

To edit a Mask layer with the usual editing tools, you need to first activate it in the Layers and Masters panel or using the Tools \> Edit Mask (Ctrl+H) command. 

When the Mask layer is selected for editing, the editing area changes its background color to remind you are in the Mask layer. Use any editing tool to create, edit or remove the nodes and contours of the Mask layer outline. When you are finished working on the mask, you can (re)activate the main layer by selecting it in the Layers and Masters panel or de-selecting the Tools \> Edit Mask (Ctrl+H) command. You can also switch to the Mask layer and back to the main layer, by simply double-clicking the contours of the mask and outline. The editing area’s background color will change accordingly to display whether you are in the mask-editing mode or not.

If the option View \> Snap \> Mask is turned on, nodes on the main layer will snap to the contours on the Mask layer when they are moved. Similarly, nodes on the Mask layer will snap to the contours on the main layer when moved.