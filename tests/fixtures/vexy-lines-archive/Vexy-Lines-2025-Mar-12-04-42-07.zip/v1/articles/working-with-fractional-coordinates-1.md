## Metadata_Start 
## code: en
## title: Working with fractional coordinates 
## slug: working-with-fractional-coordinates-1 
## seoTitle: Working with fractional coordinates 
## description:  
## contentType: Markdown 
## Metadata_End

When you’re designing a font that has very thin strokes or very complex details, you can have “the best of both worlds”: integer nodes and fractional coordinates, like this:

1. In Contours \> Coordinates, turn off Round when Editing and Preview Rounding.
2. Turn on View \> Show \> Grid and View \> Snap \> Grid.
3. In Preferences \> Grid, set both Grid line distance entries to 1, keep Round nodes, guides and anchors to grid points on, and move the Grid lines opacity and Dots opacity sliders to the left. You may move both sliders all the way to the left or keep the grid dots slightly visible.

With this setup, the nodes, guides and anchors will snap to the 1-unit integer grid as you edit, but handle coordinates will remain fractional. At any point during design, you can choose Contour \> Coordinates \> Apply Rounding to round both nodes and handles to integers.

* To export the font to OpenType PS (.otf), customize the export profile and set Outline \> Round coordinates to UPM grid \> Keep fractional nodes and handles. FontLab will then optimize the placement of the handles so coordinates close to integers will become integer, coordinates close to 1/10 fractions of a font unit will export as single-digit decimal fractional coordinates, and other coordinates will export with 1/100 (two-digit) decimal precision. The overall size of the final OTF will only be a few percent larger than with all-integer coordinates, but will keep perfect curves.
* To export the font to OpenType TT (.ttf), customize the export profile and set Outlines \> Conversion tolerance \> Precise (larger file).

You can also increase the precision of both nodes and handles placement by setting Font Info \> Family Dimensions \> Units Per eM to a larger number such as 2000 or 4000. Both techniques can be combined.