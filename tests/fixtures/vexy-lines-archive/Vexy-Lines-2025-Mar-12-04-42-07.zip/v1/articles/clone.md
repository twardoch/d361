## Metadata_Start 
## code: en
## title: Clone 
## slug: clone 
## seoTitle: Clone 
## description:  
## contentType: Markdown 
## Metadata_End

The Clone feature in Strokes Maker is a powerful tool that allows users to create complex and harmonious fill compositions by cloning a base fill and modifying specific parameters. This unique type of fill maintains a connection with the source fill through its graphical representation, while still allowing for changes to be made to other parameters. The basic parameters of the original fill in clones are not available for editing.

For example, when using a linear fill, the interval parameters and line tilt angle in the fill will be preserved in the clone. However, other parameters such as offset, color, thickness, and more can be modified for the clone. This flexibility allows users to create unique variations and customized compositions without having to start from scratch each time.

One of the key advantages of using Clone in Strokes Maker is its ability to automatically update all clone fills when changes are made to the base fill. This ensures consistency and saves time for designers who want to make global adjustments to their compositions. Whether it's adjusting the angle of lines or changing the hand-drawn base curve, these modifications will be reflected across all clone fills, resulting in a harmonious and coordinated design.

In addition to its automatic update feature, Clone also offers a wide range of customization options for users. They can modify parameters such as offset, color, thickness, and more to create unique variations of the base fill. This allows for endless possibilities in terms of creating diverse and visually appealing compositions.

In conclusion, Clone is a powerful feature in Strokes Maker that allows users to create complex and harmonious fill compositions by cloning a base fill and modifying specific parameters. With its ability to automatically update clone fills when changes are made to the base fill, as well as its extensive customization options, Clone provides a versatile tool for designers looking to create visually stunning graphics.