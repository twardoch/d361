## Metadata_Start 
## code: en
## title: Tables panel Define custom OpenType tables 
## slug: tables-panel-define-custom-opentype-tables-1 
## seoTitle: Tables panel Define custom OpenType tables 
## description:  
## contentType: Markdown 
## Metadata_End

#### Tables panel: Define custom OpenType tables

The new Tables panel allows you to store, edit and export OpenType table definitions for arbitrary OpenType tables using the popular [TTX](https://github.com/fonttools/fonttools) syntax. The Tables panel is a convenient way to override the tables that FontLab exports by default (for example name or gasp), and/or to add tables to the exported font that FontLab does not support (for example MATH, BASE or meta).

Open an existing OTF or TTF and FontLab will decompile font tables except those listed in the Preferences \> Open Fonts \> Do not import these tables to Tables panel. Open Window \> Panels \> Tables to view the decompiled table definitions, to add or edit custom table definitions, to copy-paste them between fonts, and to enable some of the custom table definitions for export.

To add a definition for a new table, click +, double-click the XXXX table tag and type your desired table tag. Then input a valid TTX definition for that table in the editing area. To perform a basic verification of your custom table definition, select it and click Verify. To remove a table definition, click –.

To enable custom table definitions for export, turn on their checkboxes. Whenever you export a non-variable OpenType font (OTF or TTF), FontLab will override the tables it generates with enabled custom tables, and will add any enabled custom tables that are suitable for the format.

| :----- |
| Currently, FontLab will not write custom table definitions into OpenType Variations fonts. Also, if you are generating instances from a variable font, each custom table definition that you enable for export in the Tables panel will be exported into all instances. |

See the FontLab Help article about the [Tables panel](http://help.fontlab.com/fontlab-vi/Tables-panel/) for more info.