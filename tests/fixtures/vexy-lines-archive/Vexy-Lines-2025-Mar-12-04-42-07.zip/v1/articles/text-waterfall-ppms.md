## Metadata_Start 
## code: en
## title: Text waterfall PPMs 
## slug: text-waterfall-ppms 
## seoTitle: Text waterfall PPMs 
## description:  
## contentType: Markdown 
## Metadata_End

The sizes for text waterfall preview in the \[TrueType Hinting panel\](TrueType-Hinting-tooltruetype-hinting-panel)