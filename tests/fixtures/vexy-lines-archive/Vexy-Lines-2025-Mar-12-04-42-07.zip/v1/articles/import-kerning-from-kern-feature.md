## Metadata_Start 
## code: en
## title: Import kerning from kern feature 
## slug: import-kerning-from-kern-feature 
## seoTitle: Import kerning from kern feature 
## description:  
## contentType: Markdown 
## Metadata_End

If you’ve modified the kern feature or imported a kern feature definition from a .fea or .vtp file, or you have copied them from another font, you can now choose Font \> Kerning \> Import from \[kern\] Feature to convert that kerning into the current font master’s visual kerning. Then, you can edit the visual kerning in the Kerning mode of the Glyph window or in the Kerning panel.