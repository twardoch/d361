## Metadata_Start 
## code: en
## title: Quick Help 
## slug: quick-help-1 
## seoTitle: Quick Help 
## description:  
## contentType: Markdown 
## Metadata_End

Ever wondered: what does this button in FontLab do? FontLab 7 helps you discover its powerful user interface with the new Quick Help system.

* Move your pointer over a UI element and wait a bit: FontLab shows the yellow tooltip, known from most apps.
* Move your pointer over a UI element and hold F1: FontLab instantly shows a longer Quick Help tip. The Quick Help tips are more extensive and provide more detailed explanations. Much of the FontLab 7 user interface already has Quick Help tips, and we’ll be improving the system in upcoming builds. If you’re on macOS and System Preferences \> Keyboard \> Use F1, F2, etc. keys as standard function keys is off, hold Fn+F1, or turn that option on to use F1.

Tap F1 or Fn+F1 to turn on Quick Help mode. Now when you move the pointer around the user interface, Quick Help tips appear instantly so you can explore the descriptions. Tap F1 or Fn+F1 again to turn it off.

When you turn on Preferences \> General \> Show keystrokes, FontLab shows the keys you press, and also shows Quick Help tips in larger font —great for teaching, tutorials or presentations!

Tap Shift+F1 or Shift+Fn+F1 to show or hide Help \> Help Panel. When you open a dialog or click a panel, the Help panel shows descriptions for the active dialog page or panel. The Help Panel and Quick Help are complementary.