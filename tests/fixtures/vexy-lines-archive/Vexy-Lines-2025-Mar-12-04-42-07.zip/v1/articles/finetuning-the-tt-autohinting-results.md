## Metadata_Start 
## code: en
## title: Fine-tuning the TT autohinting results 
## slug: finetuning-the-tt-autohinting-results 
## seoTitle: Fine-tuning the TT autohinting results 
## description:  
## contentType: Markdown 
## Metadata_End

To start fine-tuning the TT autohinting results:

1\. Open a glyph in the Glyph Window.

2\. Choose Tools \> TrueType Hinting.

3\. In the Glyph Window Property bar, click the Stems stems\_icon.png button to open TT stems that have been copied from the PS standard stems. Editing the TT stems may have a significant impact on how consistent the appearance of different stems will display, especially in pure black-and-white rendering. For example, merging some stem values will result in a font in which the slightly different stems will appear more consistent.

4\. In the Glyph Window Property bar, click the Zones zones\_icon.png button to open TT zones that have been copied from the PS alignment zones.

One important parameter for TT stems is the ppm2 value. This value indicates the ppem size at which (mostly in black-and-white mode) the stems will turn from 1 pixel width to 2 pixels width. (The ppm3 entry indicates the ppem size at which the stems will turn from 2 pixels to 3 pixels width etc.).

Lowering those ppem values will result in the affected stems appearing heavier in small sizes. Raising those ppem values will result in the affected stems appear lighter in small sizes. For example, if you have a Medium style and a Semibold style in your family, and they look too similar at small point sizes, you may choose to decrease the ppm2 and ppm3 entries in the Semibold style (so it will appear heavier), and to increase them in the Medium style.