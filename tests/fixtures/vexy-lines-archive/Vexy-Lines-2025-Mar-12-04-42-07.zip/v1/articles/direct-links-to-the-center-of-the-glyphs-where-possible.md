## Metadata_Start 
## code: en
## title: Direct links to the center of the glyphs where possible 
## slug: direct-links-to-the-center-of-the-glyphs-where-possible 
## seoTitle: Direct links to the center of the glyphs where possible 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab can try to hint starting from the left sidebearing and going to the right or starting from both sidebearings and going to the center of the glyph. Use this option to customize the hinting direction.