## Metadata_Start 
## code: en
## title: Creating a glyph in an empty glyph cell 
## slug: creating-a-glyph-in-an-empty-glyph-cell 
## seoTitle: Creating a glyph in an empty glyph cell 
## description:  
## contentType: Markdown 
## Metadata_End

Creating new glyphs in empty cells