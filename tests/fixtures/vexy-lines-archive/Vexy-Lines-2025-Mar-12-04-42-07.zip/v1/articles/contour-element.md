## Metadata_Start 
## code: en
## title: Contour element 
## slug: contour-element 
## seoTitle: Contour element 
## description:  
## contentType: Markdown 
## Metadata_End

A Contour element is a collection of one or more closed or open contours built from PostScript and/or TrueType segments. This is the most common element type. It can also contain alignment objects: element guides and pins. The “inside” (i.e. the existing contents of a contour element) can be modified using the Contour tool, Eraser tool, Knife tool, or Scissors tool. New contours can be added to an element using the Brush tool, Pencil tool, Rapid tool, Pen tool, Ellipse tool and Rectangle tool.