## Metadata_Start 
## code: en
## title: Release Notes Archive 
## slug: release-notes-archive 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

# Release Notes Archive {: .uk-h5 }

!!! note

> Also see [[Release Notes]] for the [latest stable version](Release-Notes-Current) and the [latest beta versions](Release-Notes-Beta). [Download older](https://download.fontlab.com/) versions of FontLab if needed.

## FontLab 7

- [7.2.0.7649](Release-Notes-7649)

- [7.2.0.7644](Release-Notes-7644)

- [7.2.0.7622](Release-Notes-7622)

- [7.2.0.7614](Release-Notes-7614)

- [7.2.0.7608](Release-Notes-7608)

- [7.1.4.7515](Release-Notes-7515)

- [7.1.4.7511](Release-Notes-7511)

- [7.1.3.7495](Release-Notes-7495)

- [7.1.3.7493](Release-Notes-7493)

- [7.1.3.7478](Release-Notes-7478)

- [7.1.2.7436](Release-Notes-7436)

- [7.1.2.7435](Release-Notes-7435)

- [7.1.2.7432](Release-Notes-7432)

- [7.1.1.7383](Release-Notes-7383)

- [7.1.1.7382](Release-Notes-7382)

- [7.1.0.7363](Release-Notes-7363)

- [7.0.1.7276](Release-Notes-7276)

- [7.0.0.7264:](Release-Notes-7264)
  - [General, editing, anchors, actions, FontAudit, copy-paste](Release-Notes-7264-1)
  - [Metrics, kerning, Font window, Font Info, hints, guides, classes](Release-Notes-7264-2)
  - [Variation, imported artwork, components, auto layers, elements](Release-Notes-7264-3)
  - [Glyph names, OT features, text, layers, color, files, UI, Python, varia](Release-Notes-7264-4)
  - [Bug fixes](Release-Notes-7264-5)

## FontLab VI

- [6.1.4.7044](Release-Notes-7044)

- [6.1.4.7043](Release-Notes-7043)

- [6.1.3.7016](Release-Notes-7016)

- [6.1.3.7013](Release-Notes-7013)

- [6.1.2.6927](Release-Notes-6927)

- [6.1.1.6879](Release-Notes-6879)

- [6.1.1.6878](Release-Notes-6878)

- [6.1.0.6871](Release-Notes-6871)

- [6.0.9.6798](Release-Notes-6798)

- [6.0.8.6790](Release-Notes-6790)

- [6.0.7.6774](Release-Notes-6774)

- [6.0.7.6772](Release-Notes-6772)

- [6.0.6.6722](Release-Notes-6722)

- [6.0.5.6675](Release-Notes-6675)

- [6.0.4.6634](Release-Notes-6634)

- [6.0.3.6611](Release-Notes-6611)

- [6.0.2.6578](Release-Notes-6578)

- [6.0.1.6558](Release-Notes-6558)

- [6.0.0.6550](Release-Notes-6550)

