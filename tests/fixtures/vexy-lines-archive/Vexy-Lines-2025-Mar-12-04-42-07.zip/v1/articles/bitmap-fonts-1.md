## Metadata_Start 
## code: en
## title: Bitmap fonts 
## slug: bitmap-fonts-1 
## seoTitle: Bitmap fonts 
## description:  
## contentType: Markdown 
## Metadata_End

When your font does not have a ppm.NN layer and you export it into a bitmap font format (OpenType+sbix), all glyphs are rasterized at the PPM specified in Rasterize if needed. Choose 127 or less to export into the OpenType+CBDT format.