## Metadata_Start 
## code: en
## title: Build Names button 
## slug: build-names-button 
## seoTitle: Build Names button 
## description:  
## contentType: Markdown 
## Metadata_End

Press this button to automatically generate the Full name, PostScript name and Style group name fields. If you are creating a new font we recommend that you fill in the Family Name field, generate or manually fill in the Style name field and then press this button to create the Font and Full names.

!!! **Note**

The Build Names button doesn’t re-build the Style name (TSN) field.