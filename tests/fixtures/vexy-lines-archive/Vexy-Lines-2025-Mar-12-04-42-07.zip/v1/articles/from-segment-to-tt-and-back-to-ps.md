## Metadata_Start 
## code: en
## title: From Segment to TT and Back to PS 
## slug: from-segment-to-tt-and-back-to-ps 
## seoTitle: From Segment to TT and Back to PS 
## description:  
## contentType: Markdown 
## Metadata_End

To convert a segment to TrueType curve and back to PostScript curve, Alt-click the segment. In order to use this feature, the option Clicking outline selects segment must be off. Otherwise Alt-clicking selects the whole contour.