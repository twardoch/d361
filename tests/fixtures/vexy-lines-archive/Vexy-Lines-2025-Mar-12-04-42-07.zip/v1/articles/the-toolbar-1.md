## Metadata_Start 
## code: en
## title: The Toolbar 
## slug: the-toolbar-1 
## seoTitle: The Toolbar 
## description:  
## contentType: Markdown 
## Metadata_End

When you open FontLab 7 for the first time, the toolbar is at the left side of the screen. It can be placed anywhere and use vertical or horizontal forms. The toolbar presents the basic tools of FontLab 7 and also controls for what is seen when a glyph is edited.

![][toolbarhoriz-r]

Toolbar areas

| **Tools** | ⬉ | Contour | 🖌 | Brush | 🧲 | Magnet | 💕 | Matchmaker |
| :----- | :-----: | :----- | :-----: | :----- | :-----: | :----- | :-----: | :----- |
|  | ⬁ | Element | 🖉 | Pencil | ⬙ | Fill | 󰀓 | TT Hinting |
|  | 🇲 | Metrics | 🖋 | Pen | 📏 | Guides | ○ | Ellipse |
|  | Ꜹ | Kerning | 🖊 | Rapid | ⮎ | Rotate | □ | Rectangle |
|  | Ͳ | Text | 🔪 | Knife | ⭷ | Scale |  |  |
|  | 💊 | Eraser | ✄ | Scissors | ⌰ | Slant |  |  |
|  |  |  |  |  |  |  |  |  |
| **View controls** | 󰀗 | All nodes | 󰀙 | Curvature | 𝄜 | Grid | 󰀛 | Font Guides |
|  | 󰀘  | Coordinates | ☯ | FontAudit | 󰀚 | Glyph Guides | 󰀜 | Hints |

If you click on a tool button in Toolbar while Font Window is active, FontLab opens a new Glyph Window with the currently selected tool active.

For a complete description of each tool and view control, please consult the Application Tools chapter.

[toolbarhoriz-r]: toolbarhoriz-r.jpg width=513px height=40px