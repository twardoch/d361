## Metadata_Start 
## code: en
## title: FontLab VI and 7 Reviews 
## slug: fontlab-vi-and-7-reviews 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

> This baby is a rock-solid font development software, from design to engineering. If you’re coming from FontLab VI, 7 looks pretty familiar — but don’t let that fool you. I found myself toggling Quick Help obsessively, constantly finding new ways to optimize my workflow — and pretty fast!

> Drawing is a joy: FontLab has the best drawing tools I’ve ever seen, and they just got better! FontAudit keeps you in check, with new information and smarter corrections; the new views for masks and layers are a super-handy for designing multiple masters; and the nudging workflow is spot-on.

> Expressions and tags became my bread and butter: generate tags to keep you organized in one click, edit them to automate your kerning classes and OT features, copy your expressions to all of your masters with one click!

> Did I mention that FontLab 7 is a serious variable font production tool, with conditional glyph substitutions, table editing and all? To be honest, I wish I recorded my face when I saw the new axis graph!

> And hey, it’s running flawlessly on my Linux machine too!

— Fábio Duarte Martins, [Scannerlicker](http://fonts.scannerlicker.net/)

> If you want to make more fonts faster and better and if you want to stay ahead of the competition, go with FontLab 7. My favorite parts of FontLab are auto layers (set-it-and-forget-it for components letters), glyph masters (fine-tune the d, b, p, q, 6 and 9 between your masters without having to fix the exports!), FontAudit (quickly fix kinks in the intermediates).

> Using these features, I was able to create an average of 167 ornamental glyphs (in two weights) per day. By automating much of the grunt work, I think I’m doing some of the best work of my life.

—  Dave Lawrence, [California Type Foundry](http://www.californiatypefoundry.com)

> I’ll put it simply: FontLab 7 is superb!

> What’s not to love? The best vector engine for drawing and manipulation I have seen in ages. Rock-steady interpolation engine that is also compliant with variable OpenType fonts. Start with an excellent multi-paradigm approach to type design —  old-school outlines, element references, components, auto-generated glyphs, or all of them combined. Sprinkle on top a handful of nifty tricks to speed up your work like auto layers or auto OpenType feature generation. Combine that with a super powerful Python based API (that I actually use a lot). Let’s not forget multi-platform: a fact that I consider very important.

> The new FontLab is an endless ocean of opportunities — you get an app for every taste and workflow. I have been happily using FontLab VI and 7 on a daily basis for three years, and, to my great surprise, I still find new ways to work more efficiently. The learning curve is steep, but in FontLab 7, there is a new Quick Help system. Combined with the helpful support, it softens a lot one’s journey to mastery. Who said that type design should be easy? Although FontLab really tries to simplify the complexity. Many saw the FontLab VI roller-coaster development as a deal breaker. But I must say that the new FontLab 7 finally feels really mature. Don’t take my word for granted — it is obvious that I am a devotee. Just give it a try, and see for yourself!

— Vassil Kateliev, [Karandash type foundry](http://karandash.eu/), [The FontMaker](http://thefontmaker.com/) foundry, developer of [TypeRig](https://kateliev.github.io/TypeRig/)

> This application is top-notch: supports many font formats for import and export, the edit/drawing tools are refined and easy to use, and the developers are very responsive. Add to that a generous upgrade path, and FontLab VI is one of my favorite applications of all time.

— [Dylan-mc](https://www.macupdate.com/app/mac/3464/fontlab)

> I am truly blown away with FontLab VI. Coming from FontLab Studio 5, it has really ramped up my production time. Everything I wish FLS5 had is now available in FontLab VI!

— Charles Borges de Oliveira, designer of Desire and Sarah Script, [Borges Lettering & Design](http://www.borgeslettering.com/)

> No other type design software can match the speed and reliability of the drawing interface of FontLab VI.

— Ramiro Espinoza, designer of Barbieri and Medusa, [ReType Foundry](http://www.re-type.com/)

> I switched to FontLab VI about a year ago. It took me a month or less to feel that I definitely prefer working in it. It looks new and fresh, the interface is nice and precise. You use one window for everything — from glyph editing to testing the font in a long text — just by zooming and switching modes.

> What I like most is that you can link the metrics of glyphs to any other glyphs. It helps a lot when you design Cyrillic or Greek or make another style of the same font. It has handy tools for variations, and needs just a name of the typeface and style to generate working fonts! I’m so used to working in VI that it just seems natural.

— Alexandra Korolkova, lead designer of PT Sans, [ParaType](https://www.paratype.com/)

> There are a host of drawing tools in FontLab VI that all offer different ways to get an outline started. Once a basic outline is in, editing it is intuitive. Power Nudge cleverly adjusts locally related nodes in harmony to the one you’re editing.

> Features such as Tunni Lines and Smart Corners allow fluid control over the outline, whereas Make Overlap and Unlink Corners let you chop and change a shape easily. The flexibility of the drawing tools continues to impress.

— Jeremy Tankard, designer of Bliss and Corbel, [typography.net](https://typography.net/)

> I am a fan of “elements”. There are some very convenient and helpful aspects of the feature, and the underlying concept is a great innovation!

— Jonathan Patterson

> I asked for this, and Fontlab is delivering. Can’t get better customer relations than that.

— [Nate Piekos](http://www.blambot.com/)

> FontLab’s new ‘Tunni Lines’ are brilliant. Still the best vector curve editor out there by a mile.

— Sebastiaan de With (@sdw)

> I’m in love with FontLab. After spending some time tweaking my font it looks so much smoother and cleaner!

— Haley Martin (@NelmaThyria)

> I’ve spent some serious time with Fontlab VI this week, and I have to say, I like it!

— James Montalbano, Terminal Design Inc. (@TerminalDesign)

> I really like how the Change Weight algorithm works in FontLab VI

— ReType Foundry (@retypefoundry)

> The Font Audit tool (better Glyph Audit) is great!

— Jürgen Weltin ‏(@type_matters)

> I love that there is a Sketchboard in FontLab VI!

— Mads Davidsen (@mads199007)

> Fontlab VI kicked my expectations, it’s totally great! And even better!

— Petra Docekalova ‏(@docekalovapetra)

> FontLab VI looks great... Loving the new Live Pathfinding tool!

— Jeremy Swinnen ‏(@jereswinnen)

> OMG! I never wanted any software so much since Diablo 1. FontLab, this is amazing!

— Daniel Mizieliński (@hipopotam)

> FontLab VI looks jolly promising...

— Ben Mitchell (‏@OhBendy)

> Holy Serifs of Garamond, FontLab VI looks AMAZING

— Liam O’Connor (@liamoconnor22)

> I’m not a typographer, but I want this Bézier tool

— João Faraco ‏(@jpfaraco)

> The new FontLab looks so sexy that I’m really thinking about designing my own font

— Lan Pham ‏(@Lanooz)

> Fontlab got it #fontnerd

— @gr3g0rysm1th

> This is so damn sexy: FontLab VI

— Miguel A. Cardona Jr (‏@miggi)

> THIS looks like a solid FontLab upgrade!

— George Arriola (@arriola)

> This is AMAZING!

— Fin ‏(@finGoods)

> FontLab - Cool looking font editor

— Thomas Veit ‏(@TommyHoliday)

> Fontlab is coming back with FontLab VI and tons of impressive new features and finally a well designed UI

— Timothée Goguely ‏(@TimotheeGoguely)

> Wow, new FontLab is seriously awesome.

— Sasha Agapov ‏(@Agapov)

> This looks so powerful

— Duarte Fernandes ‏(@juiceboxfmspace)

> Amazing, Can’t wait to start using it on Win

— Otba Mushaweh ‏(@LogosGuide)

> There goes my month

— Arthur RF (‏@ArtArthus)
