## Metadata_Start 
## code: en
## title: Drawing Freehand 
## slug: drawing-freehand 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

[TOC]

FontLab gives you the tools to closely replicate the process of drawing freehand, like you would on paper. This can be achieved by using the following two tools:


## Using the Pencil tool


**To activate the Pencil tool**, select it in the toolbar or press the ++N++ key. With the [[Pencil tool]], you both draw new contours and edit existing ones. 

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-pencil_in_toolbar.png)

**To draw a contour**, click the mouse button where you want to start, drag the mouse as you would a physical pencil and release when you are finished. **To close the contour**, move the pencil back to the starting point to finish drawing. If you want **to stop drawing the contour without closing it**, release the mouse button at the location of your choice. 

**To draw a straight line**, hold down ++Alt++ while drawing. **To draw a horizontal or vertical line**, hold down ++Alt+Shift++ while drawing. You can use [[Fill tool]] ++F++ in the same way as described above to unfill any interior counters. 

With the Pencil tool, you can also edit an existing contour by adding or deleting from its edge. **To draw over an existing contour to add or delete from its edges**, first you need to turn on the ==Pen and Pencil tools can continue on a contour== option in the [Preferences](Preferences#pen-and-pencil-tools-can-continue-on-a-contour). In this mode, if you move the cursor of the Pencil tool over any node or outline of an existing contour, a blue cross will appear. If you begin drawing from this point, the new contour will be inserted into the existing contour. If both the starting and finishing points are on the same existing contour, then the new drawing will replace the part of the existing contour that lies between the start and end points of your new drawing:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-pencil_tool_03.gif)


## Using the Brush Tool


**To activate the Brush tool**, select it in the toolbar or press the ++B++ key. The Brush tool in FontLab works somewhat like the brush tool in any bitmap editing program. It can be used to draw strokes that resemble those drawn using calligraphic tools.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-brush_in_toolbar.png)

**To draw a stroke**, start by pressing down the mouse button, drag to draw, and finish by releasing the button. The results of your drawing depend on what options you have chosen in the Property bar before drawing. If you choose to draw **Simple Stroke**, it is converted into curves immediately after you finish drawing; on the other hand, if you draw a **Smart Stroke**, it gives you a skeleton on which a [[Power Brush]] filter can be applied. If you have drawn a simple stroke, you can refine the result using the [[Contour tool]]. In the case of a Smart Stroke, you can not only edit the stroke with the Contour tool, but also edit the size and shape of the brush applied to this stroke using the [[Property bar]] or [[Brush panel]].
