## Metadata_Start 
## code: en
## title: StdW vs 
## slug: stdw-vs 
## seoTitle: StdW vs 
## description:  
## contentType: Markdown 
## Metadata_End

#### StdW vs. StemSnap PostScript stems

OpenType PS (.otf) and Type 1 fonts define have two kinds of stems for each direction: one standard stem (horizontal StdHW and vertical StdVW) and a list of common stems (horizontal StemSnapH and vertical StemSnapV). The standard stem is often, but not always, included in the common stems list.  FontLab 7.2 makes the handling of these stems in Type 1, OpenType PS (.otf) and UFO more consistent.

[![][fl72-fontinfo-stems]](https://help.fontlab.com/fontlab/7/manual/img/fl72-fontinfo-stems.png)

Font Info \> Stems

When you open a Type 1 or an OpenType PS (.otf) font, FontLab names the stems:

* Hstem and Vstem if the StdHW/StdVW stem values are also found in the StemSnap list
* std.Hstem and std.Vstem if the StdHW/StdVW are not found in the StemSnap list, or if the StemSnap list does not exist

FontLab 7.2 now names the stem Hstem or Vstem if the stem is in StdHW/StdVW and in a single-entry StemSnapH/StemSnapV. Previously, FontLab incorrectly named such a stem std.Hstem/std.Vstem.

When you export fonts to Type 1 or OpenType PS:

* If a stem in Font Info \> Stems is named std.Hstem or std.Vstem, FontLab 7.2 now correctly exports it as StdHW/StdVW stems, but will not include it in the StemSnapH/StemSnapV list. If such a stem is the only stem in a given direction, FontLab does not write StemSnapH/StemSnapV at all. Don’t use the std. prefix unless you really want that behavior. Previously, FontLab did not export the std.Hstem/std.Vstem stems at all.
* If a stem is named Hstem or Vstem, FontLab exports it as StdHW/StdVW.  FontLab now includes it in StemSnapH/StemSnapV even if this stem is the only one stem in the given direction
* If a stem has a different name, FontLab includes it in StemSnapH/StemSnapV. If there is no stem with the names mentioned above, FontLab also puts the first stem in a given direction into StdHW/StdVW.
* If there is only one stem in a given direction, and the stem name does not have the std. prefix, FontLab includes it in StdHW/StdVW and StemSnapH/StemSnapV.

When you open an UFO, FontLab 7.2 now reads the standard stems from the postscriptStemSnapH and postscriptStemSnapV entries of fontinfo.plist. It gives the names Hstem and Vstem to the first entries. Previously, FontLab incorrectly named them std.Hstem and std.Vstem.

[fl72-fontinfo-stems]: fl72-fontinfo-stems.png width=319px height=281px