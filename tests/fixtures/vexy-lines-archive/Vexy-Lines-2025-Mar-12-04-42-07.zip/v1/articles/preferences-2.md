## Metadata_Start 
## code: en
## title: Preferences 
## slug: preferences-2 
## seoTitle: Preferences 
## description:  
## contentType: Markdown 
## Metadata_End

The **Preferences** panel allows the user to control the main settings of Strokes Maker.

* **Export** - select the export mode - filled shapes or zigzag mode
* **Source Opacity** - Transparency of the source image in the background
* **Ranges** - minimum and maximum values for adjustable parameters
* **Thickness** - minimum and maximum thickness values
* **Interval** - minimum and maximum interval values between curves in strokes
* **Terminal** - maximum length of the tip of a curve if the triangle type is selected for the tip
* **Colors** - highlighting colors of objects in the Strokes Maker workspace.
    * **Fill** - fill highlighting color.
    * **Mask** - mask highlighting color.
    * **Background** - document surface color.
* **Rendering** - optimization mode for previewing results for certain types of strokes, this parameter does not affect the quality of the exported result
    * **Fast** - fast result generation with slight quality reduction, can be used if there are a large number of dense strokes in the document
    * **Normal** - normal mode
    * **Best** - best quality rendering mode
* **Preview key** - shortcut key for previewing, all auxiliary objects, source images, and highlights are turned off, only the rendering result remains
* **Cmd+Space** - determines the zoom action for this hotkey.
    * **Dynamic Zoom** - dynamic zooming, when the combination is pressed, dragging the mouse to the right will increase the image relative to the starting point of the drag, and dragging to the left will decrease it.
    * **Frame Zoom** - the zoom area is determined by a frame that is created by dragging the mouse.
* **Backup**
    * **Save backup** - save the previous version of the document when saving, in a file with the same name but with the extension *.~strx
* **Save view** - save the parameters of the current viewing area in a file
* **Check update on startup** - check for updates when starting the program.