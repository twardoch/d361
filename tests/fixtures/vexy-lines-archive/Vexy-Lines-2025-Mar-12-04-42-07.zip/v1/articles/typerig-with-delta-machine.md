## Metadata_Start 
## code: en
## title: TypeRig with Delta Machine 
## slug: typerig-with-delta-machine 
## seoTitle: TypeRig with Delta Machine 
## description:  
## contentType: Markdown 
## Metadata_End

The [TypeRig](https://github.com/kateliev/TypeRig/) by Vassil Kateliev is a powerful extension package for FontLab 7. It includes TypeRig Panel, a floating side panel aimed at glyph and outlines manipulation; TypeRig Manager, a set of tools for editing various font-related parameters; and TypeRig Filter, assorted outline modifiers.

TypeRig now also includes Delta Machine, an advanced tool for adaptive outline scaling based on the research paper by Tim Ahrens [“A Multiple Master based method for scaling glyphs without changing the stroke characteristics”](https://remix-tools.com/pdf/Tim_Ahrens_MM_method.pdf), published in *Digital Creativity*, 19:2 (2008, 105-123, [DOI](https://doi.org/10.1080/14626260802037445). If your font already includes a Weight axis with at least two masters, you can use Delta Machine to create a variable Width axis, as well as small caps, superscript or subscript glyphs.

| :----- |
| TypeRig is free and opensource (BSD license). Run Scripts \> Update / Install Scripts to install the newest version of TypeRig. Currently, there is little to no documentation regarding using TypeRig and Delta Machine. We are working with Vassil to improve that. |