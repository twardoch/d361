## Metadata_Start 
## code: en
## title: Match Masters 
## slug: match-masters-1 
## seoTitle: Match Masters 
## description:  
## contentType: Markdown 
## Metadata_End

In Font window, when you turn on the sidebar and expand the Layers & Masters, the Mismatch filter shows all glyphs that have mismatching masters. Now, when you choose Glyph \> Match Masters to automatically make glyphs interpolable, FontLab instantly recalculates the Mismatch filter so you no longer need to click ↻ to re-calculate it manually.