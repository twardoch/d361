## Metadata_Start 
## code: en
## title: Pencil 
## slug: pencil-draft 
## seoTitle: Pencil 
## description:  
## contentType: Markdown 
## Metadata_End

The **Pencil** tool in **Strokes Maker** is a versatile feature that allows users to draw and edit individual strokes or curves. These strokes are then placed in the **Handmade** fill, which can be either an existing fill that has been selected or a new one that will be created.

To edit a stroke, users can simply click on it to select it. Only one stroke can be selected for editing at a time, and the last point of the selected stroke will be marked with a plus sign. To edit the stroke, users can drag it from a special point on the curve, represented by a small filled circle.

In addition to drawing curves, users can also add segments of straight lines to their strokes. This can be done by clicking anywhere on the canvas, which will add a new point to the currently selected stroke and create a straight line segment. Holding down the Shift key while clicking will ensure that the points are added strictly vertically or horizontally in relation to the last point of the stroke.

To close a stroke while drawing, users can either release the mouse button after dragging or click on the starting point of the curve. This action will create a closed shape, completing the stroke.

When the "Smooth" mode is enabled, smooth curves will be constructed. This mode helps to create curves with fewer anchor points and more fluid shapes. It is particularly useful for creating curves with a more organic and natural appearance. 

The Pencil tool in Strokes Maker provides users with a flexible and intuitive way to create and edit strokes. Whether drawing freehand strokes or adding straight line segments, this tool offers precise control over artwork. Users are encouraged to experiment with different techniques and explore the possibilities of the Pencil tool to unleash their creativity.

Furthermore, users can utilize various parameters and modes of the Handmade fill to achieve different effects based on the hand-drawn strokes. These strokes remain editable even after applying different fill options, allowing for further customization and refinement.