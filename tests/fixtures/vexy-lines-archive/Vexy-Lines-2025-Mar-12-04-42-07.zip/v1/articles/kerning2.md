## Metadata_Start 
## code: en
## title: Kerning-2 
## slug: kerning2 
## seoTitle: Kerning-2 
## description:  
## contentType: Markdown 
## Metadata_End

### Kerning

In the Glyph window Kerning mode, and in the Kerning panel of FontLab 7 you can visually define “typical” horizontal left-to-right pair-based kerning with classes. FontLab’s visual kerning is the same kerning model as used by most graphical font editors. A kerning pair consists of the 1st glyph or class, the 2nd glyph or class, and an adjustment value. You can assign glyphs to 1st and 2nd classes via Font \> Kerning \> Set Kerning Class or in the Classes panel. One glyph can only be in one 1st class and in one 2nd class. The adjustment value expresses the change of the advance width of the 1st glyph or class when it is followed by the 2nd glyph or class.

If you export a font that has such kerning into OpenType, FontLab compiles an OpenType kern feature and puts it into the GPOS table. It can optionally also include the legacy TrueType kern table which does not support classes. When FontLab opens an OpenType font, it decompiles the kern feature and tries to convert the OpenType kerning into visual kerning.