## Metadata_Start 
## code: en
## title: Comparing Fonts 
## slug: comparing-fonts-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

Sometimes you may need to compare two or more opened fonts. FontLab has a special command for that. It can check glyph sets of two fonts comparing glyph names. It also can analyze glyph contents to compare font designs.

For a visual comparison of glyphs present in multiple fonts, see [[Using Fonts and Font Map Panels]] and [[Overlaying Fonts]].


## Comparing Glyph Sets


**To compare font glyph sets**, select two or more fonts in the [[Fonts panel]] and choose the ==Font > Compare Fonts== menu command. The dialog with comparing results will appear:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Comparing_Fonts_1.png)

**To add missing glyphs** to the current font, make sure the corresponding option is turned on and click ==OK==. Use the ==Flag new glyphs== option to mark created glyph cells with color tag. As a result you should get the same number of glyphs in both compared fonts. New added glyph cells will be colored by the selected color.

!!! Note

> The ==Compare Fonts== command not only adds empty glyph cells, but also attempts to generate the glyphs that are being created. For example, if your font includes the basic Latin letters and some diacritic marks, and some accented Latin glyphs are added, they will be automatically generated with the appropriate [[Elements]] placed into the glyphs. You can switch this feature off in ==Preferences > Operations > New glyphs==.


## Comparing Font Designs


**To compare glyphs content**, select two fonts in the [[Fonts panel]] and choose the ==Font > Compare Fonts== menu command. The dialog with comparing results will show the percentage of fonts difference. The smaller the percentage the more similar fonts are.
