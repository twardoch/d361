## Metadata_Start 
## code: en
## title: Improved backups when saving files 
## slug: improved-backups-when-saving-files 
## seoTitle: Improved backups when saving files 
## description:  
## contentType: Markdown 
## Metadata_End

When you save a font, FontLab can create backup copies of the previously-saved versions of your working file. This has now been improved. In Preferences \> Save Fonts:

* If you set Existing font files to Rename and turn on the new Save backup files to subfolder setting, FontLab will create a subfolder named the same as your working file but with a .backup extension, and will save the backups inside that subfolder.
* If you set Existing font files to Rename and turn off Save backup files to subfolder, FontLab will behave like in previous versions, saving the backup files directly in your working folder.
* If you set Existing font files to Overwrite, FontLab will not create any backup files.