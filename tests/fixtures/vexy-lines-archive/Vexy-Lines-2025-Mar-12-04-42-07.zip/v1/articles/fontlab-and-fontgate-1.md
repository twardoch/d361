## Metadata_Start 
## code: en
## title: fontlab and fontgate 
## slug: fontlab-and-fontgate-1 
## seoTitle: fontlab and fontgate 
## description:  
## contentType: Markdown 
## Metadata_End

The [fontlab](https://fontlabcom.github.io/fontlab-python-docs/fontlab.html) package exposes most or all of the FontLab 7 GUI and high-level font-related objects. The [fontgate](https://fontlabcom.github.io/fontlab-python-docs/fontgate.html) package exposes more technical aspects of fonts, and does not include GUI functionality.

Some functionality is in fontgate, some in fontlab, but typerig abstracts and combines both packages. Both fontgate and fontlab are “bindings”, i.e. they’re not true Python packages, but instead interfaces that you can use from within Python.