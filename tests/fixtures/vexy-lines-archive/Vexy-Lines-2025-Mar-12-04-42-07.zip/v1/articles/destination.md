## Metadata_Start 
## code: en
## title: Destination 
## slug: destination 
## seoTitle: Destination 
## description:  
## contentType: Markdown 
## Metadata_End

In the lower-right part of the Export Font dialog, you can choose the destination where the target fonts will be saved. The destination consists of a base folder and optional subfolders.

Pick Source if you wish to export your fonts into the same base folder as your current source font is saved in, or pick Folder and Choose to select a custom base folder where your fonts will be exported.

You can also enable the Family and/or Profile checkboxes to help you organize your exported fonts.

If you select Family, FontLab will create a subfolder structure inside the base destination folder, based on the Family name of the source font as defined in \[Font Info dialog box\](Font-Info-Dialog-Boxnames) File \> Font Info \> Names. Choosing Profile will create a subfolder structure based on the name of the chosen \[export profile\](Export-Profiles). 

FontLab will automatically construct the filenames of exported fonts based on “best guesses”. You can use the Existing font files dropdown to decide what should happen if files with the same filename already exist in the destination folders.

Once you’ve chosen your export settings (profile, content and destination), click Export and FontLab will generate the target font files.