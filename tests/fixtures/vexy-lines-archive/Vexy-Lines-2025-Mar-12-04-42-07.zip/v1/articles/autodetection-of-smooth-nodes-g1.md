## Metadata_Start 
## code: en
## title: Auto-detection of Smooth nodes (G1) 
## slug: autodetection-of-smooth-nodes-g1 
## seoTitle: Auto-detection of Smooth nodes (G1) 
## description:  
## contentType: Markdown 
## Metadata_End

When you work with integer coordinates (i.e. Contour \> Coordinates \> Round when Editing is on), the resolution (density) of the coordinates is limited.

* When you declare a node Smooth, FontLab *tries to* place both handles of the node so that the direction (angle) of both handles towards the node is the same.
* When you declare a node Tangent, FontLab tries to place the handle on the curve side of the node at the same angle as the line side of the node.

If you place handles of a Smooth node or the handle and the line of a Tangent node diagonally (not vertically or horizontally) on integer coordinates, then the real angles on both sides of the node may be slightly different. If the distances from the Smooth node to both handles or from the Tangent node to the handle and opposite node are different, and especially if they are short, the angle difference may be quite large, so you get a weak smooth connection between the segments: *as smooth as the integer coordinates permit*, but not *truly smooth*.

FontLab 7.1 has detailed improvements when it classifies node connections as Smooth.

When you open OpenType fonts or when you perform certain operations that significantly change the contours (e.g. Remove Overlap, Flatten Glyph, Apply Smart Corner), FontLab performs *smooth auto-detection*: it checks which nodes it should classify as Smooth or Tangent. This happens the following way:

* When Round when Editing is off (so you work in fractional coordinates), FontLab sets the node connection to smooth (Smooth between two curve segments, Tangent between a curve and a line) if the angle difference is 1° or less.
* When Round when Editing is on (so you work with integer coordinates), FontLab is slightly more tolerant: it will also set the node connection to smooth if the node is *weak smooth* (as smooth as the integer coordinates permit).
* If the distance between the node and the handle is extremely short (2 font units or less), FontLab will not classify the node connection as smooth.

When you perform Contour \> Nodes \> Detect Smooth, FontLab is more tolerant than during smooth auto-detection. It will allow for slightly larger differences, and it will intelligently adjust the position of the nodes or handles. If one side of the node is perfectly horizontal or vertical, it will adjust the position of the other side. If it’s a node between a line and a curve segment, it will adjust the position of the handle. If it’s a node between two curve segments, it will adjust the position of the longer handle.

The Font Audit test Nearly smooth is even more tolerant.

* Remove Overlap has been improved to minimize contours distortion. 
* The Expand Stroke operation is improved to process thin strokes better.