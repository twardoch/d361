## Metadata_Start 
## code: en
## title: Grouping and Ungrouping Objects 
## slug: objects-group 
## seoTitle: Group 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:layersAddSection-->

In Vexy Lines, a group is a powerful tool that lets you bundle layers and even other groups. This is especially useful for organizing and managing your document, especially when dealing with numerous layers or groups.
<!--qh-->

Key benefits of using groups:
1. **Simplified Management:** Easily toggle the visibility of multiple layers or adjust their display order with a single action.
2. **Batch Operations:** Apply changes or transformations to several layers at once by targeting the group they belong to.
3. **Nested Grouping:** Groups can house other groups, enabling you to design intricate document structures for more advanced projects.

By leveraging groups, you can streamline your workflow and maintain a tidy workspace, even in complex designs.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-XVI85KK0.png){height="" width="227"}

<!--qh:layersAddSection-->

### Grouping Objects

To group multiple objects together:

1. Select the desired Layers and Groups you want to group.
2. Navigate to the menu **Layer -> Group**. Alternatively, you can quickly group them by pressing the ⌘G shortcut.

<!--qh-->

<!--qh:layersAddSection-->

### Ungrouping Objects

To ungroup a selected group:

1. Navigate to the menu **Layer -> Ungroup**.
2. Alternatively, use the shortcut ⇧⌘G.
<!--qh-->

<!--qh:layersAddSection-->

### Moving Objects Between Groups

You can move both Layers and Groups between different groups using the Layers panel. To do this:

1. Click and hold the desired Layer or Group with your mouse.
2. Drag it to the target group or to the root group of the document in the Layers panel.

| Starting to drag the 'Lips' group | 'Lips' group placed inside the 'Face' group |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-RN9ZAOOJ.png){height="" width="228"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-CC9IGS3R.png){height="" width="228"}|

> For more details on moving objects, refer to the article [here](/v1/docs/layers-2)

<!--qh-->

### Creating an Empty Group

You can create an empty group and populate it later. To create an empty group, go to **Layer -> New -> Group** (⌥⌘N) or use the button on the Layers panel.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-YHCM71JA.png){height="" width="247"}

The new group will be added to the document or to the previously selected group if one was highlighted.

<!--qh:layersAddSection-->

### Group's Source Image

In Vexy Lines, a group can have its own source image that it uses as a reference for rendering. If a group has an image and there are no images in its subgroups, then this main image will be used for all the fills within that group. This allows for consistent and accurate rendering based on the chosen image.
<!--qh-->

<!--qh:layersAddSection-->

### Creating a New Group with an Image

To create a new group that includes an image, follow these steps:

1. Go to the menu and select **Layer -> Add Source**.
2. In the dialog box that appears, choose the file with the desired image.
3. Confirm your selection and position the image within the document.
<!--qh-->
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-W1EX72RC.png){height="" width="1050"}
<!--qh:layersAddSection-->
4. Press ⏎ to confirm the image placement or press **Esc** to cancel the operation.
5. A new group will be created with the selected image.
<!--qh-->
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-2B3JCRHU.png){height="" width="1050"}

<!--qh:layersAddSection-->

### Adding a Group via Drag-and-Drop

Another way to create a group in Vexy Lines is by using the drag-and-drop method. Here's how:

1. Locate the image you want to use, for instance, in a folder on your computer.
2. Drag and drop the image into the Vexy Lines document.
3. An action dialog will appear.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-G2MJHE61.png){height="" width="196"}
4. Select **Add new group** and position the image within the document.
5. Press ⏎ to confirm the image placement or press **Esc** to cancel the operation.
6. A new group with the chosen image will be created.
<!--qh-->

<!--qh:layersAddSection-->

### Changing the Group's Source Image

If you want to change the source image of a selected group, follow these steps:

1. Use the **Layer -> Replace Source** command, or
2. Drag and drop a new image directly into the Vexy Lines document while the group is selected.
3. Follow the same steps as mentioned in the previous sections.
4. Once done, the original image in the group will be replaced with the new one, and the fills within the group will be updated accordingly.
<!--qh-->

<!--qh:layersAddSection-->

### Removing the Group's Source Image

To delete the source image from a group:

1. Select the image within the group.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-Q19WN9J1.png){height="" width="236"}
2. Click on the ![bin.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/bin.svg) button in the Layers panel or press the ⌫ or ⌦ key on your keyboard.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-EHSZZEA5.png){height="" width="236"}

### Importing Strokes

When you import an STRX file into your document, a new group will be created containing the objects from the imported file. To import an STRX file:

1. Go to the File menu and select **Import -> Strokes**.

2. In the file dialog that appears, select the desired file and confirm your choice.

3. A new group will be created with the name of the imported file as its title. The objects and group structure will match the contents of the file.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-66R1O6LC.png){height="" width="237"}

<!--qh:layersAddSection-->

### Group Mask Overlay

A group has an "Overlay" feature. When activated, any Overlay masks within the group will cover layers situated beneath this group. However, if the group's Overlay feature is turned off, the Overlay masks will only cover layers present within that specific group.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-WE6SLS5R.png){height="" width="237"}

>In the example above, there won't be any under-eye fillings because the Overlay property is enabled for the Eyes group.

<!--qh-->
$~$
For more details on the Overlay property, refer to the [Mask](/v1/docs/mask-2) article.

