## Metadata_Start 
## code: en
## title: Variation panel 
## slug: variation-panel-1 
## seoTitle: Variation panel 
## description:  
## contentType: Markdown 
## Metadata_End

If a variation axis has a small range such as 0–1, the Variation panel sliders now give you more resolution (two decimal places rather than one).