## Metadata_Start 
## code: en
## title: Fill and Preview 
## slug: fill-and-preview 
## seoTitle: Fill and Preview 
## description:  
## contentType: Markdown 
## Metadata_End

If you are in Element, Drawing or Editing mode, FontLab shows closed contours with a fill whose opacity can be modified in Preferences \> Glyph Window. Because you can control the opacity of the fill, you can view your contours with no fill at all, or with a fill of an opacity of your choice. In FontLab, you can also show open contours with a fill by selecting the option in Preferences \> Glyph Window. Since an open contour can’t really be filled, it is shown filled as if it has been closed by an invisible straight line that connects the starting and ending points of the contour.

The fill color depends on the element color. Unless you are working on a color font, the color of all elements, and consequently of the glyphs, will be black. In a color font, each element could be a different color.

While drawing or editing glyphs, you can choose to preview your outlines with an opaque fill. There are two ways to do this, each with its own advantages:

* using the View \> True Fill menu command or Shift+Space keyboard shortcut will render the interior of outlines as their full solid color (without the usual transparency effect), while other elements will remain visible;
* using the Space or Grave keyboard shortcuts will render outlines as they appear in printed text and suppress other screen information (such as the baseline, metrics, guidelines, etc.).

| :----- |
| In Metrics, Kerning and Text modes, contours are always shown with an opaque fill. Your chosen preference about open contours will be applied in these modes as well. So if you have not chosen open contours to be shown as filled, in these modes they would display as outlines only. |