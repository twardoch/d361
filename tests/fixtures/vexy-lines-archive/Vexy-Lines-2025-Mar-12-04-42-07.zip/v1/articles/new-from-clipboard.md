## Metadata_Start 
## code: en
## title: New from clipboard 
## slug: new-from-clipboard 
## seoTitle: New from clipboard 
## description:  
## contentType: Markdown 
## Metadata_End

The **New from clipboard** option in Strokes Maker lets users import images from their **clipboard**. It's a time-saving feature that quickly integrate raster images into new **Strokes Maker** document. This is great for those who often work with external sources and want to create new documents without saving the image as a separate file. With just a few clicks, users can generate a new document with the image from their clipboard, improving workflow and productivity.

1. Copy a raster image to your computer's clipboard.
2. Launch the **Strokes Maker** application.
3. Press "Control + Shift + Command + N" on your keyboard to open the wizard for creating a new document based on the raster image from your clipboard.
4. In the **New Document** dialog, select the option to import from clipboard or paste the raster image.
5. Click "**Ok**" to complete the setup process.
6. The imported raster image from your clipboard will now be displayed as a new document in **Strokes Maker**.
7. Proceed to edit and manipulate the vectors and strokes based on the imported image.