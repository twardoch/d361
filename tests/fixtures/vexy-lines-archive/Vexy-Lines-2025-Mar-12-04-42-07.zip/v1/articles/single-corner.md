## Metadata_Start 
## code: en
## title: Single Corner 
## slug: single-corner 
## seoTitle: Single Corner 
## description:  
## contentType: Markdown 
## Metadata_End

A simple click a corner node will break the contour in a special manner. The node will turn into two nodes, the contour will become an open contour, yet its filled/unfilled state won’t change; the fill is still controlled by the paint bucket (Fill tool).

!\[Scissors 4\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scissors\_4.gif)

The Scissors tool (K key) allows you to cut complex outlines into basic components with overlap, to make them easier to edit. For example, you can divide “H” into three overlapping rectangles, or detach the middle stem of “B” from its vertical stem. There are several different ways to use the Scissors tool.

[![][flvi-scissors_in_toolbar]](file:///Volumes/Igor/Fontlab/Manual/FontLabVI-help-master/docs/fontlab/7/manual/img/flvi-scissors_in_toolbar.png)

**Marquee select**

Click in empty space and drag around the area where stems are connected.

[![][flvi-scissors_1]](file:///Volumes/Igor/Fontlab/Manual/FontLabVI-help-master/docs/fontlab/7/manual/img/flvi-scissors_1.gif)

Scissors 1

[flvi-scissors_in_toolbar]: flvi-scissors_in_toolbar.png width=429px height=25px

[flvi-scissors_1]: flvi-scissors_1.png width=190px height=127px