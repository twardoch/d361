## Metadata_Start 
## code: en
## title: Drawing ellipses and rectangles 
## slug: drawing-ellipses-and-rectangles-1 
## seoTitle: Drawing ellipses and rectangles 
## description:  
## contentType: Markdown 
## Metadata_End

When you started to draw an ellipse or a rectangle at a sidebearing, FontLab used to move the sidebearing instead of drawing the contour. This no longer happens, but you can still move the sidebearing using the Spacing Controls triangles.

When View \> Suggest \> Stems is on, FontLab now suggests stem distances (defined in Font Info) as you draw with the Rectangle tool.