## Metadata_Start 
## code: en
## title: Propagated Fills 
## slug: propagated-fills 
## seoTitle: Propagated Fills 
## description:  
## contentType: Markdown 
## Metadata_End

<!--qh:customPropagation-->
In this filling technique, every contour you draw extends by a distance set by the Interval parameter, ensuring a uniform fill across the entire image. This method guarantees that the gap between individual contours is never less than the specified Interval value.
<!--qh-->
There are three types of connection to choose from: Miter, Bevel, and Rounded. 

- In Miter connection, contours expand in a square shape, utilizing strictly vertical and horizontal lines to form the four sides of a square.
- Bevel connection sees the contour lines radiate outwards into eight sectors, resembling an octagon.
- Round connection allows the contour lines to spread out in concentric circles, similar to ripples created by drops on water.

Each propagation type offers a unique aesthetic, allowing you to achieve the desired texture and depth in your artwork.


## Enable and Customize a Propagated Fill

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28330%29.png){height="" width="300"}

To enable the "Propagated" mode in the Handmade fill, please follow these steps:

1. Ensure that you have selected the Handmade fill type.
2. Navigate to the "HANDMADE FILL" tab.
3. Activate the propagation mode by clicking on one of the three **Propagated** buttons.

## Fill Parameters
![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28251%29.jpeg){height="" width="300"}

![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) **Interval** ([units](/v1/docs/units)): This setting allows you to adjust the distance between strokes. Decreasing the value will make the strokes closer together, while increasing the value will spread them out.

![Shift](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-middle.svg) **Shift** (%): 
Altering the "phase" of the fill pattern by displacing the initial stroke in a direction perpendicular to the initial strokes. 

<!--qh:customPropagation-->

![custom-sqare.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/custom-sqare.svg) **Miter**: create a propagation of strokes with miter connections.

![custom-hex.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/custom-hex%281%29.svg) **Bevel**: create a propagation of strokes with octogonal connections.

![custom-circle.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/custom-circle.svg) **Rouded**: create a propagation of strokes with smoother and more curved appearance.

<!--qh-->


### Interval
1. Locate the **Interval** ![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) parameter.
2. Use the slider or manually enter a value.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28337%29.png){height="" width="300"}

> Decreasing the intervals enhances the level of detail and darkens the image, whereas increasing the intervals lightens it but results in a loss of detail.

$~$

| interval: 1 | interval: 1.5 | interval: 2 |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28253%29.jpeg){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28335%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28334%29.png){height="" width="300"}|


### Shift
1. Locate the **Shift** ![Shift](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-middle.svg) parameter.
2. Use the slider or manually enter a value.
3. The **Shift** adjusts the phase of the fill pattern, affecting the position of the first stroke relative to its original position.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28343%29.png){height="" width="300"}


| shift: 15% | shift: 50% | shift: 75% |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28340%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28339%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28341%29.png){height="" width="300"}|

### Propagation type

1. Choose one out of three propagation types: **Miter**, **Bevel**, or **Rounded**.
2. Fills will be created based on the selected propagation type.


![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28344%29.png){height="" width="300"}

<!--qh:customPropagation-->

| square | octagonal | circle |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28351%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28349%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28350%29.png){height="" width="300"}|
<!--qh-->



























