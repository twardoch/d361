## Metadata_Start 
## code: en
## title: Glyph Substitution rules-1 
## slug: glyph-substitution-rules1 
## seoTitle: Glyph Substitution rules-1 
## description:  
## contentType: Markdown 
## Metadata_End

#### Glyph Substitution rules

Glyphs that have no Unicode in the font cannot get into the text directly (via keyboard, for example) but they may appear in the text when the app makes OpenType glyph substitutions. The rules for replacing particular encoded glyphs with their counterparts without Unicode are called \_features\_ and are defined in the font’s “GSUB” OpenType table. Glyphs in features are referenced by their names and indices.

The most common glyph substitution rules include:

\| Feature tag \| Description \|

\| calt \| Contextual Alternates \|

\| ccmp \| Glyph Composition / Decomposition \|

\| clig \| Contextual Ligatures \|

\| dlig \| Discretionary Ligatures \|

\| liga \| Ligatures \|

\| locl \| Localized Forms \|

\| onum \| Oldstyle Figures \|

\| rlig \| Required Ligatures \|

\| salt \| Stylistic Alternates \|

\| smcp \| Small Capitals \|

\| subs \| Subscript \|

\| sups \| Superscript \|

\| swsh \| Swash \|

\| zero \| Slashed Zero \|

| **Extension** | **Description** |
| :----- | :----- |
| ttf | TrueType, final font format with quadratic Bézier curves |
| otf | OpenType, final font format with cubic or quadratic Bézier curves |
| ufo | Flying objects from Serif planet studying why humans just use Helvetica |
| pfb | Type1, final font format with cubic Bézier curves |
| vfb | FontLab Studio 5, proprietary source format |
| woff | Web and also how D. Trump writes wolf. |
| woff2 | Web+ |
| glyphs | Glyphs editor, proprietary source format |
| designspace | \+UFO |

To define the glyph substitution rule in your font, use the Features panel. For example:

1\. Open the Features panel (Window \> Panels \> Features)

2\. Click the + button at the bottom of the list of features (pane on the left). A new feature named xxxx will appear in the list and a generic feature definition will be posted to the feature editor (pane on the right):

==

feature xxxx \{ 

\} xxxx;

==

3\. In the feature editor, change the name from xxxx to liga in order to define ligatures. The list on the left will be updated automatically. Do not forget to make the ending name the same as the beginning name or the feature definition will not compile.

4\. Edit the feature body with substitution commands each on its own line:

==

feature liga \{

sub f f l by ffl;

sub f f i by ffi;

sub f f by ff;

sub f l by fl;

sub f i by fi;

\} liga;

==

5\. Click the Features\_panel\_03.png button to compile the code. Note that your font must contain all glyphs mentioned in the code: f, l, i, ffl, ffi, ff, fl, fi.

6\. Check the Output panel for warnings and errors. If there is an error, the line will be highlighted in the feature definition code. Fix any errors. 

7\. When there are no errors, check the feature in the Glyph Window. Open the Contents sidebar, select the script and language and enter the test text using the Text tool.