## Metadata_Start 
## code: en
## title: Basic Operations 
## slug: basic-operations 
## seoTitle: Basic Operations 
## description:  
## contentType: Markdown 
## Metadata_End

*To insert a new node on a segment with the Contour tool* (A, ⬁)

1\.	Position the mouse cursor on the segment where you want to insert the node;

2\.	Ctrl+Alt-click where you want the node to be inserted or Shift+Ctrl+Alt-click a segment to add an extremum node to that curve segment.

*To insert one new node on a segment with the Knife tool* (J, 🔪)

1\.	Position the mouse cursor on the segment where you want to insert the node;

2\.	Click where you want the node to be inserted. On a straight segment you will get a sharp (corner) node; on a curve you will get a smooth node.

3\.	Shift+Ctrl+Alt-click a curve segment to add an extremum node.

*To insert several new nodes with the Knife tool* (J, 🔪)

1. Press the mouse button anywhere on the empty area of the editing field and drag the mouse to form a “knife line”;
2. Hold down the Shift key to constrain the direction of the “knife line” to 90-degree increments.
3. After you release the mouse button, new nodes will be added at all points where this line crossed the contour(s).

*To insert one new node on a segment with the Pen tool* (P, 🖋)

1\.	Position the mouse cursor on the segment where you want to insert the node;

2\.	Click where you want the node to be inserted. On a straight segment you will get a sharp (corner) node; on a curve you will get a smooth node.

The Rapid tool (5, 🖊)  can insert nodes on the same contour which it is currently drawing. Click a segment to add a sharp node or double-click to add a smooth node.

To add a handle to a sharp node using the Contour tool, press the Alt key, and drag a control point out of the node in the direction of the segment line:

(GIF)

*TruteType control points*

To add a TrueType control point using the Contour tool, press the Alt key and drag a new control point from the existing off-curve point. (FontLab will convert outlines and points as needed when you export a font, but editing TrueType as TrueType and PostScript as PostScript gives you maximum control over the output.)

You can also duplicate TrueType off-curve points the same way as on-curve points using Cmd+D / Ctrl+D.