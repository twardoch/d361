## Metadata_Start 
## code: en
## title: Edit Across Commands 
## slug: edit-across-commands 
## seoTitle: Edit Across Commands 
## description:  
## contentType: Markdown 
## Metadata_End

**TBA: capture, internal links**

The Edit Across Glyphs toggle in the Edit menu switches the Editing area to a mode when you can see and edit nodes of the current glyph only (other glyphs are not editable at the same time).

![][exclusive_1]

If you turn Edit \> Edit Across Glyphs on you will be able to see nodes and edit all glyphs in the string, frame or table.

![][exclusive_2]

One of the glyphs still looks different because it is the current glyph.

| :----- |
| If you use grid snapping, the current glyph defines the grid origin. The points in the other glyphs will snap to the grid of the current glyph, which may not be what you want. |

See Scope of Editing for information about *Edit Across Elements* and *Edit Across Layers*.

[exclusive_1]: exclusive_1.png width=219px height=190px

[exclusive_2]: exclusive_2.png width=219px height=190px