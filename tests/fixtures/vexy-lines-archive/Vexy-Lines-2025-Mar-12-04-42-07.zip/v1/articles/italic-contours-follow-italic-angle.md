## Metadata_Start 
## code: en
## title: Italic contours Follow Italic Angle 
## slug: italic-contours-follow-italic-angle 
## seoTitle: Italic contours Follow Italic Angle 
## description:  
## contentType: Markdown 
## Metadata_End

**Italic contours: Follow Italic Angle**

In the Glyph window, you can now tap \\ to make your up/down movements *italic* or upright. This turns on or off Contour \> Coordinates \> Follow Italic Angle:

* When it’s on, vertical Shift-dragging or using the ↑↓ keys moves nodes, selections, anchors, components and elements diagonally along the y-axis *slanted* by Font Info \> Font Dimensions \> Italic Angle.
* When it’s off, the movement is vertical.