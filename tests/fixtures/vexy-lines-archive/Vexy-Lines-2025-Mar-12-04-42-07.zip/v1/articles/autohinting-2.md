## Metadata_Start 
## code: en
## title: Autohinting 
## slug: autohinting-2 
## seoTitle: Autohinting 
## description:  
## contentType: Markdown 
## Metadata_End

![][autohinting-r]

The PostScript Autohinting options are as follows:

[autohinting-r]: autohinting-r.jpg width=362px height=301px