## Metadata_Start 
## code: en
## title: Handles 
## slug: handles 
## seoTitle: Handles 
## description:  
## contentType: Markdown 
## Metadata_End

Handles or control points are off-curve points. 

When dragging a curve to alter the curve segment, use the Shift key to maintain pre-existing angles of control handles on the curve. (This was a preference setting in FontLab Studio 5: All BCPs are fixed).

Under Preferences \> Glyph Window there is a middle Node Style option. When this option is selected, any node whose handles are aligned perfectly vertically or horizontally (or corner node whose adjacent line is almost vertical/horizontal) will be a darker solid color. Any node that does not meet such a test will be lighter and outlined. This helps identify points that are not quite where you intended, or are not quite proper extrema.

Visual appearance of nodes

As described above, smooth nodes are displayed as a green circle contours\_08.png, tangent nodes by a violet triangle contours\_09.png, and sharp nodes by a red square contours\_10.png. Further, the starting point of a contour is displayed as blue node with an arrow start\_point.png. Visual appearance of nodes, including their size, style and color, along with whether and how to display their coordinates can be changed in \[Preferences\](Preferencesglyph-window):

contours\_11.png

To display nodes in the same way as they are in Fontographer, change their color to black and white.