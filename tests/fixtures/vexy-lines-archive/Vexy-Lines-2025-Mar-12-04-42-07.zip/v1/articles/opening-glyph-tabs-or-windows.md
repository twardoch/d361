## Metadata_Start 
## code: en
## title: Opening Glyph tabs or windows 
## slug: opening-glyph-tabs-or-windows 
## seoTitle: Opening Glyph tabs or windows 
## description:  
## contentType: Markdown 
## Metadata_End

When you select many or all glyphs in the Font window, and you open a Glyph window (by tapping Enter, clicking one of the Toolbar buttons or choosing Window \> New…):

* If you’ve selected fewer than 5000 glyphs, FontLab will now open all selected glyphs in the Glyph window.
* If you’ve selected 5000 or more glyphs, FontLab will show a warning that opening so many glyphs in a Glyph window may slow down the app and offer you to open all selected glyphs or just the first 5000 glyphs.