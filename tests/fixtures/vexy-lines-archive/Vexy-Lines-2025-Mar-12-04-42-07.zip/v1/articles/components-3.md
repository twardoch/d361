## Metadata_Start 
## code: en
## title: Components 
## slug: components-3 
## seoTitle: Components 
## description:  
## contentType: Markdown 
## Metadata_End

When you add a component in a glyph layer at certain x,y position, FontLab creates a pointer to a *source glyph layer*. The source glyph layer can be the same layer of another glyph, a different layer of any glyph in the font, or an interpolated instance of any glyph. When you view a glyph layer that has a component, FontLab dynamically places the entire content of the source glyph layer so that the origin point (0,0) of the source glyph layer is placed at the x,y position of the component. A component always inherits the full content of its source glyph layer, including the placement, transformation, color and stroke.

A glyph that contains components is called a composite glyph. If a Font window glyph cell has an downwards-pointing light gray icon in the corner, the glyph layer is a *full composite* layer, so it only has components. If the icon is dark rouge, the glyph layer is a *partial composite* layer, so it has both components and other non-component elements.

[![][fl713-add-component]](https://help.fontlab.com/fontlab/7/alpha/img/fl713-add-component.png)

Glyph \> Add Component

With Glyph \> Add Component (Shift+Ctrl+A / Alt+Ins), you can add a component that points to the same layer of another glyph. In the Add Component dialog, you specify an additional x and y shift of the component, flip the component, choose to replace the advance width of the current glyph with the width of the component source glyph, and choose to add the component to the current master or all masters.

* In Font window, you can also Copy a glyph cell and then Edit \> Paste Components onto another glyph cell.

Once you have a component, when you click Show element properties and Expand properties in the Elements panel, you can set the Base layer name to point the component to another layer, or click Select component instance to make an interpolated component.

* When you double-click a component in the Glyph window, FontLab opens the source glyph for editing.
* If you edit the contours of the source glyph, its components in all composite glyphs are affected. If you move, scale, rotate or slant the contours or elements of the source glyph, the composite glyphs are affected. If you change the colors or stroke of the elements within the source glyph, the composite glyphs are affected.

Components inherit more information than element references. Element references only link the content of an element (contours or image) but each reference that links to the same element has its own independent placement, transformation, color and stroke.

Changes that you make to the composite glyphs don’t affect the source glyph of a component.

To replace a component with a full independent copy of the content, which you can then directly edit in the composite glyph, choose Glyph \> Decompose.

[fl713-add-component]: fl713-add-component.png width=320px height=250px