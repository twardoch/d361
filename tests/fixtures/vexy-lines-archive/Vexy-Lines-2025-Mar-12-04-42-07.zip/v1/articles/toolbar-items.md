## Metadata_Start 
## code: en
## title: Toolbar items 
## slug: toolbar-items 
## seoTitle: Toolbar items 
## description:  
## contentType: Markdown 
## Metadata_End

You can find the following buttons in the Toolbar:

\| Icon \| Tool Link \|

\| !\[Contour tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-contour.png \| Contour tool (A) for selecting, moving and editing points \|

\| !\[Element tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-element.png \| Element tool (V) for moving elements \|

\| !\[Edit Metrics tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-edit\_metrics.png \| Metrics tool (M) for editing metrics \|

\| !\[Edit Kerning tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-edit\_kerning.png \| Kerning tool (K) for editing kerning \|

\| !\[Text tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-text.png \| Text tool (T) for text keyboard input \|

\| !\[Eraser tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-eraser.png \| Eraser tool (Q) for removing non-extrema nodes or, with +Shift+, any nodes \|

\| !\[Brush tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-brush.png \| Brush tool (B) for drawing brush strokes \|

\| !\[Pencil tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-pencil.png \| Pencil tool (N) for creating and modifying contours freehand \|

\| !\[Rapid tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-rapid.png \| Rapid tool (5) for very quick drawing of smooth curves \|

\| !\[Pen tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-pen.png \| Pen tool (P) for drawing Bézier curves \|

\| !\[Knife tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-knife.png \| Knife tool (J) for adding nodes and slicing outlines \|

\| !\[Scissors tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-scissors.png \| Scissors tool (K) for disconnecting or opening contours \|

\| !\[Magnet tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-magnet.png \| Magnet tool (U) for attaching points to guides \|

\| !\[Fill tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-fill.png \| Fill tool (F) for filling or unwilling contours \|

\| !\[Guides tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-guides.png \| Guides tool (G) for measuring and adding short guides \|

\| !\[Match tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar\_matchmkr.png \| Matchmaker tool for semi-automatic masters matching and harmonization \|

\| !\[TrueType Hinting tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-hinting.png \| TrueType Hinting tool (Cmd+Shift+F7) for creating and modifying TrueType hints \|

\| !\[Ellipse tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-ellispe.png \| Ellipse tool (O) for drawing ellipses and circles \|

\| !\[Rectangle tool\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-rectangle.png \| Rectangle tool (I) for drawing rectangles and circles \|

\| !\[Show all Nodes\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-all\_nodes.png \| Show All Nodes View \> Show \> Nodes \|

\| !\[Show Coordinates\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-coordinates.png \| Show Coordinates View \> Show \> Coordinates \|

\| !\[Show Curvature\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-curvature.png \| Show Curvature View \> Show \> Curvature \|

\| !\[Show FontAudit\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-fontaudit.png \| Show FontAudit View \> Show \> FontAudit \|

\| !\[Show Grid\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-grid.png \| Show Grid View \> Show \> Grid \|

\| !\[Show Guidelines\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-guides2.png \| Show Glyph Guidelines View \> Glyph Guides \|

\| !\[Show Font Guides\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-toolbar-font\_guides.png \| Show Font Guidelines View \> Font Guides \|

\| toolbar-hints.png \| Show PostScript Hints View \> Show \> Hints \|

See the Tools page for information on activating tools using the keyboard.