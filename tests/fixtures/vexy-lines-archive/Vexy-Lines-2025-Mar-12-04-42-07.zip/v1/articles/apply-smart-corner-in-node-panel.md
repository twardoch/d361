## Metadata_Start 
## code: en
## title: **Apply smart corner** in **Node** panel 
## slug: apply-smart-corner-in-node-panel 
## seoTitle: **Apply smart corner** in **Node** panel 
## description:  
## contentType: Markdown 
## Metadata_End

![Apply smart corner](https://i.fontlab.com/fl8/rn/fl8-rn3-apply-smart-corner.png){ .r data-scale="33%"}

To convert a smart corner into final contours, activate the smart corner in the Glyph window, and then:

- either right-click the smart corner control point in the canvas and choose ==Apply Smart Corner==
- or click the ==Apply smart corner== button in the ==Node== panel