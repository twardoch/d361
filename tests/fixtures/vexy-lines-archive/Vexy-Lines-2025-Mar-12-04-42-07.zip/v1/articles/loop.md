## Metadata_Start 
## code: en
## title: Loop 
## slug: loop 
## seoTitle: Loop 
## description:  
## contentType: Markdown 
## Metadata_End

![Image](https://i.fontlab.com/fl8/rn/fl8-rn3-scissors-loop.gif){ .plain .r data-scale="66%"}

If all sub-tools of the ==Scissors== tool (++Q++) are turned off, ++Alt++-click a node to create a looped corner: FontLab unfills it if ==Font Info > Other Values > Unfill looped corners== is turned on, and if the loop is outside the filled area.

If the ==Loop== sub-tool on the toolbox is turned on, simple click on a node creates a looped corner, and modifier keys have no effect.

To create looped corners on several sharp nodes, select some segments or contours in Glyph window and choose ==Contour > Loop Corners==.
