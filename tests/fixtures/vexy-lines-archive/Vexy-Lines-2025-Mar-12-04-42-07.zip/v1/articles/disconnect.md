## Metadata_Start 
## code: en
## title: Disconnect 
## slug: disconnect 
## seoTitle: Disconnect 
## description:  
## contentType: Markdown 
## Metadata_End

![Disconnect](https://i.fontlab.com/fl8/rn/fl8-rn3-scissors-disconnect.gif){ .plain .r data-scale="66%"}

If all sub-tools of the ==Scissors== tool (++Q++) are turned off:

Click a node to unlink the node: FontLab breaks it, elongates the new end nodes slightly, and applies a Power Fill

Drag between or around two nodes, or drag around 4 nodes to make an overlap

If the ==Disconnect== sub-tool on the toolbox is turned on, clicks and drags work the same way, and modifier keys have no effect.
