## Metadata_Start 
## code: en
## title: Font Info panel 
## slug: font-info-panel-2 
## seoTitle: Font Info panel 
## description:  
## contentType: Markdown 
## Metadata_End

At the bottom of the Font Info *panel*, there are two more numeric values that are otherwise accessible via File \> Font Info \> Font Dimensions, and apply to the current font master:

* Corner is corner tension used in smart corners
* Ink Trap is ink trap width used in “negative” smart corners and with the new ink trap operation (Shift-click with Scissors tool)

The Font Info panel previously contained stem values and allowed you to auto-calculate the stem values. This implementation was inconsistent with the behavior of the Stems page in the Font Info dialog. We have decided to remove the stem info from the Font Info panel, and we recommend that you use File \> Font Info \> Stems.