## Metadata_Start 
## code: en
## title: Add a Mask 
## slug: adding-a-mask 
## seoTitle: Add a Mask 
## description:  
## contentType: Markdown 
## Metadata_End
A mask determines which parts of your fill are visible. Think of it as a stencil that controls where your artwork appears. You can add a mask to any layer, giving you precise control over your design.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-049QKBKS.png){height="" width="486"}


## Add a Mask

Select a layer in the **Layers panel** and use any of these tools from the toolbar:
![Brush tool](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/tool-mask-brush.svg) **Brush** (B): Paint your mask freehand
![Rectangle tool](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/tool-mask-rectangle.svg) **Rectangle** (I): Create rectangular masks
![Ellipse tool](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/tool-mask-ellipse.svg) **Ellipse** (O): Draw circular masks
![Freeform tool](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/tool-mask-freeform.svg) **Freeform** (S): Create custom mask shapes

When you add a mask, it appears next to the layer in the **Layers panel**. White areas of the mask show your fill, while black areas hide it.

## Working with Masks

You can create masks in three ways:
- **Draw** them manually using the tools above
- Click on objects to **auto-detect** their shapes

The **Rectangle**, **Ellipse**, and **Freeform** tools support smart auto-detection:
- **Click** to detect and replace the current mask
- **⇧ (shift)+Click** to add to the existing mask
- **⌥ (alt)+Click** to subtract from the mask

The next sections will show you how to use each mask tool effectively and how to fine-tune your masks for perfect results.