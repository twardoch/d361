## Metadata_Start 
## code: en
## title: Pairs & Phrases panel 
## slug: pairs-phrases-panel-2 
## seoTitle: Pairs & Phrases panel 
## description:  
## contentType: Markdown 
## Metadata_End

The Pairs & Phrases panel provides two types of text lists that consist of phrases:

* The Texts mode of the panel has a list of short texts (text phrases) that consist of a few words, useful when doing design, and especially useful when spacing.
* The Pairs mode of the panel has a list of words (pair phrases) with a marked kerning pair, useful when kerning. When you choose a pair phrase, the Glyph window activates the marked kerning pair so you can immediately adjust its kerning.

At the bottom of the panel, you can set the mode. If you choose Auto, the panel will switch to Pairs mode when the Glyph window is in Kerning mode, otherwise it will switch to Texts mode.

Use Fn+Cmd+↓/Fn+Cmd+↑ (Mac) or Ctrl+PgDn/Ctrl+PgUp (Win) to step through the phrases. When you go to the previous or next phrase, the phrase is shown in the current Glyph window. When the panel is open and Preferences \> Spacing \> Smart navigation with the up/down arrow keys is on, you can also step through the phrases with ↓/↑.

In FontLab 7, both the Texts and the Pairs mode can have multiple phrases lists. Click the new ☰ button at the bottom of the panel to switch between the lists.

[![][fl7-panel-pairs-list-selector]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-panel-pairs-list-selector.png)

Switch between multiple Pairs & Phrases lists

FontLab 7 also includes three built-in pairs lists that you can use to step through when kerning:

* Latin: a list of 1,000 Latin-script words with marked kerning pairs. The list has pairs for uppercase-uppercase, lowercase-lowercase, uppercase-lowercase and punctuation pairs. Each group is arranged by “kernability” of the pair — the most frequent pairs that commonly have large kerning values are listed first.
* Latin Extended: the same list, but each word is surrounded by pseudowords that show the 1st and 2nd glyph in the pair between regular letters (HOno).
* Cyrillic: a list of 700 Cyrillic-script words, arranged similarly to the Latin list.

[![][fl7-panel-pairs-list-editor]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-panel-pairs-list-editor.png)

Edit multiple Pairs & Phrases lists

In FontLab VI, you could click the Edit Pairs & Phrases button at the bottom of the panel. In the dialog, you could edit the Text or Phairs phrases list, open the list from a text file or save it. But at any given time, you could work with just one list of text phrases and one list of pair phrases. In FontLab 7, the Edit Pairs & Phrases dialog has a sidebar where you choose from multiple phrases lists, edit the contents of the list, or a new list from a plain-text file.

[fl7-panel-pairs-list-selector]: fl7-panel-pairs-list-selector.png width=212px height=170px

[fl7-panel-pairs-list-editor]: fl7-panel-pairs-list-editor.png width=263px height=243px