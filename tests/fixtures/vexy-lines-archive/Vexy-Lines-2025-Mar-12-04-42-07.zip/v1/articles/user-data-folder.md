## Metadata_Start 
## code: en
## title: User data folder 
## slug: user-data-folder 
## seoTitle: User data folder 
## description:  
## contentType: Markdown 
## Metadata_End

The user data folder is the main place where you can place customized data files. By default, the location is:

\~/Library/Application Support/FontLab/FontLab 7 on macOS

%userprofile%\\AppData\\Roaming\\Fontlab\\FontLab 7 or %userprofile%\\Application Data\\Fontlab\\FontLab 7 on Windows

You can relocate the user data folder using Preferences \> General \> User data folder. For example, if you work with a team and have a shared drive such as a network drive, Dropbox or Google Drive, all team members can relocate the user data folder to the same shared folder.

When you relocate the user data folder, you need to restart the app. The app does not copy the files from the old location to the new location. You need to copy the files yourself.

\_Note: By default the user data folder is the same as the local data folder on macOS. When you relocate the user data folder, the app will still autosave into the local data folder. This is a safety precaution: you may point the user data folder to a network drive, and it might become unavailable — but you still want the app to autosave.\_

The user data folder has the following subfolders:

* Codepage
* Data
* Encoding

You can place your customized data files there.