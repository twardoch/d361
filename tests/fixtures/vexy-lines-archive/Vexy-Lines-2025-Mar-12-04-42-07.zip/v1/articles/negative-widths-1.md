## Metadata_Start 
## code: en
## title: Negative widths 
## slug: negative-widths-1 
## seoTitle: Negative widths 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab 7.1.2 no longer allows the advance width to be negative. When you enter a negative value or an expression that results in a negative value, FontLab sets the advance width to 0.

Negative advance widths are not permitted in OpenType fonts, and exporting fonts that contained negative widths to OpenType failed.