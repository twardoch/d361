## Metadata_Start 
## code: en
## title: PostScript Hinting 
## slug: postscript-hinting-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

[TOC]

There are two hinting methods applied to OpenType-PS (Type 1) fonts: font-level hinting and glyph-level hinting. Font-level hinting is generated automatically in FontLab, so you don’t have to edit it manually. Glyph-level hinting is discussed here.


## Hints


![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-type_1_hinting_01.png)

All important stems in a glyph should have stem **hints**, a pair of vertical or horizontal lines. The information in the hint includes not just the position of each of the two lines that “build” the hint, but also the position of one (major) line and the width of the hint.

You can declare stem hints in FontLab just by dragging them and modifying their width. Because hints in FontLab are very “intelligent,” they automatically snap to the contour, minimising your work. In most cases the built-in autohinting algorithm produces good results – usually as good as the results of manual hinting.

### Autohinting

Autohinting is a good start before you manually add and edit PostScript hints.

**To automatically create PostScript hints** for the current glyph, choose the ==Tools > Autohint== (++F7++) command. **To automatically create PostScript hints for several glyphs**, select them in the Font Window and choose the ==Tools > Autohint== (++F7++) command. You can control whether autohinting will remove existing hints and convert hints to links on the [Autohinting](Preferences#autohinting) page of the **Preferences** dialog box.

### Editing Hints

Editing hints is very similar to editing [guidelines](Using-Guidelines). Hints are actually guidelines having width and marked as hints. Like guidelines hints can be locked, named, etc. In contrast to guides, hints cannot be slanted.

**To add a new hint:**

1. Create a guideline by dragging it out of the Glyph window’s Ruler, horizontal or vertical.
2. Define the width for the guideline by dragging it with the ++Shift++ key.
3. ++Ctrl++-click the guideline and choose **Hint** in the context menu or click the **Hint** button in the Property bar. The guideline will become the hint.

**To move a hint:**

1. Position the mouse cursor on the hint’s main (solid green) line.
2. Drag the hint to its new place. Both hint lines will move together.

**To change the width of the hint**, move the second hint’s (dotted green) line.

While you are dragging the hint and the mouse cursor is within the snap-to distance the hint line will stick to the node. Nodes must be visible.

While you are editing the hint, its parameters are shown on the [[Property bar]] and in the [[Guideline panel]].

Hint widths that correspond exactly to stem values defined in ==Font Info > Master Properties > Stems== are rendered bold on screen.

**To remove a hint**, select it and press ++Backspace++.

**To remove all PostScript hints in the current glyph**, select the ==Tools > Remove Hints== command.

**To remove all PostScript hints in several glyphs**, select them in the Font Window and choose the ==Tools > Remove Hints== command.

Note that **Remove Hints** also deletes links.


## Links


Stem hints are not connected to the outline. This allows you to use hints as pairs of guidelines while you work on an outline. But if you change the outline after hints are set you have to set all the hints again to reflect the outline changes. Another kind of stem hint, called a _link_, may help in this case.

Links connect two outline nodes, using the position of the nodes and the distance between them, to define a stem hint. If you move one of the nodes connected by a link the link will automatically reflect the changes. Links can also be either vertical or horizontal:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-type_1_hinting_02.png)

Links are extremely useful when you are working with [variable fonts](Variable-Fonts). In these fonts each point has several “layers”, called masters, which represent different styles of the font. If you try to set hints in variable fonts, you will have to manually define the hints’ positions in each master. But with links you can just connect two outline nodes and hints will be generated automatically for each master when you export your font.

### Editing Links

Links are hints connecting nodes. The only way to edit links is to connect them to different nodes of the outline.

**To add a new link:**

1. Select two nodes.
2. Choose the **Add New Horizontal (or Vertical) Hint** command in the ==Tools== menu.

The hint will appear linking two nodes:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-type_1_hinting_03.png)

**To turn a hint into link:**

1. Drag the base hint’s line (solid green) to the node until it snaps to it.
2. Drag the second hint’s line (dotted green) to another node until it snaps to it.

**To turn all hints into links** for the current glyph, choose the ==Tools > Hint To Links== menu command.

**To turn a link into hint (to unlink hint from nodes),** ++Ctrl++-click the link and use the **Unlink** command in the context menu.

**To remove all links in the current glyph**, select the ==Tools > Remove Hints== command.

**To remove all links in several glyphs**, select them in the Font Window and choose the ==Tools > Remove Hints== command.

Note that **Remove Hints** deletes both links and hints.


## Hinting Actions


Hints transformation actions let you automate some hinting operations. To open the **Actions** dialog, select the ==Tools > Actions== menu command.

### Autohint

Analyzes a glyph’s outline and generates PostScript hints for the glyph. This is the ==Tools > Autohint== command.

### Remove hints

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Hinting_actions_01.png)

This action removes horizontal and/or vertical PostScript hints and links.
