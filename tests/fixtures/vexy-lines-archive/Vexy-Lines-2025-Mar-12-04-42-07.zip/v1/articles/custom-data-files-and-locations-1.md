## Metadata_Start 
## code: en
## title: Custom data files and locations 
## slug: custom-data-files-and-locations-1 
## seoTitle: Custom data files and locations 
## description:  
## contentType: Markdown 
## Metadata_End

When you run FontLab, it loads various resources (data files): encodings, codepage definitions, glyph generation recipes, mapping tables, Python scripts etc. FontLab has these data files bundled, but it first looks in additional locations (folders) for data files you may have customized. Only if there are no customized data files, it loads its own bundled resources. See below for the locations of the data folders, in the order in which the apps looks inside them.

The following symbols are used to indicate special locations:

\~ is your user home folder on macOS, typically /Users/USERNAME

%userprofile%is your user home folder on Windows, typically C:\\Users\\USERNAME

Whenever a location is given here, you can copy it, and then:

in macOS Finder, choose Go \> Go to Folder…, paste the location and click Go

in Windows File Explorer, paste the location into the location text field and press Enter

| **macOS** | **Windows** |
| :----- | :----- |
| Shift | Shift |
| Cmd | Ctrl |
| Opt | Alt |
| Ctrl | Ctrl+Alt+Shift |