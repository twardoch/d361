## Metadata_Start 
## code: en
## title: Choosing new export options 
## slug: choosing-new-export-options 
## seoTitle: Choosing new export options 
## description:  
## contentType: Markdown 
## Metadata_End

To choose new options during exporting a font in one of the available \[export formats\](Font-Formatsfinal-font-formats), select the File \> Export Font As menu command. The following Export dialog box will appear as a result:

export\_fonts\_as\_02.png

In this dialog, you can choose the \[final export format\](Exporting-OptionsFont-formats), what \[font content you would like to export\](Exporting-OptionsFont-content), and the \[destination\](Exporting-OptionsDestination) of the exported font.