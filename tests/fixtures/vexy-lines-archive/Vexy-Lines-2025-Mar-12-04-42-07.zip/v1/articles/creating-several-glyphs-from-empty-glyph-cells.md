## Metadata_Start 
## code: en
## title: Creating several glyphs from empty glyph cells 
## slug: creating-several-glyphs-from-empty-glyph-cells 
## seoTitle: Creating several glyphs from empty glyph cells 
## description:  
## contentType: Markdown 
## Metadata_End

To create several glyphs at the same time, you need to first select multiple glyph cells, which can be done in several ways:

* Hold Shift and press Return or double-click the selection to create glyphs for all selected cells.
* Hold Shift and select the Font \> Generate Glyphs menu command. See Generate Glyphs for details.
* Select the Font \> Add Glyphs menu command to add several Unicode glyphs at once. See Add Glyphs for details.

And then press Return.