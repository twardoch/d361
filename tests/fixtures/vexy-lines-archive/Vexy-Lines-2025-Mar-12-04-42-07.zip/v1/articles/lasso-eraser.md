## Metadata_Start 
## code: en
## title: Lasso eraser 
## slug: lasso-eraser 
## seoTitle: Lasso eraser 
## description:  
## contentType: Markdown 
## Metadata_End

If all sub-tools of the ==Eraser== tool are turned off, ++Alt++-drag on canvas to “draw” a freeform selector, release the mouse button to remove all nodes inside that selector. Hold ++Shift++ to keep key nodes.

![Image](https://i.fontlab.com/fl8/rn/fl8-rn3-eraser-lasso.gif){ .plain .r data-scale="66%"}

If the ==Eraser > Lasso eraser== sub-tool is turned on, simple dragging with optional ++Shift++ works as described above, and other modifier keys have no effect.
