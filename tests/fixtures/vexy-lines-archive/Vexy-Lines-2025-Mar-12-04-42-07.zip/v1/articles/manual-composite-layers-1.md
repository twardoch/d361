## Metadata_Start 
## code: en
## title: Manual composite layers 
## slug: manual-composite-layers-1 
## seoTitle: Manual composite layers 
## description:  
## contentType: Markdown 
## Metadata_End

To re-use existing shapes in your font, you can build a *manual composite layer* by adding components into a layer. This can be a *full composite* layer if it only contains components, or a *partial composite* layer if it mixes components with other types of elements, including simple contours. You can position any component directly by settings its *x, y* coordinates, or you can use *corresponding anchors* to position the component in relation to another component. A base anchor with any name corresponds to a mark anchor with the same name prefixed by \_.

For example, if the a base glyph has an anchor named top, and acutecomb mark glyph has an anchor named \_top, then these anchors correspond. When you build the aacute glyph those two components, the a component is placed at the origin (*0,0*), and the acutecomb component is moved so that its \_top anchor snaps to the position of the top anchor in the a glyph.

To create a *manual composite layer*, you can use Font \> Generate Glyphs (and turn Create auto layers off), or you can use Glyph \> Add Component. When Preferences \> Operations \> Add components is on and create auto layers is off, FontLab will also try to create a manual composite layer if you’re creating a new glyph in the Font window or via Font \> Add Glyphs. You can use the anchors to position the components in all these situations — but once the components have been added, you can change their position freely. Moving the anchors in the component sources no longer affects the position of components in composite glyphs.