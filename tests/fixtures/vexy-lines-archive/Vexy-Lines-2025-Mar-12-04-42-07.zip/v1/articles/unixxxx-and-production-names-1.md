## Metadata_Start 
## code: en
## title: uniXXXX and Production names 
## slug: unixxxx-and-production-names-1 
## seoTitle: uniXXXX and Production names 
## description:  
## contentType: Markdown 
## Metadata_End

When you export your font into OpenType, the glyph names should follow a stricter convention so that the font works well in all environments. This convention is called uniXXXX: if a glyph is the default representation of a Unicode BMP character U+XXXX, use the name uniXXXX, and if it represents a non-BMP character U+XXXXX, use uXXXXX, where X is an uppercase hex digit (0-9 and A-F). For non-default forms and ligatures, you can use the AGL rules (hyphens are disallowed).

Unicode 12 includes 137,929 characters. 70% of them are Chinese, Japanese and Korean idegraphs, which leaves more than 40,000 characters that belong to various other writing systems, as well as symbols or different sorts. For about 600 of those Unicode characters, the Adobe [AGLFN](https://github.com/adobe-type-tools/agl-aglfn/blob/master/aglfn.txt) list provides more human-readable names, for example, for Á, you can use Aacute or uni00C1. The AGLFN names and the uniXXXX names together are called Production names. Any shipping OpenType font should use either Production or uniXXXX names, though in TrueType- and CFF2-flavored OpenType fonts, you can also not use any glyph names at all.

In development sources (VFC, VFJ, UFO etc.), you can use any names that follow the AGL rules, but don’t need to follow the stricter uniXXXX or Production conventions. But this still keeps the question open: which names, precisely, should I use?