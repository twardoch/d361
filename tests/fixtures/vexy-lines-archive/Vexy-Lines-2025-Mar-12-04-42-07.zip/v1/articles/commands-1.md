## Metadata_Start 
## code: en
## title: Commands 
## slug: commands-1 
## seoTitle: Commands 
## description:  
## contentType: Markdown 
## Metadata_End

The Commands dialog can be used to assign keyboard shortcuts to menu commands, and to execute commands.

To find a command, type its name in the Search field. Note that this dialog only shows seventy-five commands, so not every command is visible by default.

To define a new keyboard shortcut, select the command in the list and position the cursor on the editing field below the list. When the caret is in position in the field, press the combination of keys that you want to assign. A description of that combination will appear in the editing field, and you can click the Set button to assign that combination to the currently selected command. If that keyboard shortcut you have entered is already being used for another command, that command’s name will appear under the editing field in red, and the Set button will appear disabled. The button will also be disabled if you only press a single key. 

To remove the existing keyboard shortcut for a command, select the command in the list, and click Clear.

To reset all FontLab keyboard shortcuts to factory defaults, click the ☰ menu button and select Reset Shortcuts. 

To import keyboard shortcuts, click the ☰ menu button and select Import Custom Shortcuts…. A standard Open dialog will appear where you can choose the appropriate file to import.

To export keyboard shortcuts, click the ☰ menu button and select Export Custom Shortcuts…. A standard Save dialog will appear. Note that exported keyboard shortcuts are saved in a JSON file.

To save changes and close the dialog, click Close in the dialog.

To save the changes and also execute the selected command, click Go or press ↩.