## Metadata_Start 
## code: en
## title: Clicking outline selects segment 
## slug: clicking-outline-selects-segment 
## seoTitle: Clicking outline selects segment 
## description:  
## contentType: Markdown 
## Metadata_End

Turn this option on if you would like to be able to select a segment by clicking the outline. When this option is off, you can still select a segment by Shift-clicking it.