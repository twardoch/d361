## Metadata_Start 
## code: en
## title: Duplicate nodes 
## slug: duplicate-nodes-3 
## seoTitle: Duplicate nodes 
## description:  
## contentType: Markdown 
## Metadata_End

When a glyph layer has duplicate nodes (two consecutive nodes at the same coordinate), FontLab shows a red rhombus indicator. Duplicate nodes are not necessarily an error, especially if you work with multiple masters — in some masters, you may put two nodes on top of each other, and in other masters, you may move them apart.

[![][fl72-duplicated-node]](https://help.fontlab.com/fontlab/7/manual/img/fl72-duplicated-node.png)

Duplicated node

1. FontLab 7.2, the rhombus indicator is slightly smaller.

[fl72-duplicated-node]: fl72-duplicated-node.png width=200px height=75px