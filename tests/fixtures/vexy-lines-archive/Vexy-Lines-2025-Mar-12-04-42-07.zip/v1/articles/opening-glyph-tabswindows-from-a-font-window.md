## Metadata_Start 
## code: en
## title: Opening Glyph tabswindows from a Font window 
## slug: opening-glyph-tabswindows-from-a-font-window 
## seoTitle: Opening Glyph tabswindows from a Font window 
## description:  
## contentType: Markdown 
## Metadata_End

#### Opening Glyph tabs/windows from a Font window

When you select many or all glyphs in the Font window, and you open a Glyph window (by tapping Enter, clicking one of the Toolbar buttons or choosing Window \> New…):

* If you’ve selected fewer than 5000 glyphs, FontLab will now open all selected glyphs in the Glyph window.
* If you’ve selected 5000 or more glyphs, FontLab will show a warning that opening so many glyphs in a Glyph window may slow down the app and offer you to open all selected glyphs or just the first 5000 glyphs.

Previously, FontLab only opened the first 200 selected glyphs in the Glyph window.