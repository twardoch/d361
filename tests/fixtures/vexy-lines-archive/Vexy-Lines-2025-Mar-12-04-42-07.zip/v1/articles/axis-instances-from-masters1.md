## Metadata_Start 
## code: en
## title: Axis instances from masters-1 
## slug: axis-instances-from-masters1 
## seoTitle: Axis instances from masters-1 
## description:  
## contentType: Markdown 
## Metadata_End

#### Axis instances from masters

When you have some variation axes defined, you can add *axis instances* in Font Info \> Axes. FontLab uses these to create the STAT table in variable fonts, and you can use them in Font Info \> Instances to build a long list of predefined instances that is a combination of axis instances for all axes.

To build axis instances, click ☰ and choose:

* From Axis Graph: builds axis instances from the graph points defined in the axis graph; use the axis graph to creatte a mapping of custom design locations to standardized user locations for the Weight axis, then use this to create corresponding axis instances
* From Instances: builds axis instances from predefined Font Info \> Instances; this is handy for a single-axis font where you define the instances in the Instances page, and then build axis instances from them so that they’re included in the STAT table
* From Axis Defaults: builds axis instances from definitions of common axes that are built into FontLab; use this as a starting point for your axis instances, edit them; note that your axis instances should not exceed the locations of the masters
* **NEW** From Masters: builds axis instances from all unique locations of existing masters on the axis; use this as a starting point, give the axis instances correct names, and add intermediate axis instances between the master locations 

After using one of those automated ways to build axis instances, edit the names as needed. If an attribute name uses multiple names, surround the name with ". Surround the name with () and the name will be marked as “elided” in the STAT, and FontLab will skip it when you build names of predefined instances from axis instances.