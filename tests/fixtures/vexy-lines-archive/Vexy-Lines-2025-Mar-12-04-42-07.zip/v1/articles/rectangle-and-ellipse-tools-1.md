## Metadata_Start 
## code: en
## title: Rectangle and Ellipse tools 
## slug: rectangle-and-ellipse-tools-1 
## seoTitle: Rectangle and Ellipse tools 
## description:  
## contentType: Markdown 
## Metadata_End

If you use the Rectangle or Ellipse tool to draw a new contour in an existing contour glyph, FontLab makes the contour direction of the new contour compatible with the existing contours, so if the glyph has contours that go in the PostScript (CCW) direction, the new rectangle or ellipse will also have that direction, and if the existing contours go in the TrueType (CW) direction, same goes for the new rectangle or ellipse.

When you hold Cmd (Mac) or Ctrl (Win) as you draw the rectangle or ellipse, the contour gets the opposite direction, so it visually cuts out the existing contour.

However, in previous versions, if you used Rectangle or Ellipse in a blank glyph, the contours would get the TrueType direction —so if you copy-pasted them into an existing glyphs with PostScript contours and direction, you’d get the cutouts. FontLab 7.1.1 changes that— when you draw in a blank glyph, the contours will have the PostScript (CCW) direction (or the opposite with you hold Cmd/Ctrl). This is better for most users who draw using PS curves.