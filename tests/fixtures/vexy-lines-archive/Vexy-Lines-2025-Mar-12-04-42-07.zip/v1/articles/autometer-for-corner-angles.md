## Metadata_Start 
## code: en
## title: Auto-meter for corner angles 
## slug: autometer-for-corner-angles 
## seoTitle: Auto-meter for corner angles 
## description:  
## contentType: Markdown 
## Metadata_End

If the ==Guides== tool is active, and the zoom level of the window is close enough, the Glyph window shows the angles of corner nodes measured by Auto-meter.
