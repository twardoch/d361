## Metadata_Start 
## code: en
## title: Swap with Mask 
## slug: swap-with-mask 
## seoTitle: Swap with Mask 
## description:  
## contentType: Markdown 
## Metadata_End

Use the Tools \> Swap with Mask (Ctrl+Alt+M) command to exchange the contents of the main layer and the Mask layer.