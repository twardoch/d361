## Metadata_Start 
## code: en
## title: Sharpen 
## slug: sharpen 
## seoTitle: Sharpen 
## description:  
## contentType: Markdown 
## Metadata_End

This filter makes the image sharper and higher contrast. It is the opposite of the Soften filter.

![][image_panel_02]  ![][image_panel_03]

[image_panel_02]: image_panel_02.png width=61px height=62px

[image_panel_03]: image_panel_03.png width=62px height=59px