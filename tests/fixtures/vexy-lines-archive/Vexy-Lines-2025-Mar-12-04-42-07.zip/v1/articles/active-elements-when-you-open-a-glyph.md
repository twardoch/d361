## Metadata_Start 
## code: en
## title: Active elements when you open a glyph 
## slug: active-elements-when-you-open-a-glyph 
## seoTitle: Active elements when you open a glyph 
## description:  
## contentType: Markdown 
## Metadata_End

☆ When you open a glyph in a Glyph window that doesn’t have a stored selection, FontLab will no longer automatically make a component or the first locked element active. So when you open a composite glyph, no component is active by default. You can click a component, or use the \< or the \> key, to select the first component and iterate through the other components.

FontLab will by default make the first unlocked element active, which typically is the default element that holds the glyph’s contours.