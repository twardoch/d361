## Metadata_Start 
## code: en
## title: Geometric transformations 
## slug: geometric-transformations-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

[TOC]

Transformations done to the geometry of your glyph drawings (scale, slant, rotate and flip/mirror) are called **geometric transformations**. FontLab has a variety of ways in which you can apply transformations to the glyphs. 


## Contour-level vs. element-level transformation


FontLab can apply geometric transformations on two levels: the element level or the contour level. 

### Element-level transformation

- Element-level transformations are performed on entire [[Elements]]. 
- You transform the **element box** itself, not the contents of the element box. 
- The node coordinates inside the element remain untransformed. 
- Transformations applied on the element level are non-destructive.
- They are visible and editable in the ==Elements== panel. 
- The references to this element remain unaffected (the transformation is only visible in the glyphs where it was applied). 
- In the ==Gallery== panel, elements appear untransformed. 
- You can use ==Element > Expand Transformation== to convert an element-level transformation to a contour-level transformation. 

### Contour-level transformation

- Contour-level transformations are performed on [[Contours]]. 
- Every contour is part of some element (they’re the contents of an element box), but in contour-level transformations, you transform **the contents of the element box**.
- The node coordinates inside the element are transformed permanently
- The ==Elements== panel shows no sign of these transformations after you’ve applied them. 
- The node coordinates are rounded if ==Contour > Coordinates > Round when Editing== is on. 
- All references to the element are affected (the transformation is visible in all composite glyphs and auto glyphs). 
- In the ==Gallery== panel, elements appear transformed. 

### How do I perform transformations?

While in the Glyph window, you can use keyboard shortcuts to perform [[Quick transformations]]: scale, slant, rotate and flip (mirror) your elements, contours or contour selections visually. 

You can also use the [[Free Transform operation]] to visually perform several transformations at once. 

In both the Glyph and the Font window, you can use the [[Transform panel]] to perform transformations numerically. 

Finally, you can perform geometric transformations to entire glyphs across multiple layers using ==Tools > Actions==, see [[Basic actions]]. 
