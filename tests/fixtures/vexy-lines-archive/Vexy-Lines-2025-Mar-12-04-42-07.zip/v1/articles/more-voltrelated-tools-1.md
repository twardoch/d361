## Metadata_Start 
## code: en
## title: More VOLT-related tools 
## slug: more-voltrelated-tools-1 
## seoTitle: More VOLT-related tools 
## description:  
## contentType: Markdown 
## Metadata_End

* Tiro Typeworks has published [Volto](https://github.com/TiroTypeworks/TiroTools), a Python script that can convert the VTP file into a FEA file that you can import into FontLab.
* SIL International has published [FontUtils](https://scripts.sil.org/FontUtils) ([source](https://github.com/silnrsi/font-ttf-scripts)), a set of Perl utilities that include commandline volt2ttf and ttf2volt apps that can convert between VTP and binary tables in both directions.