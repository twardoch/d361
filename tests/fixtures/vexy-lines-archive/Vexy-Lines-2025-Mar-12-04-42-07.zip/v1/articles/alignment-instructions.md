## Metadata_Start 
## code: en
## title: Alignment Instructions 
## slug: alignment-instructions 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

#### \#\# Alignment Instructions

Alignment instructions are used to align points to the grid. There are two types of alignment instructions: those linked with alignment zones and those not linked with zones.