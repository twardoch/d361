## Metadata_Start 
## code: en
## title: Balanced Mode of the Handmade Fill 
## slug: balanced-strokes-1 
## seoTitle: Balanced Strokes 
## description:  
## contentType: Markdown 
## Metadata_End

<!--qh:customNorm-->
In this filling approach, the behavior is akin to the "Blended" method, but with a key distinction: the fill lines can break and reappear to ensure a consistent fill density. Unlike in "Blended" where lines may converge at narrow points, here they simply disconnect. Moreover, new fill lines are introduced in wider sections to occupy any vacant space, enhancing the uniformity of the fill.
<!--qh-->

### Enabling and Customizing a Blended Fill
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28291%29.png){height="" width="280"}

To enable the "Balanced" mode in the Handmade fill, follow these steps:

1. Make sure that you have selected the Handmade fill type.
2. Go to the "HANDMADE FILL" tab.
3. Activate the blending mode by toggling the "Balanced" button.

<!--qh:customNorm-->

| blended |  balanced |
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-88UK2KD8.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-UGB7UGJ1.png){height="" width="300"}|

<!--qh-->

### Fill Parameters:
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28294%29.png){height="" width="300"}

![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) **Interval** ([units](/v1/docs/units)): Controls the distance between strokes. Smaller values bring the strokes closer, while larger values space them out.

<!--qh:customEvenOdd-->
![Render Even/Odd Strokes](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/halftone-both.svg) **Render Even/Odd Strokes**: Add to the fill all the strokes that have an even AND odd ordinal number.

![Render Only Odd/Even Strokes](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/halftone-even.svg) **Render Only Odd/Even Strokes**: Add to the fill only the strokes that have an even OR odd ordinal number.
<!--qh-->

![Smoothness](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/wireframe-smooth.svg) **Smoothness**: Use this parameter to refine the flow of lines and curves, eliminating jagged edges for a polished look.

![Extending](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/custom-expand.svg) **Extending**: extends the strokes beyond the basic curves.

### Interval
1. Locate the **Interval** ![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) parameter.
2. Use the slider or manually enter a value.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28304%29.png){height="" width="300"}

> Decreasing intervals darkens the image, while increasing intervals lightens it.

$~$
<!--qh:customInterval-->

| balanced interval: 0.5 | balanced interval: 1 | balanced interval:1.5 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28320%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28321%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28322%29.png){height="" width="300"}|
<!--qh-->

### Render Even/Odd Strokes
1. Navigate to the HALFTONE FILL tab and find the buttons for controlling Even & Odd Strokes modes.
2. These buttons can be toggled on or off based on your preference.
3. Activating these options will either include strokes at both **Even & Odd** positions or restrict them to just **Even** or **Odd** positions.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28323%29.png){height="" width="300"}

<!--qh:customEvenOdd-->

| even & odd | odd | even |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28324%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28325%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28326%29.png){height="" width="300"}|
<!--qh-->

### Smoothness
1. Find the **Smoothness** option in the HANDMADE FILL tab.
2. Modify the smoothness level by sliding the slider or inputting a desired value.
3. Increasing this setting will result in smoother transitions between strokes in the fill.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28261%29.png){height="" width="300"}

| smoothness: 0 | smoothness: 15 | smoothness: 30 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28266%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28267%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28268%29.png){height="" width="300"}|

### Extending

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28256%29.png){height="" width="300"}

1. Locate the **Extending** ![Extending](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/custom-expand.svg) option in the HANDMADE FILL tab.
2. Activate this feature by toggling the button.
3. When enabled, the strokes in the fill will no longer be restricted by the basic contours and will extend beyond them.

| extending: off |  extending: on | extending: on |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28258%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28289%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28290%29.png){height="" width="300"}|



























