## Metadata_Start 
## code: en
## title: Font masters 
## slug: font-masters 
## seoTitle: Font masters 
## description:  
## contentType: Markdown 
## Metadata_End

A font master in FontLab is a complete “font” that is has a defined location on each axis. You can define some font properties for a font master in Font Info: dimensions, some names, stems, zones, font guides and some other parameters and values. A font master also contains its own set of kerning classes and kerning pairs.

In addition, a font master is associated with font master layers in all or some glyphs — or, in other words, any glyph layer that has a name identical to a font master’s name is associated with that font master.

By default, when you add a font master, FontLab will also add associated glyph layers for all glyphs in your font. However, you can add a font master without adding any font master glyph layers. You can remove a font master and choose to also remove the associated glyph layers.

You can rename a font master and the associated glyph layers. But you can also add, remove or rename a glyph layer in all or some glyphs without renaming the font master — then those glyph layers become disassociated from the font master. If you give a glyph layer a name that matches a font master’s name, the glyph layer becomes associated with that font master.

A variable font master also defines the location in all font axes, which allows it to participate in interpolation. A variable font master also needs the associated glyph layers to be variable. A glyph layer is variable only if its contents matches the contents of other variable master glyph layers, that is if the number and order of elements are the same and those elements have the same number of contours and the same number of segments.

At a minimum you need a total of one font master, plus one font master per axis. Each axis must have font two masters that have different coordinates on that axis.