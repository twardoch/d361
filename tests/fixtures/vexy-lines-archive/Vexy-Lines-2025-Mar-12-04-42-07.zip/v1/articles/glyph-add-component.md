## Metadata_Start 
## code: en
## title: Glyph > Add Component 
## slug: glyph-add-component 
## seoTitle: Glyph > Add Component 
## description:  
## contentType: Markdown 
## Metadata_End

#### Glyph \> Add Component

With Glyph \> Add Component (ShiftCtrlA AltIns), you can add a component that points to the same layer of another glyph. In the Add Component dialog, you specify an additional x and y shift of the component, flip the component, choose to replace the advance width of the current glyph with the width of the component source glyph, and choose to add the component to the current master or all masters.

In Font window, you can also Copy a glyph cell and then Edit \> Paste Components onto another glyph cell.

Once you have a component, when you click Show element properties and Expand properties in the Elements panel, you can set the Base layer name to point the component to another layer, or click Select component instance to make an interpolated component.

When you double-click a component in the Glyph window, FontLab opens the source glyph for editing.

If you edit the contours of the source glyph, its components in all composite glyphs are affected. If you move, scale, rotate or slant the contours or elements of the source glyph, the composite glyphs are affected. If you change the colors or stroke of the elements within the source glyph, the composite glyphs are affected.

Components inherit more information than element references. Element references only link the content of an element (contours or image) but each reference that links to the same element has its own independent placement, transformation, color and stroke.

To replace a component with a full independent copy of the content, which you can then directly edit in the composite glyph, choose Glyph \> Decompose.

| :----- | :----- |
| 󰄣 | Changes that you make to the composite glyphs **do not** affect the source glyph of a component. |