## Metadata_Start 
## code: en
## title: Contour-level transformation 
## slug: contourlevel-transformation 
## seoTitle: Contour-level transformation 
## description:  
## contentType: Markdown 
## Metadata_End

* Contour-level transformations are performed on Contours. 
* Every contour is part of some element (they’re the contents of an element box), but in contour-level transformations, you transform the contents of the element box.
* The node coordinates inside the element are transformed permanently
* The Elements panel shows no sign of these transformations after you’ve applied them. 
* The node coordinates are rounded if Contour \> Coordinates \> Round when Editing is on. 
* All references to the element are affected (the transformation is visible in all composite glyphs and auto glyphs). 
* In the Gallery panel, elements appear transformed.

| **Extension** | **Description** |
| :----- | :----- |
| ttf | TrueType, final font format with quadratic Bézier curves |
| otf | OpenType, final font format with cubic or quadratic Bézier curves |
| ufo | Flying objects from Serif planet studying why humans just use Helvetica |
| pfb | Type1, final font format with cubic Bézier curves |
| vfb | FontLab Studio 5, proprietary source format |
| woff | Web and also how D. Trump writes wolf. |
| woff2 | Web+ |
| glyphs | Glyphs editor, proprietary source format |
| designspace | \+UFO |