## Metadata_Start 
## code: en
## title: Ghost hints 
## slug: ghost-hints-2 
## seoTitle: Ghost hints 
## description:  
## contentType: Markdown 
## Metadata_End

☆ When FontLab opens a VFB, OTF or Type 1, it now correctly reads the top ghost hints as -20 and the bottom ghost hints as -21. It also correctly exports the top and bottom ghost hints into VFB, OTF and Type 1.

You can now create horizontal ghost hints: select one node or several nodes that have the same y-coordinate, for example on the top or the bottom of the I, and choose Tools \> Add Horizontal Hint (Ctrl+X) command. FontLab will pick the hint value depending on the geometry of the segments adjacent to the node.

| :----- |
| When you convert a bottom ghost hint to a link or add a horizontal bottom ghost link, that link gets the width 21 (because the nodes it links from are at the bottom), but FontLab will change the hint back to -21 when you export. |