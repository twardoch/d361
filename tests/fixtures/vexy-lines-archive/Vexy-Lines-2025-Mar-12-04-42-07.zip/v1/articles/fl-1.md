## Metadata_Start 
## code: en
## title: FL 
## slug: fl-1 
## seoTitle: FL 
## description:  
## contentType: Markdown 
## Metadata_End

The [FL](https://fontlabcom.github.io/fontlab-python-docs/FL.html) package exposes a legacy API that is largely compatible with the old FontLab Studio 5 Python API. However, we no longer actively develop it, and it’s only useful for very simple scripts.