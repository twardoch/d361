## Metadata_Start 
## code: en
## title: Align and Arrange 
## slug: align-and-arrange 
## seoTitle: Align and Arrange 
## description:  
## contentType: Markdown 
## Metadata_End

<!--qh:align-->
Alignment and Order Adjustment Panel.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28665%29.png){height="" width="300"}

### Alignment
<!--qh:alignObjects-->
The Alignment commands adjusts the position of selected objects based on their bounding boxes. When multiple objects are chosen, alignment is relative to the bounding box of the object group. If only one object is selected, alignment is based on the document's bounding box. This feature helps organize and arrange objects in a consistent manner within a group or the overall document.
<!--qh-->

![Align Right](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/align-right.svg) Align Right.

![Align Center Horizontally](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/align-h-center.svg) Align Center Horizontally.

![Align Left](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/align-left%281%29.svg) Align Left.

![Align Top](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/align-top.svg) Align Top.

![Align Center Vertically](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/align-v-center.svg) Align Center Vertically.

![Align Bottom](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/align-bottom.svg) Align Bottom.

### Order Adjustment
<!--qh:orderAdjustment-->
Commands for changing the order of objects within a group.
<!--qh-->

![Move object down one position](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/send-backward.svg) Move object down one position.

![Move object up one position](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/bring-forward.svg) Move object up one position.

![Make object the last in its group](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/send-back%281%29.svg) Make object the last in its group.

![Make object the first in its group](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/bring-front.svg) Make object the first in its group.



