## Metadata_Start 
## code: en
## title: Removing anchors 
## slug: removing-anchors-1 
## seoTitle: Removing anchors 
## description:  
## contentType: Markdown 
## Metadata_End

You can now remove anchors with a certain name from all or selected glyphs in current master or in all masters.

Select some glyph cells in the Font Window and choose Tools \> Actions \> Contour \> Remove anchors. Choose Active Layer and the dialog will list all anchor names in the current layer of the selected glyphs. Choose All Masters to see all anchor names in all masters of the selected glyphs. Select the names of the anchors that you wish to remove and click OK.