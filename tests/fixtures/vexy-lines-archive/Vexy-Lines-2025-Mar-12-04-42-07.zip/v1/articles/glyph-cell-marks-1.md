## Metadata_Start 
## code: en
## title: Glyph Cell Marks 
## slug: glyph-cell-marks-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

Below are all the ways in which a glyph cells in the [[Font Window]] can be marked or colored.

[TOC]


## Color Lines


When you modify a glyph in any way, a dark line appears at the top of the cell. This dark line indicates that the glyph has been modified since the last save. When you save a font, all dark lines disappear.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_cell_marks_02.png)

A strong red line in the cell caption means that the character has some naming conflict: either multiple glyphs have the same name (not allowed in output font formats), or the glyph’s Unicode codepoint disagrees with its name (allowed, but usually a bad idea or an error).

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_cell_marks_01.png)

In such cases, you usually need to change either the glyph name or the Unicode codepoint.


## Color Cells


Some glyphs may be flagged with a color for the caption and background:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-the_font_window_07.png)

Flagging is very useful when you need to show visible differences among glyphs for easy identification. Read more about that in the [[Flagging Glyphs]] section.

Some operations in FontLab may flag glyph cells with a color to show the difference in the results. For example, the [[Generate Glyphs]], [[Add Glyphs]] and [Compare Fonts](Comparing-Fonts) operations can mark created glyph cells with a color tag.


## Glyph Notes


If the glyph has a [text note](Glyph-Notes) attached, you will see the note icon appear at the bottom right of the glyph cell:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-Notes_1.png)

**To open and edit the note**, double-click the note icon.

Unlike Glyph Notes, [[Element Stickers]] do not make a change in how glyph cells appear in the Font Window.


## Other Marks


| **Icon**                                                                                       |     **Mark**    | **Description**                                            |
| ---------------------------------------------------------------------------------------------- | :-------------: | ---------------------------------------------------------- |
| ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_cell_marks_03.png) |  blue `T` mark  | Glyph has [[TrueType Hinting]] program in the binary form |
| ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_cell_marks_04.png) | yellow `T` mark | Glyph has visual [TrueType hints](TrueType-Hinting)        |
| ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_cell_marks_05.png) | red corner mark | Glyph has unresolved [[FontAudit]] issues                 |
