## Metadata_Start 
## code: en
## title: Single Corner-1 
## slug: single-corner1 
## seoTitle: Single Corner-1 
## description:  
## contentType: Markdown 
## Metadata_End

#### Single Corner

A simple click a corner node will break the contour in a special manner. The node will turn into two nodes, the contour will become an open contour, yet its filled/unfilled state won’t change; the fill is still controlled by the paint bucket ([Fill tool](file:///Volumes/Igor/Fontlab/Manual/FontLabVI-help-master/docs/fontlab/7/manual/Fill-tool/)).

[![][flvi-scissors_4]](file:///Volumes/Igor/Fontlab/Manual/FontLabVI-help-master/docs/fontlab/7/manual/img/flvi-scissors_4.gif)

Scissors 4

[flvi-scissors_4]: flvi-scissors_4.png width=219px height=228px