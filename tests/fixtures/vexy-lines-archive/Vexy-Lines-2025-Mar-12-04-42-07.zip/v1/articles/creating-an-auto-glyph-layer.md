## Metadata_Start 
## code: en
## title: Creating an auto glyph layer 
## slug: creating-an-auto-glyph-layer 
## seoTitle: Creating an auto glyph layer 
## description:  
## contentType: Markdown 
## Metadata_End

To convert a simple or composite layer of a single glyph into an auto glyph layer, open the glyph and then turn on the Auto layer toggle using-composite-auto\_auto-toggle.png to the glyph’s layer or master in Property bar, or in the properties section of the \[Layers and Masters panel\](Layers-and-Masters-panelproperties-section). Once the toggle is turned on, if FontLab is using a predefined recipe, it will shown in grey in the Auto Layer field (to distinguish it from custom recipes). 

predefined\_recipes.png.

To modify this recipe, click the Edit Recipe button, enter a new recipe in the field and press Enter. To go back to FontLab’s predefined recipe, press the Reset recipe button.

If there is no predefined recipe for that glyph, you can add a custom glyph recipe in the Auto Layer field using-composite-auto\_field.png right away.

To convert the current layer of multiple glyphs into an auto glyph layer, select all the glyphs in the Font Window, open the Generate Glyphs dialog Font \> Generate Glyphs, and check Rebuild existing glyphs and Create auto layers. Once you press OK, the current layer of all the selected glyphs will be rebuilt, and the previous contents will be completely replaced with automatically generated content.

using-composite-auto\_generate-glyphs.png

To generate all new glyphs as an auto glyph in all layers, go to the \[Operations section of Preferences\](Preferencesnew-glyphs) and under New Glyphs, turn on fill created glyphs with content when available and create auto layers if possible.

using-composite-auto\_preferences.png