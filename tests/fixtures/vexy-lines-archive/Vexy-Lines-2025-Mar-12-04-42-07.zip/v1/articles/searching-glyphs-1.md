## Metadata_Start 
## code: en
## title: Searching Glyphs 
## slug: searching-glyphs-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

[TOC]

There are several methods to search for a particular glyph in FontLab. All of them work in the [[Font Window]] as well as in the [[Glyph Window]]. You may search for glyphs using:

- ==Edit > Find Glyphs== menu selection;
- ==Edit > List Related Glyphs== menu selection;
- ++Slash++ key on the keyboard;
- the **Search** box on the window’s property bar.

### Find Glyphs

Press ++Cmd+F++ (==Edit > Find Glyphs==) and the pane with all glyphs included in the font will appear:

 ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_pane_3.png)

Double-click any glyph cell in the pane to open it, or start typing the search string in the _Filter_ field. While you type, the list of search criteria may change in the left column. Click any available criterion in the list to show only those glyphs that meet the criterion. FontLab can find glyphs by glyph name, Unicode character name, script, codepage, encoding, range, glyph width, you name it. For example, type “g” to search for glyphs belonging to Greek codepage or type “550” to search for glyphs having an advance width more than (or less than, or equal to) 550 units.

After you have filtered glyphs in the pane, you can double-click one of them or select several of them using ++Shift++ and ++Cmd++ keys or click the ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_pane_4.png) button to select all visible glyphs.

Double-clicking selected cells closes the pane, and

- selects those glyph cells in the Font window (Font Map panel) if you were in the Font window (Font Map panel);

- opens those glyphs for editing in the Glyph/Metrics window if you were in the Glyph/Metrics window.

### List Related Glyphs

Press ++Cmd+L++ (==Edit > List Related Glyphs==), and choose the glyph you were looking for in the list of suggested glyphs. This list includes only those glyphs which have common elements with the current glyph:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_pane_2.png)

### Quick Find by Name

This is the quickest way to open an existing glyph for editing. Press the ++Slash++ key and start typing the desired glyph name in the popup pane:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_pane_1.png)

Then press ==Return== to select the first available glyph or double-click the glyph you need in the list. As with other methods, the glyph is selected in the Font window (Font Map panel) or opened for editing in the Glyph (or Metrics) window depending on the type of the current window.

### Search Box

Use the **Search** box in the upper right corner of the current window to quickly filter glyphs in the Font window (Font Map panel) or change the contents of the Glyph window. When you start entering text in this field, a popup list with the available search criteria appears below.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-search_popup_1.png)

You can continue entering text or select one of the options in the list. For example:

- **Text: Matches “A”** will put the glyph named “A” into the editing area of the Glyph window 
- **Name: Starts from A** will put all glyphs having their names starting from “A” 
- **Name: Contains A** will put all glyphs having their names containing “A” for example.

If you do this while in the Glyph window, the search results will replace the current contents in the glyphs editing area. In the Font window, the Search box filters glyph cells: only glyphs that meet the search criteria remain visible, and their cell captions become marked with yellow.

Search requests used in the Search box are added to the search history in the sidebar:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-glyph_pane_5.png)
