## Metadata_Start 
## code: en
## title: Status bar 
## slug: status-bar-2 
## seoTitle: Status bar 
## description:  
## contentType: Markdown 
## Metadata_End

On the left of the status bar under the list of classes, apart from showing the total number of classes and/or tags, there are two buttons: + creates new class or tag and – removes the selected class(es) or tag(s). On the right, the status bar shows the number of glyphs in the selected class or list, along with the buttons to increase/decrease the size of cells in the Preview Area and a menu, where you can select whether you would like to see the name, unicode or character in the List Sidebar. In addition, the + button lets you add the current glyph to the selected tag or class. The last button in the status bar is Select Glyphs, denoted by classes\_panel-select\_all.png. Click the Select Glyphs button to select glyph cells belonging to the currently selected classes. After cells are selected in the Font window you can color mark them or apply any other glyph operation.