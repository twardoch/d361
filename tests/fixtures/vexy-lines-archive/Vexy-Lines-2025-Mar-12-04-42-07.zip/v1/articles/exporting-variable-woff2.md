## Metadata_Start 
## code: en
## title: Exporting variable WOFF2 
## slug: exporting-variable-woff2 
## seoTitle: Exporting variable WOFF2 
## description:  
## contentType: Markdown 
## Metadata_End

When you turn on the setting ==WOFF2== in the ==Variable TT== or ==Variable PS== export profile, FontLab now exports the `.woff2` version alongside the uncompressed version.

!!! note

> FontLab does not export variable fonts as `.woff` or `.eot` even if you turn on ==WOFF== or ==EOT== in the profile. This is by design. All browsers that support variable fonts also support `.woff2`.
