## Metadata_Start 
## code: en
## title: New Glue filter 
## slug: new-glue-filter 
## seoTitle: New Glue filter 
## description:  
## contentType: Markdown 
## Metadata_End

==Glue== was one of the earliest smart contour filters we introduced in FontLab VI. It was time to re-evaluate it. We’ve looked at how people use ==Glue==, and what are its strengths, and we’ve greatly simplified the ==Glue== filter in FontLab 8.

![Image](https://i.fontlab.com/fl8/rn/fl8-rn5-glue-filter.png){ .plain }

If you have at least one closed contour and at least one open contour in an element, or if you have an element with a closed contour and another element with an open contour:

1. Select the open contour (with the ==Contour== tool), or the element with an open contour (with the ==Contour== or ==Element== tool).
2. Choose ==Element > Glue Selection==.

The new ==Glue== filter will consist of the construction element labeled ==glue== in the ==Elements== panel. This construction contains the glued element that has the open contour, and the remaining contours which serve as the body. You can glue additional contours to the body: they will be added to the same construction.

To activate the construction element, click the filled area or outline with the ==Element== tool, or click the whitespace in canvas with ==Contour== tool, or click the ==glue== entry in the ==Elements== panel.

If the ==glue== construction element is active:

- It has two green **glue connection points** per every glued element. Click any glue connection point to switch between smooth and sharp connection.
- It also has one central **glue positioning point** in the middle of the construction. Click the glue positioning point to change how the glued elements behave when you move the body element: they can stay in place (empty positioning point), follow only horizontally or only vertically, or follow in both X and Y (cross inside positioning point).

To activate the glued element or the body, click the filled area or outline with ==Contour==, or click it again with ==Element==, or click an element inside the ==glue== entry in the ==Elements== panel.

If the body element has a pin or node named, for example `p1`, and the glued element has a corresponding pin with the same name but prefixed with `_` (in this example: `_p1`), the glued element will attach to the corresponding pin/node.

If the body has another pin or node, named for example `p2`, and the glue element has a corresponding pin (`_p2`), then the glued element will also rotate so that it attaches to both body pins or nodes.

If the body has multiple same-named pins or nodes, the glued element attaches to the geometrically closest pair of pins or nodes.
