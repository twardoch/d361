## Metadata_Start 
## code: en
## title: TrueType Hinting 
## slug: truetype-hinting-5 
## seoTitle: TrueType Hinting 
## description:  
## contentType: Markdown 
## Metadata_End

* Preview of stored TT hinting. When you open a hinted OpenType TT (.ttf) font and open Tools \> TrueType Hinting, the imported binary hinting is now applied when rendering the previews in the Glyph window and the TrueType Hinting preview panel.