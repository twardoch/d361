## Metadata_Start 
## code: en
## title: Using Expressions 
## slug: using-expressions 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

In FontLab, you can use expressions to define the position of [guidelines](Using-Guidelines), [alignment zones](Hinting#alignment-zones), [anchors](Anchors-and-Pins) and [pins](Anchors-and-Pins). Expressions are more flexible than fixed values because if you change the values of font dimensions (that make up the predefined [variables](Using-Expressions#variables)) or [parameters](Using-Expressions#parameters), the respective guidelines, zones, anchors and pins will follow these new values. 

An expression can have:

1. Basic maths using `+` `–` `*` `/` operators; 
2. References to [variables](Using-Expressions#variables); 
3. References to other guidelines, anchors, pins or zones;
4. References to [parameters](Using-Expressions#parameters).

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-UsingExpressions_FontInfo.png)

Values you can reference in expressions font-wide — parameters, font guidelines and selected variables — are listed in the [[Font Info panel]] under the [Parameters](Font-Info-panel#parameters) tab, or in the [Parameters](Font-Info-Dialog-Box#parameters) section of the [Font Info dialog](Font-Info-Dialog-Box). Variables are preceded by the ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-finfo_panel-parameters_variableicon.png) icon; parameters by ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-finfo_panel-parameters_parametericon.png); and font guidelines by ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-finfo_panel-parameters_fontguideicon.png).

### Defining position of guidelines

**To use expressions to define the position of a guideline**, choose the guideline, go the [[Guideline panel]] ==Window > Panels > Guideline==, and enter the appropriate expression in the **Expression** field, which is denoted by a calculator: 

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-UsingExpressions_guidelines_panel.png)

Or after choosing the guideline, use the Expression field in the [[Property bar]]:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-UsingExpressions_guide_property_bar.png)

### Defining position of alignment zones

Similarly, **to use expressions to define the position of an alignment zone**, choose the zone and enter the value in the Expression field of the [[Guideline panel]] ==Window > Panels > Guideline== or [[Property bar]].

### Defining position of anchors and pins

**To use expressions to define the position of an anchor or pin**, choose the anchor or pin, open the [[Anchors and Pins panel]] ==Window > Panels > Anchors & Pins==, and enter the expressions for the x and y coordinates in **Location Expression** fields, again denoted by a calculator:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-UsingExpressions_a&p_panel.png)

Or after choosing the anchor or pin, use the Expression field in the [[Property bar]]:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-UsingExpressions_anchor_property_bar.png)


## Variables


There are six pre-defined variables available in the application: `ascender` `descender` `x_height` `caps_height` `width` and `baseline`. Four of these are linked to font dimensions and can be seen in the Font Info panel under the [Parameters](Font-Info-panel#parameters) tab, or in the [Parameters](Font-Info-Dialog-Box#parameters) section of the Font Info dialog box: `ascender` `descender` `x_height` and `caps_height`. `width` is linked to individual glyph advance width, while `baseline` refers to the baseline of the font (usually zero). All pre-defined variables with the exception of `width` are font-wide; `width` is the property of a single glyph. 

Some examples of how variables can be used in expressions are illustrated below:

#### To put a guideline in the middle of the baseline and x-height:

`(x_height-baseline)/2`

#### To put a guideline 12u below the baseline, useful for an overshoot:

`baseline-12`

#### To position an anchor at a given distance from the caps height you can use:

`caps_height+64`

#### To add a vertical glyph guideline at the exact middle of the glyph using simply:

`width/2`

#### To define the coordinates of an anchor (x,y) in relation to the glyph’s advance width and the font’s baseline:

`width/2, baseline-80`

Here, the first expression defines the horizontal position and the second, the vertical one.


## Guidelines, zones and anchors


Existing guidelines, zones, anchors and pins can also be referenced in expressions. To reference a guideline, zone or anchor, just use their names. For example, if you have a guideline named `curvelimit`, you can use it to define the position of another guideline:

`curvelimit+120`

Note that you can use them along with pre-defined variables:

`curvelimit+x_height+20`


## Parameters


Parameters are named numeric variables that can be used in expressions. Once defined, they can be used in expressions just like variables. Parameters can be especially useful to define heights that are not covered by font dimensions, such as as small caps, or heights for other scripts, like Arabic, Hebrew or Armenian.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-UsingExpressions_Parameters.png)

**To add a new parameter**, go to ==Window > Panels > Font Info== and select the Parameters tab or ==File > Font Info== and select Parameters from the left sidebar. Click the ==+== button at the bottom-left, add a name for the parameter and enter its value.

**To remove a parameter**, select it and click the ==-== button.
