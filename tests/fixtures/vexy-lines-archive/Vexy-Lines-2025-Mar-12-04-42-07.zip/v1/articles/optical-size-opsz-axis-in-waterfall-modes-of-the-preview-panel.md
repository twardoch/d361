## Metadata_Start 
## code: en
## title: Optical size (`opsz`) axis in waterfall modes of the **Preview** panel 
## slug: optical-size-opsz-axis-in-waterfall-modes-of-the-preview-panel 
## seoTitle: Optical size (`opsz`) axis in waterfall modes of the **Preview** panel 
## description:  
## contentType: Markdown 
## Metadata_End

If the font has an optical size axis with the tag `opsz` defined in ==Font Info > Axes== and you choose the ==Text waterfall== or ==Glyph waterfall== mode of the ==Preview== panel, a binoculars toggle appears in the panel sidebar.

If you turn **off** the toggle, the ==Preview== panel shows the current instance or master in each font size of the waterfall.

If you turn **on** the toggle, the ==Preview== panel ignores instance selections along the optical size axis done in the ==Layers & Masters== and ==Variations== panels, and automatically shows the optical size dynamic instance for each font size of the waterfall.

!!! note

> The ==Preview== panel shows font sizes in waterfalls using logical pixels, so each number is a PPM size, which corresponds to point sizes at 72 dpi. When the waterfall automatically shows optical sizing, it maps each PPM size to an `opsz` axis location in **design coordinates**. This is different from the behavior in web browsers. With the CSS `font-optical-sizing: auto` property, a browser maps either CSS points or CSS pixels (this depends on the implementation) to **user coordinates**.
> If the axis graph for your `opsz` axis in ==Font Info > Axes== uses different scales for design and user coordinates, or uses a non-linear mapping, the automatic optical sizes in the ==Preview== panel will be different than those used in the browsers. However, there is also an upside of this: you can set up your design coordinates to be, for example, 2× of the user coordinates, and then use size 20 in the waterfall to preview the optical size 10 etc.
