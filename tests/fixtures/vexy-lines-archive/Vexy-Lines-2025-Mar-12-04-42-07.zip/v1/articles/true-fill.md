## Metadata_Start 
## code: en
## title: True Fill 
## slug: true-fill 
## seoTitle: True Fill 
## description:  
## contentType: Markdown 
## Metadata_End

View \> True Fill (Shift+Space) is not really a preview, but a toggle to switch the glyph fill to 100% opaque. While in True Fill, you will continue to see glyph details that you may have made visible, like nodes, handles, curvature, etc. and will be able to edit or draw glyphs using any tools of your choice. Note that you can also control the opacity of the glyph fill in Preferences \> Glyph Window, which is explained in detail \[here\](Outline-Appearance).

![][true_fill_01]

[true_fill_01]: true_fill_01.png width=104px height=120px