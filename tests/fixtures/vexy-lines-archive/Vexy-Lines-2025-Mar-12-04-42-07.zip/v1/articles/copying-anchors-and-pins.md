## Metadata_Start 
## code: en
## title: Copying anchors and pins 
## slug: copying-anchors-and-pins 
## seoTitle: Copying anchors and pins 
## description:  
## contentType: Markdown 
## Metadata_End

When you have one or more anchors or pins selected in the Glyph window:

* Use Edit \> Copy Anchors/Pins to copy the selected anchors, pins and selected contours (if any). 
* Use the new Edit \> Copy to Masters (Cmd+Y / Ctrl+Y ) to copy the selected anchors and pins, and then paste them to all masters of the current glyph. If the other masters don’t contain anchors/pins with a given name, these anchors/pins are created. If the other masters contain anchors/pins with a given name, the position of these anchors/pins is updated.