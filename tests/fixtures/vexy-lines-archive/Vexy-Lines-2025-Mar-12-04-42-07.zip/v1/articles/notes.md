## Metadata_Start 
## code: en
## title: Notes 
## slug: notes 
## seoTitle: Notes 
## description:  
## contentType: Markdown 
## Metadata_End

!!! Note

The variations workflow mostly does not work with color. Specifically, it supports only fonts where glyphs are made from monochrome PostScript or TrueType contours (and some editing tools only work reasonably with PostScript contours, not TrueType contours). Interpolation between color glyphs (made from editable contours) is also possible to some extent. SVG or bitmap glyphs are not yet supported in variations. These are limitations because of what OpenType supports in the output formats.

!!! Note

FontLab currently only supports master at extrema locations of the design space (there, undefined kerning pairs will have the value 0), and simple intermediate masters (undefined kerning pairs will have the interpolated value). It does not support intermediate masters with ranges, but it does support conditional glyph switching.