## Metadata_Start 
## code: en
## title: VOLT tutorials and info 
## slug: volt-tutorials-and-info 
## seoTitle: VOLT tutorials and info 
## description:  
## contentType: Markdown 
## Metadata_End

* Read the [VOLT tutorial by MS](https://docs.microsoft.com/en-us/typography/tools/volt/tutorial) and the [user guide](https://docs.microsoft.com/en-us/typography/tools/volt/menus-toolbars)
* Read the [VOLT tutorial by SIL](https://scripts.sil.org/volt_tutorial)
* Check the [VOLT article](https://www.ntg.nl/maps/43/17.pdf) by Karel Píška
* Download the [VOLT tutorial video](https://www.microsoft.com/en-us/download/confirmation.aspx?id=21959) from Microsoft. Unzip, open the VoltTrainingVideo\_WMV\_media subfolder, and watch the video in an app such as [VLC](https://www.videolan.org/) or other video player that supports the WMV format.
* [Al Mamun Hossen](https://www.almamunhossen.com/) has created a series of Bangla-language videos that show how to [use FontLab to create](https://www.youtube.com/playlist?list=PLN5OEA26QEnWUlZW-Qlu8YLtjiGDlKCOx) a Bangla font, and another series on how to [use VOLT to add features](https://www.youtube.com/playlist?list=PLN5OEA26QEnXQVnUt-iWo2X01cZSAO-io) to that font. These videos are easy to follow even if you don’t speak Bangla.
* For more info about using Microsoft VOLT, visit the [VOLT forum](https://forum.fontlab.com/microsoft-visual-opentype-layout-tool-(volt)/).