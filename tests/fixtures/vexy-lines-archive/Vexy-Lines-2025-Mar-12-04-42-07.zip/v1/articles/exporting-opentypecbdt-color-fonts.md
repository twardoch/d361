## Metadata_Start 
## code: en
## title: Exporting OpenType+CBDT color fonts 
## slug: exporting-opentypecbdt-color-fonts 
## seoTitle: Exporting OpenType+CBDT color fonts 
## description:  
## contentType: Markdown 
## Metadata_End

Previously, if your font had ppm.XX layers where the XX PPM size was larger than 127, or if the font had contour-based or SVG color glyphs, and Preferences \> Save Fonts \> Default rasterization PPM was larger than 127, and you exported the font with a profile that had Export color font files \> OpenType+CBDT turned on, FontLab would export a -CBDT.ttf font that would be technically invalid since the OpenType+CBDT color font format has 127 as a technical limit of the maximum permissible PPM size.

Now, when you’re trying to export an OpenType+CBDT font in such situations, FontLab will present a dialog box that will list the PPM sizes that will not be exported or that will prompt you to enter a rasterization PPM smaller no larger than 127. Also, OpenType+CBDT export now works with both TTF- and OTF-based font profiles.

| :----- |
| OpenType+sbix fonts can be rasterized into larger PPMs. |