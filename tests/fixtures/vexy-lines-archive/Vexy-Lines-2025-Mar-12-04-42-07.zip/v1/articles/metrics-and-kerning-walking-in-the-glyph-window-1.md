## Metadata_Start 
## code: en
## title: Metrics and Kerning walking in the Glyph window 
## slug: metrics-and-kerning-walking-in-the-glyph-window-1 
## seoTitle: Metrics and Kerning walking in the Glyph window 
## description:  
## contentType: Markdown 
## Metadata_End

**Metrics and Kerning: walking in the Glyph window**

In both Metrics and Kerning modes, you can now consistently “walk around” the text in the Glyph window when you hold the Fn key and press the arrow keys, or use Home, End, PgUp, PgDn.

| **Walking (go to)** | **Mac** | **Win** |
| :----- | :----- | :----- |
| prev line in text | ↑¹ / Fn↑ | ↑¹ / PgUp |
| next line in text | ↓¹ / Fn↓ | ↓¹ / PgDn |
| prev glyph in text | \[ | \[ |
| next glyph in text | \] | \] |
| prev glyph in text (Metrics) | ← | ← |
| next glyph in text (Metrics) | → | → |
| prev pair in text (Kerning) | \[ / Fn← | \[ / Home |
| next pair in text (Kerning) | \] / Fn→ | \] / End |

¹ To get this behavior, turn off the new setting Preferences \> Spacing \> Smart navigation with the up/down keys.