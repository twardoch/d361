## Metadata_Start 
## code: en
## title: Windows and tabs configuration 
## slug: windows-and-tabs-configuration-1 
## seoTitle: Windows and tabs configuration 
## description:  
## contentType: Markdown 
## Metadata_End

The settings in Preferences \> General \> Windows and tabs configuration now have text captions in addition to the icons.