## Metadata_Start 
## code: en
## title: General information 
## slug: general-information-1 
## seoTitle: General information 
## description:  
## contentType: Markdown 
## Metadata_End

To customize your FontLab preferences, select the FontLab \> Preferences menu command on Mac, or Edit \> Preferences on Windows.

![][menu-r]

You can use the local toolbar of the Preferences dialog box to search, open, save, and reset preferences. You can use the ☰ menu on the top left of the dialog to:

* *Open Preferences* by choosing an external preferences file from the file dialog.
* *Save Preferences* into an external file.
* *Reset to Defaults* to set all preferences to factory defaults.

Note that Reset of Defaults only resets the options in the Preferences dialog. Menus, recent files, custom workspaces, loaded files for phrases and pairs, opened panels, view settings, recent settings in the Export Font, Open Font etc. dialogs, bookmarks in the Font window, custom brushes etc. remain intact. To reset all things listed above, you need to [delete the Preferences file manually](https://support.fontlab.com/a/solutions/articles/33000217170).

| :----- |
| When you save your Preferences, **all** your settings are saved in an external file, potentially including your password for your Digital Signature (DSIG) (if you saved that in your Preferences). Consider this when sharing your preferences files with other people. |

[menu-r]: menu-r.jpg width=110px height=110px