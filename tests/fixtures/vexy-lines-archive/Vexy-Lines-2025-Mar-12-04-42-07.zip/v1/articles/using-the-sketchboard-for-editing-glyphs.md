## Metadata_Start 
## code: en
## title: Using the Sketchboard for Editing Glyphs 
## slug: using-the-sketchboard-for-editing-glyphs 
## seoTitle: Using the Sketchboard for Editing Glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

You can use the Sketchboard to start working on a new design or to experiment with the drawing tools; there is no need to open a font or to create blank glyphs. Run FontLab, and then start drawing in the Sketchboard window immediately. Later, you can easily drag-drop your drawings to a font.

On the other hand, if you have a font open, you can use the Sketchboard for glyph contours and metrics editing. To edit glyph contours, \[create a text frame\](Using-Sketchboard\#opening-a-text-frame), select the Contour tool in the Toolbar, double-click the glyph you want to edit and zoom in close enough to make your changes. While you are editing one glyph in the text you can see other glyphs change as well if they share the same \[elements\](Elements). To edit glyph kerning, \[create a text frame\](Using-Sketchboard\#opening-a-text-frame), select the Kerning tool, and move the glyphs to adjust the space between them.

![][sketchboard_05]

[sketchboard_05]: sketchboard_05.png width=215px height=140px