## Metadata_Start 
## code: en
## title: Context menu 
## slug: context-menu-1 
## seoTitle: Context menu 
## description:  
## contentType: Markdown 
## Metadata_End

☆ The context menu for nodes now includes the commands Duplicate and Retract Handles.