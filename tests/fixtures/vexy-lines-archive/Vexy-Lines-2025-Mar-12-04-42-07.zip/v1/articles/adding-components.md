## Metadata_Start 
## code: en
## title: Adding Components 
## slug: adding-components 
## seoTitle: Adding Components 
## description:  
## contentType: Markdown 
## Metadata_End

If Use components is on, FontLab will use Components: 

* when you use Font \> Generate Glyphs
* when you turn on Glyph \> Auto Layer for a glyph layer or turn on the Auto layer button in the Layers & Masters panel
* when you have Preferences \> Operations \> New glyphs \> fill created glyphs with content when available turned on and you double-click an empty glyph cell in the Font window
* when you perform Font \> Detect Composites (will use them if it can)

If Convert components to element references is on, FontLab will use Element References instead (and the menu item will be Font \> Detect Element References). 

To replace your manually-constructed composite glyph master with an automatically generated glyph master that will use the “correct” components (if it’s in FontLab’s alias.dat database), turn on Glyph \> Auto Layer. 

To correct the placement of components manually, turn Glyph \> Auto Layer off.