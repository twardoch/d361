## Metadata_Start 
## code: en
## title: Snapping glyph parts and interface features 
## slug: snapping-glyph-parts-and-interface-features 
## seoTitle: Snapping glyph parts and interface features 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab can assist you in aligning your drawings with selected glyph parts and features. To activate this feature, use the View \> Snap menu command or the !\[Snap\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-quick\_zoom\_viewpanel\_snap.png button in the View panel. The parts and features you can snap to are: Outlines, Guides, Font Guides, Hints, Mask, Grid, Font Metrics, Glyph Metrics, Global Mask, Anchors and Pins, and Alignment Zones.