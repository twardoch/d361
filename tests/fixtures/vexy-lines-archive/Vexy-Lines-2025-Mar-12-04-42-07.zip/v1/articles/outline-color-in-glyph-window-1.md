## Metadata_Start 
## code: en
## title: Outline color in glyph window 
## slug: outline-color-in-glyph-window-1 
## seoTitle: Outline color in glyph window 
## description:  
## contentType: Markdown 
## Metadata_End

Editing modes of the Glyph window show the outline of contour-based elements in different colors:

* ■ black: simple contour
* ■ light gray: filtered contour (e.g. result of Smart Corner)
* ■ dolphin:  detached component
* ■ dark blue: current element
* ■ purple:  attached component
* ■ pale dark pink: element group
* ■ danube: selected non-current element
* ■ polo blue: Power Brush element
* ■ jungle green: glued contour