## Metadata_Start 
## code: en
## title: Shared app data folder 
## slug: shared-app-data-folder 
## seoTitle: Shared app data folder 
## description:  
## contentType: Markdown 
## Metadata_End

The Shared app data folder can be typically found at /Library/Application Support/FontLab on macOS or C:\\ProgramData\\Fontlab on Windows. This folder may hold files that can be used by our apps: FontLab Studio 5, TransType 4, TypeTool 3, with more to come and by all users. It has the same structure as the FontLab internal folder discussed above. In each respective subfolder, codepage definitions, encoding definitions, glyph-to-Unicode mapping files and other special data files may be stored. If needed you may use these folders for custom files but note that they will be available to all Fontlab Ltd. applications and all users of the computer.