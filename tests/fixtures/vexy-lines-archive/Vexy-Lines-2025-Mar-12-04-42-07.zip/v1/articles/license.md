## Metadata_Start 
## code: en
## title: LICENSE 
## slug: license 
## seoTitle: LICENSE 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab Ltd., Inc. ("FontLab") grants you the right to use the enclosed program (the "software"). You may not use, copy, modify, rent, sell or transfer the software or any portion thereof except as provided for in this agreement.

This license is for a single user, unless you have purchased a multi-user license.

**You may:**

* Use the software on no more than three personal computers if you have a single-user license, or on no more than one personal computer per user specified in your multi-user license. In the case of a single-user license, only one person is permitted to use the software, even if it is installed on multiple computers.
* Use the software perpetually if you have a standard license, or use the software only within the period specified if you have a time-limited license, preview or demo license.
* Copy the software solely for transfer to another personal computer for your use only, or for archival or backup purposes.
* Modify the program and/or merge it into another program for your use only. Any portion of this program merged into another program will continue to be subject to the terms and conditions of this licensing agreement.
* Transfer the program and license to another party, if the other party agrees to accept the terms and conditions of this license agreement, and you notify FontLab of the license transfer. If you transfer the program you must either transfer all copies (whether imprinted or machine readable form) to the same party or delete any copies not transferred. This includes all modifications and portions of the program contained or merged into other programs.

**You may not:**

* Use the software or cause the software to be used by more than one user, or by more users than specified in your multi-user license, including using the software across a network system.
* Use the software after the period specified, if you have a time-limited, preview or demo license.
* Sub-license the software.
* Reverse engineer, decompile, or disassemble the software.
* Rent, loan, lease, modify, distribute, or create derivative works from the software. This shall not be construed so as to restrict your ability to use the software to create or modify fonts.
* Copy the software or manual except as provided in this agreement.
* Permit simultaneous use of the software by more than the licensed number of users (normally one).
* Reveal the serial number of your license to any other person, other than as required to administer your licensing.
* If the software is a “demo version,” or if it is running in “demo mode,” circumvent the advertised demo-related limitations of the software, such as limitations on saving or exporting files, nor use the software beyond the scope of these limitations.