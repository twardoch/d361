## Metadata_Start 
## code: en
## title: When the Text tool is active 
## slug: when-the-text-tool-is-active 
## seoTitle: When the Text tool is active 
## description:  
## contentType: Markdown 
## Metadata_End

[![][flvi_GW-PropertyBar_active_text]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/flvi_GW-PropertyBar_active_text.png)

When the [Text tool](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/Text-tool/) is active, the Property bar displays the following:

1. Thumbnail list of glyphs related to the current glyph (i.e. the glyph that precedes the Text Mode’s text cursor). Click any thumbnail to insert the glyph at the cursor, or — to replace your selection in the Glyph window.
2. Find button at the end of the thumbnail list, which, on click, opens Find Glyphs Edit \> Find Glyphs dialog that allows you to make a more precise search using different criteria.
3. Case buttons, Text to uppercase and Text to lowercase, that let you change the case of text currently selected (using the text mode cursor), or of all the visible text if there is no selection.
4. Features button, which opens a floating dialog that allows you to apply OpenType features to the entire visible text. You need to have features defined and compiled in the [Features panel](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/Features-panel/). The Features checkbox enables feature processing, which will also activate Right-to-Left and script-specific Unicode processing. With the checkbox enabled, you can choose which features should be enabled.
5. Text size selector, which lets you choose a text size from the dropdown menu. The button to its left, Smaller text, and to its right, Larger text, can also be used to modify the size of text in the Glyph window.
6. Tracking and line height selectors that are hidden if they don’t fit within the window width.
7. Texts button that opens a floating text editor for the Text phrases. You can apply any of the phrases to the Glyph window using Text \> Next Phrase and Text \> Previous Phrase, and using the [Pairs and Phrases panel](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/Pairs-and-Phrases-panel/).
8. Auto wrap toggle that can be used to apply or remove wrap to the text in the Glyph window.
9. Text Bar toggle that shows or hides the [Text Bar](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/Using-the-Glyph-Window/#using-the-text-bar). There, you can edit the “source” of the text that is shown in the Glyph window.

[flvi_GW-PropertyBar_active_text]: flvi_GW-PropertyBar_active_text.png width=572px height=25px