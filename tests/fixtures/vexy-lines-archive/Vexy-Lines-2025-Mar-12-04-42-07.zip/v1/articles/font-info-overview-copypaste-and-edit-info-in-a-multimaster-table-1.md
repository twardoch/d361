## Metadata_Start 
## code: en
## title: Font Info > Overview copy-paste and edit info in a multi-master table 
## slug: font-info-overview-copypaste-and-edit-info-in-a-multimaster-table-1 
## seoTitle: Font Info > Overview copy-paste and edit info in a multi-master table 
## description:  
## contentType: Markdown 
## Metadata_End

**Font Info \> Overview: copy-paste and edit info in a multi-master table**

If you wnt to copy some Font Info data from the current master to multiple (or all) masters of the current or another font, the Copy-paste buttons in Font Info won’t help, because multiple masters cannot all correspond to one master. But there is another method:

The new Overview page of Font Info shows the most important Font Info data in form of a table, where each font master is a column. You can quickly compare the data across your masters, and you edit the values directly there.

[![][fl7-fontinfo-overview]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-fontinfo-overview.png)

Copy-paste and edit Font Info in Overview page

You can select and copy some cells (some settings for one master), and paste the values to corresponding cells of another master, and even to another font.

Also, you can select some Font Info \> Overview cells, copy them and paste them to a text editor or a spreadsheet app (such as Microsoft Excel, Apple Numbers or Google Spreadsheets). You can edit the data there, copy, and paste back into Font Info Overview!

[fl7-fontinfo-overview]: fl7-fontinfo-overview.png width=446px height=288px