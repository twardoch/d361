## Metadata_Start 
## code: en
## title: Removing links 
## slug: removing-links-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

#### \#\# Removing links

To remove links between all Power guides and nodes in a glyph select the Glyph \> Disconnect Power Guides menu command. Notice that if you move the Power guides after this operation, they will still move proportionally, but the glyph will not be modified. 

To remove links from a particular node, select the Magnet tool from the Toolbar, position the mouse cursor on that node, press the mouse button and drag somewhere in the white space, and then release. All links originating from this node will be removed.