## Metadata_Start 
## code: en
## title: Deleting the Sketchboard Contents 
## slug: deleting-the-sketchboard-contents 
## seoTitle: Deleting the Sketchboard Contents 
## description:  
## contentType: Markdown 
## Metadata_End

To delete everything from the Sketchboard, select Window \> Clear Sketchboard.

| :----- |
| The Sketchboard itself cannot be deleted, just its contents. |