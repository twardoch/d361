## Metadata_Start 
## code: en
## title: App data folder 
## slug: app-data-folder 
## seoTitle: App data folder 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab’s own data files are installed within the FontLab application package on Macintosh, or in the FontLab folder where the .exe file was installed. The folder is named “Resources” and includes “Data”, “Codepage”, “Encoding” and “Python” subfolders. FontLab allows you to override its default data files in these subfolders with your own custom data, in a different location. The original FontLab files are preserved, but your files take precedence. Note that this means that if you have a custom file for some purpose, and update to a newer FontLab build, you will still be getting the effect of your custom file — even if the file provided by FontLab is newer or more extensive.

/Applications/FontLab 7.app/Contents/Resources on macOS