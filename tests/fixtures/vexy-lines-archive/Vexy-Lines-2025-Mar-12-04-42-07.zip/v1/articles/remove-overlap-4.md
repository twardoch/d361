## Metadata_Start 
## code: en
## title: Remove Overlap 
## slug: remove-overlap-4 
## seoTitle: Remove Overlap 
## description:  
## contentType: Markdown 
## Metadata_End

Previously, Contour \> Remove Overlap would sometimes perform a Clean Up operation after removing overlaps, which resulted in additional nodes being removed. When you choose Remove Overlap now, FontLab will keep unchanged all the nodes which were not part of the overlaps.