## Metadata_Start 
## code: en
## title: Move nodes or handles with cursor keys after dragging 
## slug: move-nodes-or-handles-with-cursor-keys-after-dragging 
## seoTitle: Move nodes or handles with cursor keys after dragging 
## description:  
## contentType: Markdown 
## Metadata_End

When you drag a node or a handle to move it, it now becomes selected, so you can instantly move it further using cursor keys. Previously, clicking a node or handle selected it, but just dragging it left it unselected.