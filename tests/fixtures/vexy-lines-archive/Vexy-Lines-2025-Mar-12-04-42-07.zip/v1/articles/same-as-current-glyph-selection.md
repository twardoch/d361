## Metadata_Start 
## code: en
## title: Same as current glyph selection 
## slug: same-as-current-glyph-selection 
## seoTitle: Same as current glyph selection 
## description:  
## contentType: Markdown 
## Metadata_End

The current glyph in the Font window (the glyph cell that has a white caption on a blue background, and a dark glyph cell preview) may has particular properties that interest you. In the Select context submenu:

*Same Flag*

* Selects all glyph cells that have the same color flag as the current layer of the current glyph
* If the current glyph has no color flag, selects all glyphs that have no color flag

*Same Script*

* Selects all glyphs that belong to the same Unicode script as the current glyph; for example if your current glyph is “A”, selects all Latin letters
* Also selects alternate glyphs that have no Unicode

*Same Category*

* Selects all glyphs that belong to the same Unicode category as the current glyph; for example if your current glyph is “A”, selects all uppercase letters

*Same Tags*

* Selects all glyphs that have the identical set of tags as the current glyph
* To select glyphs by individual tag, use the Classes panel
* To assign tags to multiple glyphs, select them in Font window, open the Glyph panel (Cmd+I) and in the Tags field, enter the tags prefixed by +

If you have multiple glyph cells selected, and you open the context menu and navigate to the Select submenu:

* Click any of the Same… menu items to select only the glyph cells that match the single current glyph.
* Shift-click the menu item to add the matching glyph cells to your current Font window selection.