## Metadata_Start 
## code: en
## title: Layer scope 
## slug: layer-scope 
## seoTitle: Layer scope 
## description:  
## contentType: Markdown 
## Metadata_End

Use the Layers toggles to decide on which layers in the chosen glyphs the action is performed.

* Current runs the action in the chosen glyph(s) on the layer chosen in the Layers & Masters panel or in the window property bar. Previously the toggle was called Active Layer.
* Visible runs the action in the chosen glyph(s) on the layers which are set as visible in the “eye” column of the Layers & Masters panel.
* All Masters runs the action in the chosen glyph(s) on all master layers (which belong to a font master or are a font-less master)

When you change the layer scope, the Actions preview shows how the action will change the current layer. There is no preview that shows how the action affects the other layers.

When you open Tools \> Actions from the Glyph window, choose Glyphs \> Window, and the Actions preview will show the same glyphs as shown in your window. Choose the action, tweak its parameters, and when you’re happy with the previewed result, you can then choose Glyphs \> All to run the action on all glyphs. Previously, it was difficult to easily preview the desired glyphs in the Actions dialog.