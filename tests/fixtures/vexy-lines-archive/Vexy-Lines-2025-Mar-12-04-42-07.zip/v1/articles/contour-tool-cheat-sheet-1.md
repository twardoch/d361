## Metadata_Start 
## code: en
## title: Contour tool “cheat sheet” 
## slug: contour-tool-cheat-sheet-1 
## seoTitle: Contour tool “cheat sheet” 
## description:  
## contentType: Markdown 
## Metadata_End

![][fl711-help-panel]

FontLab 7.1.1 has a new “cheat sheet” for the Contour tool. When you’re in the Glyph window and the Contour tool is active, tap Shift+F1 or open Help \> Help Panel. Resize the panel and dock as needed. Now you always have all the powerful keyboard shortcuts of FontLab’s contour editor at a glimpse. Tap Shift+F1 to hide the Help Panel again.

The Help Panel is contextual —it changes its contents when a tool or a large dialog is active. You can also hover over a specific UI element and hold F1 (without Shift) to see Quick Help, the ultra-compact help balloons.

[fl711-help-panel]: fl711-help-panel.png width=200px height=417px