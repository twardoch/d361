## Metadata_Start 
## code: en
## title: Appearance of automatically-named anchors 
## slug: appearance-of-automaticallynamed-anchors 
## seoTitle: Appearance of automatically-named anchors 
## description:  
## contentType: Markdown 
## Metadata_End

When you choose Glyph \> Add Anchor (CtrlR) or right-click the Glyph window canvas and choose Add Anchor, FontLab automatically adds an anchor. When you do it once, and the glyph is a mark glyph, it adds a \_top anchor, otherwise a top anchor. When you do it again, FontLab adds \_bottom for a mark glyph or bottom. Once again: \_left or left, then once again: \_right or right. When FontLab 7.1.2 adds these anchors, it assigns them the triangle appearance. The triangle always points to the direction of the attachment. For example, when you add a top anchor this way, it’s displayed as an upwards-pointing triangle, and when you add \_top, it’s displayed as a bottom-pointing triangle.