## Metadata_Start 
## code: en
## title: Lookup 
## slug: lookup 
## seoTitle: Lookup 
## description:  
## contentType: Markdown 
## Metadata_End

A lookup is a named set of rules inside a feature. More than just a way to organize the rules, lookups are essential to achieve proper results due to three aspects:

1. The way lookups are presented defines the order the rules are processed;
2. A lookup can be invoked in another rule, saving large amounts of code;
3. Exceptions can be set inside a lookup so they are applied just to its rules.

Consult the reference for further details about lookups.