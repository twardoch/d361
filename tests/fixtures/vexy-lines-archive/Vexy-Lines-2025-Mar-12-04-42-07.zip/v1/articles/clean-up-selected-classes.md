## Metadata_Start 
## code: en
## title: Clean Up Selected Classes 
## slug: clean-up-selected-classes 
## seoTitle: Clean Up Selected Classes 
## description:  
## contentType: Markdown 
## Metadata_End

The Clean Up Selected Classes command will remove any glyphs from selected classes that are not present in the font (remember that classes can be defined using glyphnames and not all glyphs must necessarily exist in the font).