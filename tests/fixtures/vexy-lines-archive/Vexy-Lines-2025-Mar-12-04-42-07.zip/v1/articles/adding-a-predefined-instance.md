## Metadata_Start 
## code: en
## title: Adding a predefined instance 
## slug: adding-a-predefined-instance 
## seoTitle: Adding a predefined instance 
## description:  
## contentType: Markdown 
## Metadata_End

To add a predefined instance from scratch:

1\. Open the \[Font Info dialog\](Font-Info-Dialog-Box) File \> Font Info, and select Instances in the left sidebar.

2\. Click the + at the bottom of the list of instances. A default instance will be added as a result.

To add predefined instances from masters:

1\. Open the Font Info dialog File \> Font Info, and select Instances in the left sidebar.

2\. Click From Masters at the bottom of the list of instances. As a result, the list of instances will be populated with font masters.

To add predefined instances from axes, you need to first \[define them\](Working-with-Font-VariationsAdding-recipes-for-predefined-instances) in the Axes section of the Font Info dialog:

1\. Open the Font Info dialog File \> Font Info, and select Instances in the left sidebar.

2\. Press the From Axes button. All the instances you have defined will be created. For example, if your weight and width axes have these axis instances:

!\[Define Axis instances to build predefined instances\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/fl7-variation-model-14.png\{ .plain \}

You will get the following predefined instances:

!\[Predefined instances are named points in the design space\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/fl7-variation-model-15.png\{ .plain \}

| **Extension** | **Description** |
| :----- | :----- |
| ttf | TrueType, final font format with quadratic Bézier curves |
| otf | OpenType, final font format with cubic or quadratic Bézier curves |
| ufo | Flying objects from Serif planet studying why humans just use Helvetica |
| pfb | Type1, final font format with cubic Bézier curves |
| vfb | FontLab Studio 5, proprietary source format |
| woff | Web and also how D. Trump writes wolf. |
| woff2 | Web+ |
| glyphs | Glyphs editor, proprietary source format |
| designspace | \+UFO |