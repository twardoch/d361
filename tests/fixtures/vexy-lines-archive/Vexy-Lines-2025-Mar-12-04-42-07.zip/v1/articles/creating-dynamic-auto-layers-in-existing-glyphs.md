## Metadata_Start 
## code: en
## title: Creating dynamic auto layers in existing glyphs 
## slug: creating-dynamic-auto-layers-in-existing-glyphs 
## seoTitle: Creating dynamic auto layers in existing glyphs 
## description:  
## contentType: Markdown 
## Metadata_End

To replace existing content in existing glyphs with dynamic auto layers:

* To turn on Auto Layer for all masters of a glyph, select its glyph cell in Font window and in the Font window status bar, turn on Auto Layer. This converts all masters of that glyph into dynamic auto layers. Alternatively, Alt-click the Glyph menu and choose Auto Glyph or Alt-click the Auto layer button in the Layers & Masters panel or in the Glyph window property bar. This only works for one glyph at a time.
* To turn on Auto Layer for the current glyph layer, choose Glyph \> Auto Layer, or click the Auto layer button in the Layers & Masters panel or in the Glyph window property bar.