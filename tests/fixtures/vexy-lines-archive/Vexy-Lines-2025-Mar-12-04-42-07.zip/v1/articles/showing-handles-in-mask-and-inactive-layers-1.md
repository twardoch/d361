## Metadata_Start 
## code: en
## title: Showing handles in Mask and inactive layers 
## slug: showing-handles-in-mask-and-inactive-layers-1 
## seoTitle: Showing handles in Mask and inactive layers 
## description:  
## contentType: Markdown 
## Metadata_End

As previously, in Preferences \> Glyph Window \> Inactive, you can decide how the Glyph window shows nodes when View \> Show \> Nodes is off and nodes in *inactive elements*. You can *hide* them or show them in *tiny* or slightly *larger* size.

This affects how nodes in contours are shown when the Element tool is active. It also controls node display with Contour tool and other contour editing tools:

* when View \> Show \> Nodes is off (except those over which you hover your pointer)
* in inactive elements when you have several unlocked elements (but not components) in the current glyph layer
* in the other glyphs when Edit \> Edit Across Glyphs is on, but Edit Across Elements is off
* in the Mask layer, if View \> Show \> Mask is on
* in other visible layers that are *shown as wireframes*

Finally, the second setting (*tiny*) shows smaller nodes with the Brush, Pencil, Rapid and Pen tools.

But what about handles (Bézier control points or BCPs)? In FontLab 7, you can see handles in the Mask layer and in other layers (masters):

![][fl7-prefs-inactive-handles]

Preference to show handles in masks and inactive layers

* if you turn on the new Handles toggle in Preferences \> Glyph Window \> Inactive, and the nodes are not hidden in this setting
* and if View \> Show \> Handles is on
* for Mask, if View \> Show \> Mask is on
* for other layers (masters) if the layers are visible and *shown as wireframes* (see the *Show inactive layers as wireframes* section for details)

The new Handles toggle does *not* affect how the Glyph window shows handles in other inactive elements on the current layer. However:

* You can see (and edit) the handles of other glyphs with Edit Across Glyphs and …Elements both on.
* You can always see handles with Rapid and Pen if View \> Show \> Handles is on, but the second node in inactive elements setting (tiny) shows them smaller.

[fl7-prefs-inactive-handles]: fl7-prefs-inactive-handles.png width=122px height=25px