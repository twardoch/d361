## Metadata_Start 
## code: en
## title: Placeholder Font 
## slug: placeholder-font 
## seoTitle: Placeholder Font 
## description:  
## contentType: Markdown 
## Metadata_End

Use this option to select the font that will be used as template for empty glyph cells. Click Reset to set the font back to the default font. You can also choose how you would like missing glyphs to be shown by selecting an option from Missing Glyph.

Other options that control how the Font Window looks are:

\| Option \| Description \|

\| Show grid lines \| Draws thin grey borders between glyph cells \|

\| Show glyph metrics \| If cells are large enough, the advance width is shown with a lighter background so left and right glyph sidebearings are visible \|

\| Show hinting icons \| Draws small hinting marks in the lower left corner of glyph cell having hints \|

\| Show note icon \| Draws the note icon if glyphs have Glyph Notes \|

\| Show note text if possible \| If cells are large enough, the note text is shown \|