## Metadata_Start 
## code: en
## title: Selecting and Deselecting Elements 
## slug: selecting-and-deselecting-elements 
## seoTitle: Selecting and Deselecting Elements 
## description:  
## contentType: Markdown 
## Metadata_End

* To select an element, click it with the Element tool selected.
* To select several elements, click each of them with the Element tool holding the Shift key down. When you click, position the mouse cursor over contours (and not any counters).
* To deselect element(s), press the Esc key.

Use the Edit \> Invert Selection (Cmd+I) operation to deselect the selected elements and select the rest. This command works only within the current glyph.