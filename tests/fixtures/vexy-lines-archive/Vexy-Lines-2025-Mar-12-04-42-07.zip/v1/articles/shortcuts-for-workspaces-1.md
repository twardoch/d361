## Metadata_Start 
## code: en
## title: Shortcuts for Workspaces 
## slug: shortcuts-for-workspaces-1 
## seoTitle: Shortcuts for Workspaces 
## description:  
## contentType: Markdown 
## Metadata_End

On macOS, you can use Alt+Cmd+1 to Alt+Cmd+6 to switch between the predefined workspaces (panel sets).