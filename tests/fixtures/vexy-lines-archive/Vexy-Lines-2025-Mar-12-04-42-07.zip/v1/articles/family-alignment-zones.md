## Metadata_Start 
## code: en
## title: Family Alignment Zones 
## slug: family-alignment-zones 
## seoTitle: Family Alignment Zones 
## description:  
## contentType: Markdown 
## Metadata_End

To support the common appearance of fonts that belong to the same font family the PostScript hinting system allows so-called FamilyBlues, alignment zones that are used in the whole font family. Typically the alignment zones of the regular weight are used as Family Blues in all members of the family.

To set family alignment zones click the Set family alignment zones radio button. Then edit the alignment zones as usual. To return to editing “local” alignment zones click the Set local alignment zones radio button.

You also can copy family alignment zones defined for the current font to any other font opened in FontLab Studio. Just press the Copy family zones button and select the destination font in the appeared dialog box: