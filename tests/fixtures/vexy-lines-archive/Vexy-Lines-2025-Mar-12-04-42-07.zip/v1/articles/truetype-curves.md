## Metadata_Start 
## code: en
## title: TrueType curves 
## slug: truetype-curves 
## seoTitle: TrueType curves 
## description:  
## contentType: Markdown 
## Metadata_End

TrueType curves are 2nd order curves (i.e. quadratic B-splines). They are defined by two nodes (or on-curve points) and one control point (or off-curve point).

contours\_05.png

Some TrueType curves may appear linked together and form a long curve with off-curve points only. In such curves, the intermediate nodes do not exist explicitly, but are implied by the rasterizer. Each handle is connected to both the points before and after it, whether those are nodes or handles.

contours\_06.png

Off-curve points of the TrueType curves are light-blue in color mode appearance.