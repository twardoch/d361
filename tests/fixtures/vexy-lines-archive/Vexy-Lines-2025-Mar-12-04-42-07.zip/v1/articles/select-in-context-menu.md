## Metadata_Start 
## code: en
## title: Select in context menu 
## slug: select-in-context-menu 
## seoTitle: Select in context menu 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab offers a powerful Select \> submenu to the context menu of the Font window (right-click or Ctrl-click)

![][selectfwmenu-r]

Quickly select related glyphs in Font window

With the Select submenu items, you can select any glyph cells that are *visible*, based on several criteria.

* When the Hide unfiltered glyphs toggle in the Font window context bar is on, only glyphs within the current Font window filter can be selected.
* When the toggle is off, FontLab can select any glyphs in the font.

[selectfwmenu-r]: selectfwmenu-r.jpg width=215px height=307px