## Metadata_Start 
## code: en
## title: Removing classes and tag groups 
## slug: removing-classes-and-tag-groups 
## seoTitle: Removing classes and tag groups 
## description:  
## contentType: Markdown 
## Metadata_End

To remove a class or tag group, select it in the list and click the – button.

To remove all classes, click the local menu button and choose the Remove All Classes command. It will remove classes but leave the tags intact.

Note that virtual tags cannot be removed at all.