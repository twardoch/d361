## Metadata_Start 
## code: en
## title: Guides Context Menu 
## slug: guides-context-menu 
## seoTitle: Guides Context Menu 
## description:  
## contentType: Markdown 
## Metadata_End

More commands related to a guide are available in a its context popup menu. The content of the context popup menu depends on the guide type. For example, a glyph guide’s popup menu contains the Copy to Font command, while a font guide’s popup menu will contain the Copy to Glyph command.

* Copy to Glyph command will create a new glyph guide on top of the element one or the font one.
* Copy to Font command will create a new font guide on top of the glyph one.
* Create Orthogonal CW and CCW commands create a guide that is orthogonal to the current one.
* Proportional Marks trigger to allow/not allow guide markers to change their positions when the length of a vector guide changes.

The commands in the Colors submenu allow you to change colors of individual guides.

The Snap trigger allows you to turn off snapping for that individual guide. If it is turned off for a guide, nodes will not snap to the guide regardless of the state of View \> Snap \> Font Guides and View \> Snap \> Guides commands.

And finally, you can Lock any guide, in case you wish to move it only occasionally or not change it at all.