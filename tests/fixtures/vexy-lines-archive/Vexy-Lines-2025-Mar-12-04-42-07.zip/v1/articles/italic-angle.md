## Metadata_Start 
## code: en
## title: Italic Angle 
## slug: italic-angle 
## seoTitle: Italic Angle 
## description:  
## contentType: Markdown 
## Metadata_End

Actual italic or oblique angle for the font. The italic angle is measured in the counterclockwise direction, but FontLab shows it positive here. So the default value is 12º. Use this field if you are creating an italic font.