## Metadata_Start 
## code: en
## title: Using Rapid Tool 
## slug: using-rapid-tool 
## seoTitle: Using Rapid Tool 
## description:  
## contentType: Markdown 
## Metadata_End

When drawing with the Rapid tool, to change the type of connection, double-click the node.