## Metadata_Start 
## code: en
## title: Include in VFJ 
## slug: include-in-vfj 
## seoTitle: Include in VFJ 
## description:  
## contentType: Markdown 
## Metadata_End

The same windows and panels options available for VFC files are also possible to VFJ format. And also:

* *Session:* if enabled, it will include timestamps of last modification of the glyphs. If you use a version control system, the option **not to** include timestamps is more suitable.
* *Save VFJ when saving VFC:* whenever you save as .vfc, FontLab also saves a JSON-compatible .vfj file in the same folder. The VFJ contains the same information as the VFC save format but is human-readable.
* *Prettify VFJ:* when on, this will make the saved JSON more human-readable thanks to line breaks and indentations, although the file size will increase.