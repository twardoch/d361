## Metadata_Start 
## code: en
## title: Export large Asian OpenType fonts 
## slug: export-large-asian-opentype-fonts 
## seoTitle: Export large Asian OpenType fonts 
## description:  
## contentType: Markdown 
## Metadata_End

If you export an OpenType font with the `post` v2 table, which uses `cidXXXX` glyph naming, FontLab now exports the names using the `_XXXX` naming scheme.