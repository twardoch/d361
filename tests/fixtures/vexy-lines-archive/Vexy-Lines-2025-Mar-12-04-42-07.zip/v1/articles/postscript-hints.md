## Metadata_Start 
## code: en
## title: PostScript hints 
## slug: postscript-hints 
## seoTitle: PostScript hints 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab now exports PostScript hints into UFO in a new, UFO3-compliant, format *public.postscript.hints*.

FontLab treats PostScript hints with the fractional portion .5 like integer values, and does not rounded them. In Adobe fonts that use integer coordinates, a hint that goes through the middle of a slightly tilted horizontal or vertical line segment is used to align that segment. If the height/width of the tilt has an odd value, the hint in the middle has a “half” value.

When you create a composite glyphs using Font \> Generate Glyphs or double-click an empty Font window cell, FontLab no longer copies PS hints from the component source glyphs. Composite glyphs do not need hints at this point. FontLab will copy the hints when you decompose the composite glyph or when you export the font as OpenType PS.