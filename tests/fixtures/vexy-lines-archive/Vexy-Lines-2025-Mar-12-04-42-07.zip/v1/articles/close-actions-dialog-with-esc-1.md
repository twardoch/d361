## Metadata_Start 
## code: en
## title: Close Actions dialog with Esc 
## slug: close-actions-dialog-with-esc-1 
## seoTitle: Close Actions dialog with Esc 
## description:  
## contentType: Markdown 
## Metadata_End

When you open Tools \> Actions (Shift+Cmd+T / Shift+Ctrl+T), you can now press the Esc key to close the Actions dialog without performing any actions.