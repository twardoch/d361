## Metadata_Start 
## code: en
## title: Make SVG Editable 
## slug: make-svg-editable-1 
## seoTitle: Make SVG Editable 
## description:  
## contentType: Markdown 
## Metadata_End

When you import an SVG graphic and choose Element \> Image \> Make SVG Editable, FontLab converts the contours and images contained in the SVG into editable elements. When FontLab makes SVG editable, it now ignores invisible SVG objects that have the display="none" property.