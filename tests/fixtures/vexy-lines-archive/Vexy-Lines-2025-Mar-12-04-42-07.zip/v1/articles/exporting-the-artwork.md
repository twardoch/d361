## Metadata_Start 
## code: en
## title: Export Your Artwork 
## slug: exporting-the-artwork 
## seoTitle: Export Your Artwork 
## description:  
## contentType: Markdown 
## Metadata_End
Once you've created your artwork in Vexy Lines, you can export it for use in other applications or for final production. Whether you need vector graphics for scaling or raster images for web use, Vexy Lines provides flexible export options.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-R4Z8GS67.png){height="" width="392"}

## Vector Export

Export your artwork as scalable vector graphics in several formats:
- **PDF** (Portable Document Format)
- **SVG** (Scalable Vector Graphics)
- **EPS** (Encapsulated PostScript)

### Export Options

You can choose how your layers are exported. Export all layers together as a single file, export layers separately as individual files, or combine layers with the same color into color-based folders. This flexibility is particularly useful when working with print shops, continuing work in other vector editors, or creating files for different production methods.

## Raster Export

For web use or when vector formats aren't needed, you can export your work as raster images. Choose from PNG (with transparency support), JPEG (for smaller file sizes), or BMP (Windows Bitmap).

When exporting raster images, you can adjust several settings to get exactly what you need. Set specific dimensions in pixels, choose between color or grayscale, adjust transparency for PNG files, or select a background color for your image.

## Export Your Artwork

To export your artwork:
1. Go to **File** > **Export** in the menu
2. Choose your desired **format**
3. Adjust **export settings** as needed
4. Select **destination** and filename
5. Click **Export** to complete

> Note: Export features require a registered version of Vexy Lines. The trial version allows you to test the features but won't save the final files.

## Clipboard Operations

For quick transfers between applications, you can copy selected elements to the clipboard and paste them directly into vector editors like Adobe Illustrator or Affinity Designer. This maintains vector properties for further editing.

> Remember: If you plan to edit your artwork further in another application, vector formats (particularly SVG) typically offer the most flexibility and maintain the highest quality.