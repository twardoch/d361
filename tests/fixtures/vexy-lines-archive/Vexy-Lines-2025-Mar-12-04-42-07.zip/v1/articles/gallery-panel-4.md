## Metadata_Start 
## code: en
## title: Gallery panel 
## slug: gallery-panel-4 
## seoTitle: Gallery panel 
## description:  
## contentType: Markdown 
## Metadata_End

The Gallery panel shows named elements in the current master. If you assign a name to an element, it will appear in the Gallery. Elements that have the same content and name that are used in different glyphs within the same master are called *element references*. In FontLab 7.1:

* In the Gallery panel, you can select one or more elements.
* Then use BkSp and Del to remove the elements selected in the Gallery.

When you remove an element from the Gallery, FontLab removes its name (so the element no longer shows up in the Gallery), but keeps the elements in the glyphs.

You can also select one element in the Gallery panel and use Edit \> Copy (Cmd+C / Ctrl+C). When you then activate the Glyph window:

* Edit \> Paste (Cmd+V / Ctrl+V) will paste the content of the copied element as an unlinked copy into the current glyph layer
* Edit \> Paste Element Reference (Cmd+Shift+P / Ctrl+Shift+P) will paste an element reference into the current glyph layer (same as using the Place button in the Gallery panel)

When you activate the Font window, you can paste into the current master of the selected glyphs.