## Metadata_Start 
## code: en
## title: Clean Up 
## slug: clean-up 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

**Clean Up** ==Contour > Clean Up== attempts **to remove unnecessary nodes from your outlines**. It will do so by approximating a segment of the contour with a curve. It differs from [[Simplify]] in that it will **not add new nodes** to your contours; and will be less aggressive in removing points, therefore keeping the contour shape closer to the original.

This operation can be applied to a single glyph if it is open in the [[Glyph Window]], or you can select several glyphs in the [[Font Window]] or [[Font Map panel]] and run the operation on all of them together. Apart from the ==Contour== menu, this operation is also found in [[Contour actions]] in ==Tools > Actions=.
