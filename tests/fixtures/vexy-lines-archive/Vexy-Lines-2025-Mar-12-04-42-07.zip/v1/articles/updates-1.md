## Metadata_Start 
## code: en
## title: Updates 
## slug: updates-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

<!--- Other -->

FontLab is updated regularly with bug fixes. It has a mechanism to check for updates, so you can always have the latest version. The Public Preview will not be updated and will eventually expire with the release version of FontLab. After that, only the release version will be updated. Learn more about the installation and requirements of the release version [here](Installation-and-Requirements).

Just launching the app should trigger a check for updates, unless you have turned it off in ==Preferences > General > Check for updates on startup==. Right next to that preference is a button to “Check for updates now,” so you can manually check for updates at any time.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-update_prefs.png)

The “About” screen shows the version of the current build. This is a normal version such as 7.0.0.7258. The last few digits are a “build number” that is actually a date — the number of days since January 1, 2000, on the day the build was made.

If FontLab finds an update, it suggests you to download and install it, but you can postpone this operation if you prefer.

When you choose to download, the download link is passed to your default web browser, and the download starts. The file will be downloaded to your browser’s default download location, typically a “Downloads” directory, or your Desktop.

FontLab does not overwrite or interfere with the operation of FontLab Studio 5. If you want, you can even keep a previous version of FontLab: just rename the existing installed application before installing the updated version. 

Navigate to your downloads location. Double-click the downloaded file: this will run the FontLab Installer on Windows, or mount the disk image on MacOS. The process of the update install is the same as the initial install. The updated app doesn’t need to be activated again; it should work without asking for your serial number.

NOTE: MAC OS X has a security feature called GateKeeper which may prevent FontLab from starting. If that is the case right-click the FontLab icon and choose ==Open==. Then click the **Open** button at the next dialog warning to launch FontLab anyway.
