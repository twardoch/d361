## Metadata_Start 
## code: en
## title: Element references and filters 
## slug: element-references-and-filters 
## seoTitle: Element references and filters 
## description:  
## contentType: Markdown 
## Metadata_End

When you apply a filter like Delta, Skin, Fill, Glue, Power Brush or Power Stroke to an element reference, FontLab by default applies the filter “inside” the element, so the result of the filter is visible in all element references. This is not always desired.

You can now use the two commands in the ==Element > Element References== menu to change this behavior.

- Select an element reference that has filters applied and choose ==Unlink Filter==: FontLab will apply the filter “outside” the current element, and will remove the filter from other references that point to the current element.
- Select an element reference that has unlinked filters and choose ==Link Filter==: FontLab will apply the element’s filters “inside” the element, so their results will become visible in all references that point to the current element.
