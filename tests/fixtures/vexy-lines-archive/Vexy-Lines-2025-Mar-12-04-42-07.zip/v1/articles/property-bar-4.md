## Metadata_Start 
## code: en
## title: Property Bar 
## slug: property-bar-4 
## seoTitle: Property Bar 
## description:  
## contentType: Markdown 
## Metadata_End

The Glyph Window has its own property bar, with controls related to the glyph contents. In the Interface reference chapter there is a complete description of the property bar in each situation.

![][gwdefaultbar-r]

Initial property bar for Glyph Window

The Property bar of a Glyph Window can have items hidden when there is no room to show all their controls:

![][gwsmall-r]

[gwdefaultbar-r]: gwdefaultbar-r.jpg width=576px height=50px

[gwsmall-r]: gwsmall-r.jpg width=202px height=195px