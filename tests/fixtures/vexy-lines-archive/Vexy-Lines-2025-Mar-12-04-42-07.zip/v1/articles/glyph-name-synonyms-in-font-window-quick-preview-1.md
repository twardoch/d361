## Metadata_Start 
## code: en
## title: Glyph name synonyms in Font window quick preview 
## slug: glyph-name-synonyms-in-font-window-quick-preview-1 
## seoTitle: Glyph name synonyms in Font window quick preview 
## description:  
## contentType: Markdown 
## Metadata_End

When you hold Space in the Font window, a quick preview popup of the current glyph cell appears with additional information. The top portion of the popup now lists all synonyms available in the standard.nam database for the current glyph name.