## Metadata_Start 
## code: en
## title: Guides and grid 
## slug: guides-and-grid 
## seoTitle: Guides and grid 
## description:  
## contentType: Markdown 
## Metadata_End

* Deleting guides. When you delete a guide, the Guides panel no longer shows that guide’s info. The guide is no longer undead. 
* Rounding font guides. If Contour \> Coordinates \> Round when Editing is on and you Shift-drag-and-drop from the Ruler to create a font guide, the guide’s initial position now rounded as expected. 
* Quick calculations for guides. You can now use quick calculations (e.g. entering +20 after the current value) consistently in the guide position and width fields in the property bar and in the Guides panel. Previously, quick calculations did not work in some of these fields. 
* Anchors and pins on the Grid. When you turn on Preferences \> Grid \> Round nodes, guides and anchors to grid points, and you have View \> Show Grid and View \> Snap \> Grid on, pins and anchors will now hard-snap (round) to grid points. Previously, nodes and guides did snap but pins and anchors did not.