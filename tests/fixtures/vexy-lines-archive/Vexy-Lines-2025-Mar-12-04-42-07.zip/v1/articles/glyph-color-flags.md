## Metadata_Start 
## code: en
## title: Glyph color flags 
## slug: glyph-color-flags 
## seoTitle: Glyph color flags 
## description:  
## contentType: Markdown 
## Metadata_End

The ==Glyph== menu now includes the ==Flag== submenu which was previously only available in the Font window context menu.

The entries of the ==Flag== submenu are now also available in the ==Tools > Commands & Shortcuts== dialog, so you can assign custom keyboard shortcuts to them, and you can quickly flag glyphs by pressing ++Shift+Cmd+P++ and typing `Red` or `Green` . ~~#6092~~

![Glyph panel (collapsed)](https://i.fontlab.com/fl8/rn/fl8-rn8-glyph-panel-collapsed.png){ .plain .r data-scale='50%' }

If the ==Glyph== panel is collapsed, the background of the area around the glyph name icon now shows the color flag applied to the glyph.
