## Metadata_Start 
## code: en
## title: Exporting fonts 
## slug: exporting-fonts-5 
## seoTitle: Exporting fonts 
## description:  
## contentType: Markdown 
## Metadata_End

When you export a font into the built-in Web TT profile, FontLab now exports .woff2 and .woff, and no longer exports .eot. Previously, FontLab exported .woff and .eot by default. If you need .eot, customize the profile and turn EOT: For IE (TT-only) on.

The default profile for Variable TT no longer tries to export hinting. The export of hinting mostly failed, and in the few cases it worked, it caused problems with the Apple rasterizer. We’ll revisit this issue.