## Metadata_Start 
## code: en
## title: Mask Editing 
## slug: mask-editing-1 
## seoTitle: Mask Editing 
## description:  
## contentType: Markdown 
## Metadata_End
You can easily modify the mask on your chosen **Layer**. Use tools like the **Brush**, **Rectangle**, **Ellipse**, and **Freeform** to draw new sections or erase unwanted areas.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3FDMUCC6.png){height="" width="518"}

For more precise edits, utilize the **Editor** tool. 

Start by selecting a curve on the mask. You can choose multiple curves by holding down the ⇧(shift) key while clicking. Once selected, you can drag individual or multiple points to adjust their positions.

> Dive deeper into the Editor tool's capabilities in the [Editor](/v1/docs/editor) article.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-V7P7Y1N0.png){height="" width="518"}

### Add and Remove Points

**To insert points**, either use the **Knife** tool or simply click on the desired curve spot with the **Editor** tool while holding the ⌥(alt) key.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3L1QORH8.png){height="" width="518"}

**To remove points and segments**, select and delete specific curves using the **Backspace** or **Delete** keys.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-2UJADVVK.png){height="" width="518"}

**To remove the whole mask**, delete all of its curves. Doing so will apply fills to the entire document area.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-A347QJ7T.png){height="" width="518"}
