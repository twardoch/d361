## Metadata_Start 
## code: en
## title: Circular Fill 
## slug: circular 
## seoTitle: Circular 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:circular-->
The **CIRCULAR** fill type in Vexy Lines creates a series of nested circles that start from a central point.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28103%29.png){height="" width="300"}
<!--qh-->

### Fill Parameters:
![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28173%29.jpeg){height="" width="300"}

<!--qh:circularInterval-->
![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) **Interval** ([units](/v1/docs/units)): Specifies the space between the concentric circles. Lower values produce tighter circles, while higher values spread them out.
<!--qh-->

<!--qh:circularDispersion-->
![Randomization](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-dispersion.svg) **Randomization** (%): Adds random variation to the interval distances, giving the pattern a more organic look.
<!--qh-->

<!--qh:circularMiddle-->
![Shift](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-middle.svg) **Shift** (%): Adjusts the phase of the fill pattern by shifting the strokes. A 0% shift means no offset, while 100% produces an offset equal to the interval between strokes.
<!--qh-->

<!--qh:circularCenter-->
![Center](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/center_x.svg) **Center** ([units](/v1/docs/units)): Defines the X and Y coordinates of the fill's central point for precise placement.
<!--qh-->

By adjusting these settings, you can create unique and detailed designs to enhance your digital artwork.

## Creating and Customizing a Circular Fill

To create a new Circular fill, follow the steps in our [Creating a new fill](/v1/docs/creating-new-fill) guide. When the pop-up menu appears, select the "Circular" fill type.

![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2870%29.jpeg){height="" width="160"}

Similar to the [Linear](/v1/docs/linear) fill type, the Circular fill shares the first three parameters—[Interval](/v1/docs/interval), [Randomization](/v1/docs/randomization), and [Shift](/v1/docs/shift). It also includes an additional control: the [Center](/v1/docs/center) parameter, which works like the one in the Radial fill type.

### Interval
1. Find the **Interval** ![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) parameter in the CIRCULAR FILL tab.
2. Adjust the distance between circles by using the slider or entering a value directly.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28119%29.png){height="" width="300"}

<!--qh:circularInterval-->
| interval: 1 | interval: 2 | interval: 3 |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28120%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28121%29.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28122%29.png){height="" width="300"}|
<!--qh-->

### Randomization
1. Locate the **Randomization** ![Randomization](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-dispersion.svg) parameter.
2. Adjust the slider or input a value manually.
3. Increasing this value makes the spacing between circles less uniform.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28124%29.png){height="" width="300"}

<!--qh:circularDispersion-->
| randomization: 10% | randomization: 50% | randomization: 100% |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28106%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28107%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28108%29.jpeg){height="" width="300"}|
<!--qh-->

### Shift
1. Find the **Shift** wave parameter.
2. Adjust the slider or enter a value manually.
3. The Shift parameter modifies the phase of the pattern, changing the starting position of the strokes.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28126%29.png){height="" width="300"}

<!--qh:circularMiddle-->
| shift: 25% | shift: 50% | shift: 90% |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28110%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28111%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28112%29.jpeg){height="" width="300"}|
<!--qh-->

### Center
1. Navigate to the **Center** options within the CIRCULAR FILL section.
2. Two input fields allow you to set the horizontal and vertical coordinates of the fill's center.
3. Adjust these coordinates using the drop-down slider or by entering the values directly.
4. Alternatively, use the "Interactive Center Locator" feature by clicking its button and then clicking on the desired point in your image.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28104%29.png){height="" width="300"}

<!--qh:circularCenter-->
| center: 0,0 | center: 40,40 | center: 40,70 |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2871%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2872%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2873%29.jpeg){height="" width="300"}|
<!--qh-->

## Stroke Properties
Other properties apply to this fill, which you can read about in the relevant articles:
1. [COLOR](/v1/docs/color-strokes)
2. [IMAGE THRESHOLD](/v1/docs/image-threshold)
3. [STROKE THICKNESS](/v1/docs/stroke-thickness)
4. [DASHED LINE](/v1/docs/dashed-line)
5. [STROKE CAPS](/v1/docs/stroke-caps)
6. [EMBOSS](/v1/docs/emboss)
7. [OVERLAP CONTROL](/v1/docs/overlap-control)

## Link to Example
You can use the example file for this article [UM3-Fills-Circular.strx](https://www.tracexz.com/um3/UM3-Fills-Circular.strx) to practice adjusting "Circular" fill parameters.
