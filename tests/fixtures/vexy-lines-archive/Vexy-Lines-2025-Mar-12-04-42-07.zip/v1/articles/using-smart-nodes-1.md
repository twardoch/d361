## Metadata_Start 
## code: en
## title: Using Smart Nodes 
## slug: using-smart-nodes-1 
## seoTitle: Using Smart Nodes 
## description:  
## contentType: Markdown 
## Metadata_End

We call Servant and Genius nodes the \_smart\_ nodes.