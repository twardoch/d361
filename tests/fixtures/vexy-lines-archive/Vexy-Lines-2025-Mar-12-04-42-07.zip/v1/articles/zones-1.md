## Metadata_Start 
## code: en
## title: Zones 
## slug: zones-1 
## seoTitle: Zones 
## description:  
## contentType: Markdown 
## Metadata_End

finfo\_zones.png

The Zones page displays the areas where hinting will align points. See the \[Zones\](Hinting-a-Fontfont-info) section of the Hinting a Font article.