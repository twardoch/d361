## Metadata_Start 
## code: en
## title: Kerning classes in multiple-master or variable fonts 
## slug: kerning-classes-in-multiplemaster-or-variable-fonts 
## seoTitle: Kerning classes in multiple-master or variable fonts 
## description:  
## contentType: Markdown 
## Metadata_End

Kerning classes are defined per master, but when instances or variable fonts are exported, classes from the main master are used (you can set the main master in Font Info \> Masters using the blue radio button). To ensure that you have the same kerning classes in all your masters, visit each master and use the ☰ menu of the Classes panel to Import Classes, picking the main master each time.

When building variable fonts, kerning pairs that don’t exist in corner masters are assumed to have the value 0 but kerning pairs that don’t exist in intermediate masters get the interpolated value.