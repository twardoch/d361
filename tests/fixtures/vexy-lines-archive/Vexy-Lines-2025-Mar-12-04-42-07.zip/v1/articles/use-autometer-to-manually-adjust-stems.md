## Metadata_Start 
## code: en
## title: Use Auto-meter to manually adjust stems 
## slug: use-autometer-to-manually-adjust-stems 
## seoTitle: Use Auto-meter to manually adjust stems 
## description:  
## contentType: Markdown 
## Metadata_End

![Image](https://i.fontlab.com/fl8/rn/fl8-rn4-stems-auto-meter-edit.gif){ .plain .r data-scale='100%' }

If ==Preferences > Glyph Window > Coordinates editable== is turned on, you can click the numerical value of the Auto-meter stem width to change the thickness of the stem. Type a new number, use ++Up++/++Down++ arrow keys or click the ==v== button and use the slider. FontLab applies the change when you press ++Enter++ or click away.

If you use Auto-meter to adjust the stem, FontLab intelligently changes the contours:

- If you’ve changed a X-direction stem (between two vertical contours), FontLab moves the closest nodes to the left and right as needed, and makes small adjustments to the surrounding contours,

- If you’ve changed an Y-direction stem (between two horizontal contours), FontLab moves one of the nodes towards the center of the glyph, and makes small adjustments to the surrounding contours.
