## Metadata_Start 
## code: en
## title: Automatic panning of Glyph window 
## slug: automatic-panning-of-glyph-window 
## seoTitle: Automatic panning of Glyph window 
## description:  
## contentType: Markdown 
## Metadata_End

With ==View > Center Glyph or Pair==, you can control how FontLab automatically pans (horizontally scrolls) the Glyph window to ensure that your current glyph or selection is visible. This works depending on the zoom level, and is especially important when your Glyph window text has more than one glyph.

- If ==View > Center Glyph or Pair== is turned on, the panning is “eager”. The Glyph window scrolls left/right whenever you switch to a different glyph. If the zoom level allows for entire glyphs to fit, the Glyph window will center around the new current glyph. This ensures that your current glyph is always as visible as possible, but results in more “jumpy” experience.

- If ==View > Center Glyph or Pair== is turned off, the panning is “lazy”. If the zoom level allows for entire glyphs to fit, the Glyph window only scrolls left/right if you switch to a glyph that’s not fully visible. If the zoom level is closer, the Glyph window only scrolls if you switch to a glyph that’s not visible at all.

If the ==Contour== tool is active and you make a contour selection, and you switch to a different matching master, or you change the current `#instance` layer with the ==Variations== panel, the Glyph window tries to keep the corresponding selection, and horizontally pans to make sure that the selection is visible.
