## Metadata_Start 
## code: en
## title: Font Families 
## slug: font-families-1 
## seoTitle: Font Families 
## description:  
## contentType: Markdown 
## Metadata_End

A family is a set of one or more related fonts, usually sharing the same family name and similar design aspects. The most frequent set is a family with the stylistic variants regular, **bold**, *italic*, and ***bold-italic***, but there are families with over one hundred fonts. Such a higher number of variants usually include widths from condensed to expanded, weigths from light to heavy, and also optical sizes from caption to headline. But there is no rule about how many fonts a family should embrace —it’s a design choice.

![][typefamily-r]

A type family with weight and optical size variants

*Typographic family name*

The Typographic family name (**TFN** or just “Family” or “Family Name”) is the name under which all fonts from one family are grouped in the font menu of a modern application. It is sometimes called “Preferred family name”. Sometimes a family has only one font. Other times, there are several fonts in a family, which differ from one another in some important design [parameters](https://help.fontlab.com/fontlab/7/manual/Font-Info-Dialog-Box/#parameters).

The Typographic family name may contain spaces but some vendors choose not to use any spaces here. The Typographic family name must be identical in all fonts that need to appear as one family in the font menu of modern applications.

![][familyname-r]

The Family name field in Font Info \> Names

The length of the Typographic family name should be no more than 31 characters. It is recommended to use only uppercase and lowercase English letters, spaces and numerals. Usage of non-English letters and special characters such as underscores, ampersands, accented characters, etc. is strongly discouraged.

*Typographic style name*

The Typographic style name (**TSN** or just “Style”) is the name under which a certain font within a family appears in the font menu of modern applications. It is sometimes called “Preferred style name”.

![][menutfn-r]

An application menu with a font family and its styles

The Typographic style name typically describes the typographic properties of the font within the typographic family. Usually, it consists of a combination of keywords, which describe its design attributes: weight, width and slope. For normal width and plain slope, no keyword is used. For example, if a font’s Weight is defined as Black, its Width is defined as Condensed and its Slope is defined as Plain, then the Typographic style name would typically be “Black Condensed” or “Black Cond” or “Cond Black”. The TSN must be unique for each font with the same Typographic family name.

The TSN may contain spaces. The length of the Typographic style name should be no more than 31 characters. To automatically build the Typographic style name from design attributes, click the Auto button (↺) next to the Style field.

[typefamily-r]: typefamily-r.jpg width=217px height=164px

[familyname-r]: familyname-r.jpg width=339px height=174px

[menutfn-r]: menutfn-r.jpg width=300px height=193px