## Metadata_Start 
## code: en
## title: Elements panel 
## slug: elements-panel-3 
## seoTitle: Elements panel 
## description:  
## contentType: Markdown 
## Metadata_End

The Elements panel now has a + button. Click it to open a popup that lets you:

* Create a new empty Contour Element
* Add a Component by glyph name
* Add an Element Reference by element or glyph name
* Duplicate the selected element as an unlinked copy
* Duplicate the selected element as an Element Reference
* Create a new Sticker

The buttons at the top of the Elements panel for changing the visual stacking order of elements have a new design.

The panel now shows a colorful icon next to elements that have a color fill or a stroke.