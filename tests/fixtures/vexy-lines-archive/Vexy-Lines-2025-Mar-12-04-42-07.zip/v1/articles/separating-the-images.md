## Metadata_Start 
## code: en
## title: Separating the images 
## slug: separating-the-images 
## seoTitle: Separating the images 
## description:  
## contentType: Markdown 
## Metadata_End

If you imported a set of image files, each representing one glyph, they will all appear as separate elements (with shape frames, as shown in the image below, if that has been selected in the View panel), and you can see them listed in the Elements panel:

![][from_color_bitmaps_04]

In this case, you can skip to the next step.

If you imported one large image file, you will need to divide it into elements:

1. Open Preferences \> Operations and turn off the option to “recognize alphabetic characters” in Optical Separation.
2. Now, click the image once to select it and choose the Element \> Optically Separate menu command.

One image element will be separated into smaller elements. You can select, move, scale or free transform each element separately using the Element tool.

[from_color_bitmaps_04]: from_color_bitmaps_04.png width=276px height=68px