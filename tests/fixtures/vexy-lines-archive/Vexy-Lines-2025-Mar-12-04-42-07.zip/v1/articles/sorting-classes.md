## Metadata_Start 
## code: en
## title: Sorting classes 
## slug: sorting-classes 
## seoTitle: Sorting classes 
## description:  
## contentType: Markdown 
## Metadata_End

To sort classes by their type and names, click the Class column title in the list of classes. OpenType classes sorted by their names go first in the list, then 1st classes and finally 2nd classes.

To sort classes by the number of members, click the Size column title in the list of classes.

To manually reorder classes, just select them and drag-drop lower or higher in the list.