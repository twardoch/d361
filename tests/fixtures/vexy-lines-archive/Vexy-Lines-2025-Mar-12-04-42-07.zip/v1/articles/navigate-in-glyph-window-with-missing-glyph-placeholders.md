## Metadata_Start 
## code: en
## title: Navigate in Glyph window with missing glyph placeholders 
## slug: navigate-in-glyph-window-with-missing-glyph-placeholders 
## seoTitle: Navigate in Glyph window with missing glyph placeholders 
## description:  
## contentType: Markdown 
## Metadata_End

If the text specifies a glyph which is not present in the font, the Glyph window shows a missing glyph placeholder if Preferences \> Editing \> Show missing glyph placeholders is on; or if the preference is off, the Glyph window leaves out any specified glyphs not present in the font. If a Glyph window shows missing glyph placeholders, you can jump over them them when navigating through the text with \[ (Text \> Previous in Text) and \] (Text \> Next in Text). Previously, missing glyph placeholders blocked that navigation.