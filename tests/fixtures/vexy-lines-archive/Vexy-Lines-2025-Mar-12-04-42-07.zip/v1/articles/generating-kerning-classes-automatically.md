## Metadata_Start 
## code: en
## title: Generating kerning classes automatically 
## slug: generating-kerning-classes-automatically 
## seoTitle: Generating kerning classes automatically 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab can automatically generate kerning classes for you if you would like. Click the local menu button in the Classes panel to open the menu and choose the Generate Kerning Classes command:

classes\_panel\_10.png