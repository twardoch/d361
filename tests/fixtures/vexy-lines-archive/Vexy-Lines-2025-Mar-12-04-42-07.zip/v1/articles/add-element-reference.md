## Metadata_Start 
## code: en
## title: Add Element Reference 
## slug: add-element-reference 
## seoTitle: Add Element Reference 
## description:  
## contentType: Markdown 
## Metadata_End

Glyph layers contain elements, and the same element can be used in several glyph layers. If you add an element reference to the current glyph, the new element in your glyph will be linked to the same element in other glyphs — if you change it in one place, it will change in all other places. Named element references appear in the Gallery panel. 

To find an element or glyph to add as a reference, type in its name in the filter field.

Use the Glyphs and Elements buttons in the bottom left of the dialog to choose whether you want to see only elements, only glyphs or both in the dialog.

To use the advance width of the added element, select the Replace advance width option. Otherwise leave the Keep metrics option.

To add an element reference or component, select the element or glyph in the dialog and click OK.