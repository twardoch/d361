## Metadata_Start 
## code: en
## title: **Font Info: Add master** 
## slug: font-info-add-master 
## seoTitle: **Font Info: Add master** 
## description:  
## contentType: Markdown 
## Metadata_End

![Add Master Dialog](https://i.fontlab.com/fl8/rn/fl8-rn6-add-master-dialog.png){ .plain .r title="Add Master Dialog" data-scale="50%" }

If you use ==Font Info > Add master== (==+== in the bottom-left corner), and you choose one of the options there, FontLab shows the ==Add master== dialog.

FontLab auto-completes the master names from a list of known master names.

If you use a known master name, FontLab also adds an axis in ==Font Info > Axes== if needed, and also sets reasonable values for the master’s Weight, Width and Slope class in ==Font Info > Names==.