## Metadata_Start 
## code: en
## title: Export Font As Enable and disable instances 
## slug: export-font-as-enable-and-disable-instances 
## seoTitle: Export Font As Enable and disable instances 
## description:  
## contentType: Markdown 
## Metadata_End

#### Export Font As: Enable and disable instances

In the File \> Export Font As dialog, Instances tab, you can now Alt-click any blue checkbox to enable or disable all instances for export. Example: Alt-click a checkbox to disable all instances, then click some checkboxes one by one to export only the selected instances.