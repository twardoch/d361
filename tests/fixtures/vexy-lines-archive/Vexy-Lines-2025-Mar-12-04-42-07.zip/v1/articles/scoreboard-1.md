## Metadata_Start 
## code: en
## title: Scoreboard 
## slug: scoreboard-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

**Scoreboard** is a large “numeric readout” that shows coordinates for points, anchors, guidelines etc. as you’re moving them with your pointer. Useful if you’re working on a large monitor where the normal UI elements are tiny.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-scoreboard.png)

**To open the Scoreboard**, use the ==View > Scoreboard== toggle. You can move the Scoreboard all over the screen just by dragging it. 

**To resize the Scoreboard**, drag any of its edges or corners.
