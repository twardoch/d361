## Metadata_Start 
## code: en
## title: Edit 
## slug: edit 
## seoTitle: Edit 
## description:  
## contentType: Markdown 
## Metadata_End

**Edit Menu**

The **Edit** menu in Vexy Lines provides a variety of tools and options that allow you to manipulate and modify objects within your document. 

1. **Undo**: This feature allows you to reverse the previous action, effectively undoing any changes made.

2. **Redo**: This option enables you to repeat an action that was previously undone.

3. **Lock**: This feature locks the selected objects, preventing any accidental modifications.

4. **Cut**: This option removes the selected objects from the document and stores them in the clipboard for later use.

5. **Copy**: This feature duplicates the selected objects and stores them in the clipboard.

6. **Paste**: This option inserts the copied or cut objects at the current cursor position.

7. **Duplicate**: This feature creates a copy of the selected objects within the document.

8. **Delete**: This option permanently removes the selected objects from the document.

9. **Select All**: This feature selects all objects within the document.

10. **Free Transform**: This option allows you to modify the size, position, and rotation of the selected objects.

11. **Transform**: This feature provides various transformation options for the selected objects.
    - **Flip Horizontal**: This option mirrors the objects along a horizontal axis.
    - **Flip Vertical**: This feature mirrors the objects along a vertical axis.
    - **Rotate 90**: This option rotates the objects by 90 degrees.

12. **Arrange**: This feature changes the stacking order of objects.
    - **Bring to Front**: This option brings the selected objects to the front of the stacking order.
    - **Bring Forward**: This feature moves the selected objects one step forward in the stacking order.
    - **Send to Back**: This option sends the selected objects to the back of the stacking order.
    - **Send Backward**: This feature moves the selected objects one step backward in the stacking order.

13. **Align**: This tool aligns selected objects relative to each other or to the canvas.
    - **Top**: This option aligns the top edges of the selected objects.
    - **Bottom**: This feature aligns the bottom edges of the selected objects.
    - **Vertical Center**: This option aligns the vertical centers of the selected objects.
    - **Left**: This feature aligns the left edges of the selected objects.
    - **Right**: This option aligns the right edges of the selected objects.
    - **Horizontal Center**: This feature aligns the horizontal centers of the selected objects.


