## Metadata_Start 
## code: en
## title: Font window filters 
## slug: font-window-filters-4 
## seoTitle: Font window filters 
## description:  
## contentType: Markdown 
## Metadata_End

In the Font window property bar, the underlined Filter label now correctly shows any current font filter that is applied to the window, including font filters applied via the Search box or the Sidebar. The if you click the Filter label, you can still choose the most popular types of font filters there.

The Font Window presents six filter kinds: Encoding, Unicode, Codepage, Category, Script, and Index. Each (except Index) offers several additional options. Now, when you change the filter type, FontLab remembers the last choice used for that type (for example, Script: Greek or Category: lowercase), and restores it.

☆ When you click Categories \> All in the sidebar, the Font window will retain its filter type but will set the filter value to None or All, which always has the effect that no glyph cells are filtered. Previously, Categories \> All was less intuitive.