## Metadata_Start 
## code: en
## title: Installupdate TypeRig 
## slug: installupdate-typerig 
## seoTitle: Installupdate TypeRig 
## description:  
## contentType: Markdown 
## Metadata_End

#### Install/update TypeRig

To install or update TypeRig:

1. Run FontLab 7
2. Choose *Scripts \> Update / Install Scripts*.
3. Click *OK* in the dialog, wait until the installation completes.
4. When you see the TypeRig is up-to-date dialog, click *OK* and close FontLab 7.
5. If your macOS asks you to install the Developer Tools, install them.
6. Start FontLab 7 and check the Scripts menu.

We recommend that you update TypeRig after you’ve installed FontLab 7.2, and occasionally update it afterwards.