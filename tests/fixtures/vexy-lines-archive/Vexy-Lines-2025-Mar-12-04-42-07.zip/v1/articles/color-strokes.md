## Metadata_Start 
## code: en
## title: Color 
## slug: color-strokes 
## seoTitle: Color 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:colorStrokes-->
The Vexy Lines allows you to use colors in two modes:

* **Static** - a specific fill color is defined.

* **Dynamic** - the fill color is determined based on the colors of the areas it covers.

| Static Color | Dynamic Color |
| --- | --- |
| ![Static Color](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28744%29.png){height="" width="300"} | ![Dynamic Color](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28745%29.png){height="" width="300"} |
<!--qh-->


### Dynamic color options
<!--qh:colorStrokes-->
If closed elements are used in the fill, the color of each element is determined by the color of the area covered by the element in the image. This applies to Trace, Halftone, and Text fills.

For fills represented by curves, when generating dynamic color fills, each curve is divided into segments, each of which is colored according to the color of the image under that segment of the curve. 
<!--qh-->

<!--qh:segLen-->
The length of segments can be adjusted using the **Color segment length** parameter.

| Length: 1 | Length: 4 | Length: 10 |
| --- | --- | --- |
| ![Length: 1](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28751%29.png){height="" width="300"} | ![Length: 4](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28752%29.png){height="" width="300"} | ![Length: 10](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28753%29.png){height="" width="300"} |
<!--qh-->

<!--qh:segDisp-->
The **Color segment length variation** parameter is used for randomizing segment length values, adding realism. Otherwise, the coloring may appear excessively regular and technical.

| 0% | 50% | 100% |
| --- | --- | --- |
| ![0%](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28754%29.png){height="" width="300"} | ![50%](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28755%29.png){height="" width="300"} | ![100%](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28756%29.png){height="" width="300"} |

> In Trace, Halftone, and Text fills, there are no "Color segment length" & "Variation" parameters.
<!--qh-->

### Static color option

<!--qh:colorStrokes-->

To choose a static color, the Vexy Lines program offers a color panel with various useful color-setting features.
<!--qh-->

#### Wheel panel
<!--qh:wheel-->

The color wheel is a tool that helps you choose and manage colors. It has a circular panel with different colors and shades. You can select the desired color and adjust its saturation and brightness. Inside the wheel, there is a triangle that allows you to choose colors in the color space to create necessary combinations.

![Wheel panel](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28758%29.png){height="" width="300"}
<!--qh-->

#### Sliders panel
<!--qh:sliders-->
This tool is for precise color adjustments. It allows easy and accurate color adjustments to create beautiful color schemes. For the RGB model, three sliders are used to adjust the intensity of each color. For the HSB model, there are also three sliders to choose the hue, saturation, and brightness. For the Grayscale model, there is one slider to adjust brightness from black to white.

![Sliders panel](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28759%29.png){height="" width="300"}
<!--qh-->

#### Box panel
<!--qh:boxes-->
This tool allows quick color adjustments. It is a panel with a set of colored squares that can be selected and applied to images or objects. This tool is useful for creating color schemes and allows easy combination of different colors. It supports various color models and allows precise control over color intensity, hue, saturation, and brightness.

![Box panel](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28760%29.png){height="" width="300"}
<!--qh-->

#### Swatches panel
<!--qh:swatch-->
This panel allows quick selection and application of colors. It is a panel with a set of preset color samples that can be used to create color schemes and combine different shades.

* Custom
* Standard
* Light
* Dark
* Photoshop

![Swatches panel](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28761%29.png){height="" width="300"}
<!--qh-->

#### Picture panel
<!--qh:picture-->
This tool allows you to use a loaded image to determine the fill color. Use the **Open picture** button to load an image from your storage device. Paste picture to load an image from the clipboard.

![Picture panel](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-JEX7SPFL.png){height="" width="300"}
<!--qh-->

#### Opacity
<!--qh:barOpacity-->

To adjust the transparency of the fill color, use the slider at the bottom of the Color panel, or enter the transparency value manually in the input field to the right of the slider.
<!--qh-->

![Opacity](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-XXMNH1VU.png){height="" width="300"}

#### Color name
<!--qh:colorRGB-->
You can enter the color name directly or the color value in the chosen color model.
<!--qh-->

![Color name](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-E2FGGHP5.png){height="" width="300"}

<!--qh:colorRGB-->
The value type is chosen to the left of the input field. The following types are available:

* RGB
* name
* HSB
<!--qh-->

#### Pick screen color
<!--qh:pick-->
This tool allows you to select a color directly from your computer screen.
<!--qh-->

![Pick Screen Color Image](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-RAXURBWA.png){height="" width="300"}

<!--qh:pick-->
> Before using, you may need to grant the appropriate permission in the operating system settings.
<!--qh-->

#### System color dialog
<!--qh:system-->
In any case, you can choose a color from the standard color panel offered by your operating system. To do this, click on the **System Color Dialog** button.
<!--qh-->

![System Color Dialog Image](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3Z3JYPX6.png){height="" width="300"}


