## Metadata_Start 
## code: en
## title: Selections 
## slug: selections 
## seoTitle: Selections 
## description:  
## contentType: Markdown 
## Metadata_End

When you select a whole or part of an outline using the Contour tool, the selected segment and nodes will turn red. Even if nodes are hidden otherwise, selected nodes are visible and red.

If “Glow contour selection” is on in Preferences \> Glyph Window the selection is additionally highlighted with a glow effect around it.