## Metadata_Start 
## code: en
## title: VISUAL PROOFING IN THE LOOKUPS PANEL 
## slug: visual-proofing-in-the-lookups-panel-1 
## seoTitle: VISUAL PROOFING IN THE LOOKUPS PANEL 
## description:  
## contentType: Markdown 
## Metadata_End

*VISUAL PROOFING IN THE LOOKUPS PANEL*

FontLab 7.2 also lets you test your OpenType features in a different way: in the new Lookups panel, you can explore *all* situations that your feature definitions describe.

If you open the Features panel and choose ☰ \> Add Auto Features, FontLab analyzes the glyph names in your font and automatically builds various OpenType features that the glyph repertoire of your font supports. You can also add a specific feature with the + button at the bottom of the panel. If the feature in the list has a bullet, FontLab will auto-generate the feature definition. And if you have existing feature definitions, you can click the star button at the top of the Features panel to auto-generate its contents. You can mix auto code with manual code — just write your manual code after the special \#\< feature line.

If you build a feature this way, for example smcp, can read the resulting FEA code in the Features panel to check if the results are what you want — but this is not very comfortable.  Now, in the Lookups panel, you can actually *see all* substitutions that the lookups that are mapped to the feature will perform, all the “before” and “after” glyphs.

If you have created feature definitions in the Features panel and the Lookups panel is empty, click the Import from Features panel button in the top-left of the Lookups panel. FontLab then compiles the FEA code, and if the code is valid, converts the feature definitions to a visual structure that you can explore in the Lookups panel.

If you have modified the feature definitions in the Features panel, Shift-click the Import from Features panel button, and the Lookups panel content will update.

When you export the font into OpenType or other formats, FontLab always uses the FEA code from the Features panel to compile the final features. The Lookups panel is only for visual proofing. However, if you export feature definitions into a VOLT project file, FontLab will use the content of the Lookups panel.