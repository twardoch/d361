## Metadata_Start 
## code: en
## title: Match when Editing 
## slug: match-when-editing 
## seoTitle: Match when Editing 
## description:  
## contentType: Markdown 
## Metadata_End

![Image](https://i.fontlab.com/fl8/rn/fl8-rn6-pref-match-contour-operations.png){ .r data-scale='25%' }

If you turn on ==Edit > Match when Editing== and perform edits in the Glyph window, FontLab repeats those edits accordingly on all matching masters to keep variation compatibility. 

If ==Preferences > Variations > Match when editing > Contour operations== is turned on, FontLab repeats these editing operations:

- ==Contour > Set Start Point== (but not ==Set Start Point== from the context menu)

- ==Contour > Reverse Contour== and ==Reverse Contour== from the context menu

- ==Contour > Add Smart Corner== and ==Smart Corner== from the context menu

