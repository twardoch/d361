## Metadata_Start 
## code: en
## title: Font formats 
## slug: font-formats-1 
## seoTitle: Font formats 
## description:  
## contentType: Markdown 
## Metadata_End

First, in the left part of the dialog box, select the output font format represented by the \[export profiles\](Export-Profiles). The list includes only active export profiles that you turned on in the Profiles dialog File \> Profiles. You cannot select multiple profiles for export, so choose just one of them.