## Metadata_Start 
## code: en
## title: Deleting Segments 
## slug: deleting-segments 
## seoTitle: Deleting Segments 
## description:  
## contentType: Markdown 
## Metadata_End

To delete a line or a curve, click it with the Contour tool and then select the Delete command in the Edit menu (Backspace key). This method removes the segment with both its nodes but doesn’t break the contour. On the other hand, if you wish to leave both end nodes intact, but break the counter, then you can delete the segment using the Delete (Fn+Delete) key as well.