## Metadata_Start 
## code: en
## title: Remove Background 
## slug: remove-background 
## seoTitle: Remove Background 
## description:  
## contentType: Markdown 
## Metadata_End

The Remove Background filter is one more way to make the image cleaner. This filter tries to separate the element from its background and then clear the background.

![][tibetanmanuscript_01]   ![][tibetanmanuscript_02]

[tibetanmanuscript_01]: tibetanmanuscript_01.png width=139px height=49px

[tibetanmanuscript_02]: tibetanmanuscript_02.png width=133px height=48px