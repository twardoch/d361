## Metadata_Start 
## code: en
## title: Multiple Fonts Open 
## slug: multiple-fonts-open 
## seoTitle: Multiple Fonts Open 
## description:  
## contentType: Markdown 
## Metadata_End

Open the Fonts panel and open a couple of font files using File \> Open Fonts or by drag-dropping files to the Fonts panel. You will see fonts appear in the Fonts panel but do not have their own Font window or tab. If you open the Font Map panel you will be able to work with glyph cells of the font(s) currently selected in the Fonts panel. Double-clicking a cell opens the Glyph Window as it usually does in the Font window. All other glyph cell related operations work in the Font Map panel as well.

![][fontmapandpanel-r]

[fontmapandpanel-r]: fontmapandpanel-r.jpg width=272px height=232px