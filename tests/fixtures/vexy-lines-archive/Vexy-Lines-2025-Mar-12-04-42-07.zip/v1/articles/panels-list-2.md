## Metadata_Start 
## code: en
## title: Panels list 
## slug: panels-list-2 
## seoTitle: Panels list 
## description:  
## contentType: Markdown 
## Metadata_End

A panel groups and organizes related controls and information. You can open and close panels in Window \> Panels. And also with the Panels list (Window \> Panel list):

![][panelslist-r]

Panels list

The gear icon (⚙) at the end of the list opens a dialog box allowing you to customize the set of buttons in the Panels list. By default, all buttons are turned visible. The Panel list can be resized and docked just like other panels (see the docking procedure below).

The third way to open panels is to Right-click on the Title bar of any panel. The same list from Window \> Panels will appear and so you can choose one to open.

![][panelheaderlist-r]

List from Right-click on a panel title

[panelslist-r]: panelslist-r.jpg width=115px height=90px

[panelheaderlist-r]: panelheaderlist-r.jpg width=132px height=151px