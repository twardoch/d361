## Metadata_Start 
## code: en
## title: Pencil tool 
## slug: pencil-tool-2 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

With the **Pencil tool** (++N++ key) you can create new [[Contours]] and modify existing contours in a more freehand manner than with the [[Pen tool]] or [[Contour tool]]. When using the Pencil tool, you don’t need to worry about control points, or on- and off- curve points; your drawing will be manifested as a series of curves and lines.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-pencil_in_toolbar.png)


## Drawing a new contour


1. **To start creating a new contour**, select the Pencil tool and click the mouse button. Now drag it to draw. Note that if ==Pen and Pencil tools can continue on a contour== option in ==Preferences > Editing== is turned on, and the starting point of the new contour you want to draw lies on an existing contour, will need to hold down the ++Ctrl++ key while drawing to ensure that a new contour is drawn, rather than the existing contour being modified.

2. If you want **to draw straight lines**, hold down the ++Alt++ key while drawing. Similarly, if you want **to draw horizontal or vertical lines**, hold down ++Alt+Shift++ keys while drawing.

**To close the contour**, bring back the Pencil tool to the point where you started. A blue circle will appear, and releasing the mouse button within this circle will create a closed contour.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-pencil_tool_01.gif)

**To stop drawing the contour without closing it**, release the mouse button at the location of your choice.


## Editing an existing contour


**To draw over an existing contour to add or delete from its edges**, you need to turn on the ==Pen and Pencil tools can continue on a contour== option in ==Preferences > Editing==. In this mode, if you move the cursor of the Pencil tool over any node or outline of an existing contour, a blue cross appears. If you begin drawing from this point, the new contour will be inserted into the existing contour. If both the starting and finishing points are on the same existing contour, then the new drawing will replace the part of the existing contour that lies between the start and end points of your new drawing:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-pencil_tool_03.gif)
