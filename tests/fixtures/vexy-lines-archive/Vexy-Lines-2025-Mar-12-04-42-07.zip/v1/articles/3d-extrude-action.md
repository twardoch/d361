## Metadata_Start 
## code: en
## title: 3D extrude action 
## slug: 3d-extrude-action 
## seoTitle: 3D extrude action 
## description:  
## contentType: Markdown 
## Metadata_End

When you specify `0` for ==Thickness== in the ==Tools > Actions > Effect > 3D extrude== action, the result of the action is now truly just the extrusion, with the original contour fully subtracted.