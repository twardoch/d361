## Metadata_Start 
## code: en
## title: Show names 
## slug: show-names-1 
## seoTitle: Show names 
## description:  
## contentType: Markdown 
## Metadata_End

Show glyph names shows/hides two text boxes at the bottom of the panel.

* Type into the top text box using *glyphtext* (Unicode text mixed with escaped strings: /glyphname or \\uXXXX, each followed by a space or another escaped string).
* The bottom box shows names of the previewed glyphs (prefixed with /), after features have been applied.