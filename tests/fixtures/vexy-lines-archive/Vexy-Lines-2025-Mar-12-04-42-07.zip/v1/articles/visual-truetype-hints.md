## Metadata_Start 
## code: en
## title: Visual TrueType Hints 
## slug: visual-truetype-hints 
## seoTitle: Visual TrueType Hints 
## description:  
## contentType: Markdown 
## Metadata_End

In FontLab we use a small set of high-level hinting instructions that are automatically compiled to TrueType instructions during font export. Because these instructions can be set and edited visually we call them \_visual TrueType hints\_ or just \_visual hints\_.

Visual hints are enough to define TrueType hints even in very complex situations and they are compiled in very compact and effective TrueType instruction code.

The visual hint set includes the following commands:

\| Command \| Description \|

\| Align \| Aligns (moves) the position of the outline point to the designated position on the grid or to the edge of the alignment zone \|

\| Single Link \| Sets the position of the point relative to the position of another point. Distance can be linked with one of the stem widths. Distances also may be rounded or not \|

\| Double Link \| Sets the distance between two points to an integer value that may be linked with a stem width \|

\| Interpolate \| Interpolates the position of a point between two other points \|

\| Middle Delta \| Slightly shifts a point at a specific PPM. This command works before the final interpolation of untouched points \|

\| Final Delta \| Slightly shifts a point at a specific PPM. This command works after the final interpolation of untouched points. This command is used for the final outline correction. \|

All commands are available in horizontal and vertical directions. There are no “diagonal” visual instructions.