## Metadata_Start 
## code: en
## title: Auto layers 
## slug: auto-layers-1 
## seoTitle: Auto layers 
## description:  
## contentType: Markdown 
## Metadata_End

The Auto layers section lets you decide what to do with glyphs that have auto layers which rely on glyphs that you’re deleting.

Turn Preserve recipes on to keep the logical structure of the auto layer, but the appearance may change. The affected auto layer glyphs will keep the auto layers property but may change visually.

* If the affected auto layer uses a custom recipe, that recipe will stay unchanged. The component whose source was deleted disappears. However, if you add a new glyph with the name used in the recipe or assign that name to another glyph, the new component will reappear in the affected auto layer.
* If the affected auto layer uses a built-in recipe, FontLab will try to fully rebuild the auto layer using the next-best recipe for as long as possible. For example, if your font has the glyphs A, acutecomb and acute and you turn on auto layer on Aacute, FontLab will build it from A+acutecomb. But if you delete the acutecomb glyph, FontLab will rebuild Aacute from A+acute. If FontLab cannot fully rebuild the auto layer, the component whose source was deleted disappears.

Turn Preserve recipes off to keep the appearance of the auto layer, but not its logical structure. FontLab will first convert the auto layer into a composite glyph, and will then work on the composite according to your Composite glyphs choice above.