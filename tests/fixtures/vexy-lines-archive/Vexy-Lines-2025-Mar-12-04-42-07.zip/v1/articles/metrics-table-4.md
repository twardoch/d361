## Metadata_Start 
## code: en
## title: Metrics Table 
## slug: metrics-table-4 
## seoTitle: Metrics Table 
## description:  
## contentType: Markdown 
## Metadata_End

The Metrics table (View \> Metrics Table) now shows the metrics fields for the current glyph in bold on a slightly darker background.