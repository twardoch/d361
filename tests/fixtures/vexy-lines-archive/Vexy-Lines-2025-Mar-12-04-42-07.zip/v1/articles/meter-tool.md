## Metadata_Start 
## code: en
## title: Meter 
## slug: meter-tool 
## seoTitle: Meter 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:rulerButton-->
![Meter tool](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/tool-meter%281%29.svg) The **Meter** tool helps you measure distances and angles with precision. Whether you're planning stroke spacing, checking dimensions, or measuring angles between elements, this tool gives you accurate measurements based on your chosen unit system.
<!--qh-->

### Meter Tool Activation

Access the **Meter** tool by clicking its icon in the toolbar or navigating to **Tools -> Meter** in the main menu.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-U0WP26ZK.png){height="" width="380"}

<!--qh:rulerButton-->
> Tool shortcut : G

<!--qh-->

<!--qh:rulerButton-->

### Measuring 

Using the Meter tool is straightforward:

1. Position your cursor at the starting point you want to measure from
2. Click and hold the mouse button, then drag to your endpoint
3. As you drag, a dynamic ruler appears, showing both distance and angle measurements

![dynamic ruler](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28380%29.png){height="" width="300"}

> Hold ⇧(shift) while measuring to lock the ruler to perfect horizontal or vertical directions.

$~$

Measurements display in your current unit system, which you can change in the View panel or Preferences.

![Image](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28381%29.png){height="" width="300"}

<!--qh-->
