## Metadata_Start 
## code: en
## title: Open variable COLRv1 fonts 
## slug: open-variable-colrv1-fonts 
## seoTitle: Open variable COLRv1 fonts 
## description:  
## contentType: Markdown 
## Metadata_End

![Opening Variable COLR1 fonts](https://i.fontlab.com/fl8/rn/fl8-rn-variable-colr1-fonts.png){ data-scale='75%' title="Opening Variable COLR1 fonts" }

You can now open some variable color OpenType TT+COLR fonts with the COLR v1 table, so you can have variable glyphs with gradients and other more advanced color fills. For example, try opening [Nabla](https://github.com/google/fonts/raw/main/ofl/nabla/Nabla%5BEDPT%2CEHLT%5D.ttf) by Arthur Reinders Folmer and Just van Rossum.

!!! warning

> This functionality is in beta. If you open some variable OT+COLR v1 fonts in FontLab, the glyphs will not look as intended.
