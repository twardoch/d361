## Metadata_Start 
## code: en
## title: Smart Corners 
## slug: smart-corners-2 
## seoTitle: Smart Corners 
## description:  
## contentType: Markdown 
## Metadata_End

* The rounding of coordinates when applying Smart Corners was much improved, so the results (especially very small ink traps) are much smoother now.
* When a Smart Corner handle is on top of a node, you can now use Alt-drag to grab and manipulate the Smart Corner handle instead of the node.