## Metadata_Start 
## code: en
## title: Handling the Elements 
## slug: handling-the-elements 
## seoTitle: Handling the Elements 
## description:  
## contentType: Markdown 
## Metadata_End

Use the Element tool, which is depicted by a black arrow, to select all of your artwork. If you use the Contour tool here, the following steps will not work.

Select Element \> Optically Separate. You will notice that your elements now appear in an Element Frame with their names at the top. Optically Separate only works on English and Russian glyphs at the moment. Other glyphs would have to be manually placed using the Element \> Place As Glyphs \> Current Element command.

![][art3]

[art3]: art3.png width=107px height=72px