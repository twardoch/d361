## Metadata_Start 
## code: en
## title: Brush Tool 
## slug: brush-tool-5 
## seoTitle: Brush Tool 
## description:  
## contentType: Markdown 
## Metadata_End

!\[\](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi\_GW-PropertyBar\_brush\_tool.png

When the Brush tool is active, the context bar displays the following:

1\. Simple/Smart Stroke toggle

2\. Size slider for the brush.

3\. Brush shape dropdown

4\. Remove button to remove the brush filter from a smart stroke.

5\. Expand button to apply the filter and convert the stroke to final outlines.