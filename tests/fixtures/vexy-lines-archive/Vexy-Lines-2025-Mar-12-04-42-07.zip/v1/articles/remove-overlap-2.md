## Metadata_Start 
## code: en
## title: Remove Overlap 
## slug: remove-overlap-2 
## seoTitle: Remove Overlap 
## description:  
## contentType: Markdown 
## Metadata_End

This action, which is the same as the Remove Overlap command Contour \> Remove Overlap, can be used to remove overlapping contour areas and orphan nodes. It also a expands the fill, if a fill has been applied.

actions\_remove\_overlap.png