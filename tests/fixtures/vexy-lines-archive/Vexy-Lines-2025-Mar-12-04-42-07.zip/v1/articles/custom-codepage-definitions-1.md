## Metadata_Start 
## code: en
## title: Custom Codepage Definitions ( 
## slug: custom-codepage-definitions-1 
## seoTitle: Custom Codepage Definitions ( 
## description:  
## contentType: Markdown 
## Metadata_End

#### Custom Codepage Definitions (.cpg)

The default codepage definition files (with the extension “.cpg”) are located in the app/Resources/codepage folder on the Macintosh or in the FontLab 7\\\\Resources\\\\Codepage folder on Windows. These are text files that have the following structure:

==

$\{'%%'\}FONTLAB CODEPAGE: 0xFFFF; MS Windows 1251 Cyrillic

$\{'%%'\}GROUP:MS Windows

$\{'%%'\}UN2/UN2

0x00 0x0000

0x01 0x0001

0x02 0x0002

0x03 0x0003

==

The first line of this file is an identification line that is used to set the codepage name and tell FontLab that this file is a properly composed codepage definition file. This line must start with the text %%FONTLAB CODEPAGE: 0xFFFF;, followed by the name of the codepage.

The second line identifies a codepage group name. This group name will become the submenu title in the Codepage popup menu.

!!! Note

There is no space after the ‘:’ character.

All other strings starting with ‘%’ are comments, and are not interpreted by FontLab.

The lines that follow all have the same syntax:

==

\<code\> \<Unicode codepoint\>

==

The first number is the code of the character and should be in the 0–255 range. The second number is the Unicode codepoint of the character and should be in the 0–65535 (0-FFFFh) range. Both integer numbers can be in decimal or hex form, starting with “0x.” The special Unicode codepoint 0xFFFF is used to define codes that are not mapped to any character.

Put the .cpg file in the \_\[User Data Folder\](Custom-data-files-and-locationsfontlab-vi-user-data-folder)\_/Codepage folder and restart FontLab to see the codepage in the Codepage selection popup menu.