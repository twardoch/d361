## Metadata_Start 
## code: en
## title: The Brush tool (B) in FontLab works somewhat like the brush tool in any bitmap 
## slug: the-brush-tool-b-in-fontlab-works-somewhat-like-the-brush-tool-in-any-bitmap 
## seoTitle: The Brush tool (B) in FontLab works somewhat like the brush tool in any bitmap 
## description:  
## contentType: Markdown 
## Metadata_End

The Brush tool (B) in FontLab works somewhat like the brush tool in any bitmap editing program. You begin a brush stroke by pressing the mouse button, draw the stroke by dragging, and finish drawing it by releasing the button.

brush\_in\_toolbar.png

The results depend on the brush mode selected in the Property bar:

brush\_tool\_01.png

If the Simple Stroke mode is selected, the result of your drawing is immediately converted to final outlines, and cannot be changed for contours that you have already drawn. Use the Contour tool for fine tuning the contours.

brush\_tool\_02.png

If the Smart Stroke mode is selected (the default), the result of your drawing is a stroke with a Power Brush filter applied.

brush\_tool\_03.png

In this case, you can edit the stroke with the Contour tool, as well as edit the size and shape of the brush applied to this stroke using the Property bar or the Brush panel:

brush\_tool\_04.gif)

Every time you draw a smart stroke you create a new \[element\](Elements) (including stroke + filter). It can be edited and transformed separately, including applying different brush attributes to it.

Multiple elements can be combined in one by the Element \> Combine Contours to Element command. This will automatically convert smart strokes to simple outlines.

To resize the Brush, Ctrl-drag (like adjusting the size of a brush or eraser in Photoshop).

To remove the brush filter from the smart stroke, select it and click the Remove button in the Property bar or the Brush panel.

To convert the smart stroke to final outlines, (that is to apply the filter), select it and click the Expand button in the Property bar or the Brush panel or choose the Element \> Expand Filters command.