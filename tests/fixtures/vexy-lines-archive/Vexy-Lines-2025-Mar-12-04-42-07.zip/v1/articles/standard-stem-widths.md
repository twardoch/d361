## Metadata_Start 
## code: en
## title: Standard Stem Widths 
## slug: standard-stem-widths 
## seoTitle: Standard Stem Widths 
## description:  
## contentType: Markdown 
## Metadata_End

Typically many glyphs in a font use the same few standard stem widths. As examples, let’s take the H, B, and F glyphs shown below. All of them have the same width for the straight vertical stems and the same width for the horizontal stems:

stand\_stem.png

The most widely used stem widths are stored in the font header in order to force the rasterizer to render these stems at the same width.

This information is used to control at what glyph size the rounded stem width goes from one to two pixels and from two to three pixels. A step from one to two pixels means a 100% width increase and a step from 2 to 3 pixels a 50% increase. This means that near this value rounding errors will be maximal and control over stem widths will be necessary.

If one stem has a width of 74 units and another a stem width of 76 units and the UPM is 1000 units, then at a PPM of 20 pixels the first stem will be rounded to 1 pixel and the second stem to 2 pixels. Scaled back to the original coordinates, this difference will be 50 units! That is clearly too much for an original difference of only 2 units.

Standard widths work with stem hints. When the width of a hint is close to one of the standard widths, the rounded width of the hint (and the real stem outline) will be forced equal to the width of the rounded standard stem.