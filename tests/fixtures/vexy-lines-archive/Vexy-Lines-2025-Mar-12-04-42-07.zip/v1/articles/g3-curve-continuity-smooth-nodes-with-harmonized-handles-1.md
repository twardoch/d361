## Metadata_Start 
## code: en
## title: G3 curve continuity Smooth nodes with Harmonized handles 
## slug: g3-curve-continuity-smooth-nodes-with-harmonized-handles-1 
## seoTitle: G3 curve continuity Smooth nodes with Harmonized handles 
## description:  
## contentType: Markdown 
## Metadata_End

**G3 curve continuity: Smooth nodes with Harmonized handles**

FontLab 7.1 provides automatic ways in which you can avoid visible bulges on a Smooth node, and achieve G2 continuity (Harmonize Node and Genius node) or G3 continuity (Harmonize Handles). Remember: these operations give a certain “mathematical” *local* smoothness at and around a node.

Think of them as quick short cuts, they are not a replacement for your eye. If you use the operations, check if the results are consistent with your design intentions, and use your eyes to judge the overall flow of the curves. You may use them as a learning tool: harmonize a node or its handles, and see how FontLab places the nodes and handles. Move the nodes and handles, see how the curves change.

Often, a good way to achieve smoothness is to just remove the node — the longer curve segment will naturally flow smoothly. Also, not all typefaces need ultra-smooth curves! Many designs use abrupt changes or conscious bulges and kinks to express the design intent.