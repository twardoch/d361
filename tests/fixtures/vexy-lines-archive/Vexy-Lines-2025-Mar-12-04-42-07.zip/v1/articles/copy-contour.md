## Metadata_Start 
## code: en
## title: Copy contour 
## slug: copy-contour 
## seoTitle: Copy contour 
## description:  
## contentType: Markdown 
## Metadata_End

If you have multiple masters, the current glyph no longer matches, because Paste only pasted the contours to the current master. Choose Edit \> Copy to Masters (CmdY CtrlY), and FontLab will add the current selection (which is the just-pasted contours) to all other masters of the current glyph. This works if you want to paste the *same* contours into all masters.