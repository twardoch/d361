## Metadata_Start 
## code: en
## title: Options 
## slug: options 
## seoTitle: Options 
## description:  
## contentType: Markdown 
## Metadata_End

If you are moving a node that is connecting two PostScript (Bézier) curves you have the following options:

1\. If the connection of the curves is smooth, press the Alt key to constrain movement to a line between the curves’ control points: 

contour\_tool\_04.gif)

2\. If the connection is sharp, press the Alt key while dragging the node to move it without moving the adjacent control points: 

contour\_tool\_05.gif)

3\. If the connection is smooth, press the Alt and Cmd keys to keep the connection’s curvature optimised. All 4 control points will be involved in the process: 

contour\_tool\_08.gif)

4\. Press the Alt and Shift keys to slide the node along a segment. The control points will be recalculated to keep the current shape of the segment: 

contour\_tool\_06.gif)

5\. When you are editing control points of a Bézier curve, press the Shift key before clicking the button to keep the direction of the control vector unchanged: 

contour\_tool\_07.gif)

6\. If you are moving a control point of a curve with a sharp connection, press the Alt key to temporarily change the connection type to smooth, so that the adjacent control vector will be collinear.

7\. If you have a node or handle that is nearly aligned (in either X or Y) with an adjacent node, Shift-double-click the node or control point and it will shift to become aligned.

Do not forget that you can press the Grave key (usually the key between Shift and Z) at any time to get an instant high-quality preview of the glyph outline as it will print.