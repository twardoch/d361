## Metadata_Start 
## code: en
## title: Trial period 
## slug: trial-period 
## seoTitle: Trial period 
## description:  
## contentType: Markdown 
## Metadata_End

Download the FontLab app from the [FontLab page](http://www.fontlab.com/font-editor/fontlab), and move it to the Application folder on your Mac, or run the downloaded Installer on Windows. The installation can run 10 days in trial mode, or can be activated to run indefinitely.

> The trial has the full app functionality. You can generate fonts with no restriction while using the trial period.