## Metadata_Start 
## code: en
## title: Selecting anchors and pins 
## slug: selecting-anchors-and-pins-1 
## seoTitle: Selecting anchors and pins 
## description:  
## contentType: Markdown 
## Metadata_End

To select an anchor or pin in the Glyph window, you can now Alt-click its name, or click the anchor or pin itself. This makes it easier to select anchors that have the same location. To rename the anchor or pin, click its name.