## Metadata_Start 
## code: en
## title: Tracking, slant, stretch 
## slug: tracking-slant-stretch-1 
## seoTitle: Tracking, slant, stretch 
## description:  
## contentType: Markdown 
## Metadata_End

This button group lets you dynamically apply Tracking, Slant and horizontal Stretch to the Preview panel text. Click the toggles to turn the dynamic tracking, slanting or stretching on/off, and choose the values in the next dropdowns.

Use Tools \> Actions to actually change glyph metrics, to slant or to stretch the glyph content.