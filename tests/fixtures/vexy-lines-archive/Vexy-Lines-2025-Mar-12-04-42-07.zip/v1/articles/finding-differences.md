## Metadata_Start 
## code: en
## title: Finding differences 
## slug: finding-differences 
## seoTitle: Finding differences 
## description:  
## contentType: Markdown 
## Metadata_End

This operation can also be used for finding differences in contours which are supposed to be identical. For example, glyphs a agrave aacute acircumflex atilde adieresis aring amacron abreve if decomposed must contain two identical contours. To check if they are really identical:

1\. 	Color-mark a agrave aacute acircumflex atilde adieresis aring amacron abreve glyph cells with some color, red, for example.

2\. 	Open a glyph and select the outer contour by double-clicking it.

3\. 	Using the Edit \> Find Outline command open the Find Outline dialog box.

4\. 	The left Find pane contains the contour to look for. The right Replace pane is empty. Click the find-outline\_08.png button to place the current selection into the pane. Both panes are identical now.

5\. 	Click the Find button to find the next appearance of the source path in one of the glyphs. The first such glyph located will appear in the Glyph Window and the path that is found will be selected.

6\. 	Click Replace & Find to replace and find the next location of the path. The found contour will be replaced with the same contour.

7\. 	Repeate step 6 several times until the a glyph appears in the Glyph window again.

8\. 	Close the Find Outline dialog box and look at the a agrave aacute acircumflex atilde adieresis aring amacron abreve glyph cells in the Font window. Those marked blue were found and replaced with the contour from the a glyph; any glyphs still marked red were not replaced, which means their a contour must be different than the ones that were replaced.