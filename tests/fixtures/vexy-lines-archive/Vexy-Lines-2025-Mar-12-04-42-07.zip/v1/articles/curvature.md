## Metadata_Start 
## code: en
## title: Curvature 
## slug: curvature 
## seoTitle: Curvature 
## description:  
## contentType: Markdown 
## Metadata_End

Something.