## Metadata_Start 
## code: en
## title: Automatic detection of composites and element references 
## slug: automatic-detection-of-composites-and-element-references 
## seoTitle: Automatic detection of composites and element references 
## description:  
## contentType: Markdown 
## Metadata_End

If you choose ==Font > Detect Composites==, FontLab will analyze the current master and will replace repeating contours (and contours enclosed in them) with either components (if it finds an appropriate standalone glyph) or element references (if the repeating portion does not occur by itself). This operation now works more reliably.

If you don’t want element references, first go to any glyph where the contours occur, select them and choose ==Contour > Convert > To New Component==, and give it a name. Then run ==Font > Detect Composites==, and the same contours in all glyphs in the current master will be replaced by components that point to the new glyph.

To only replace a single selection with a component, use ==Contour > Convert > Detect Component==.
