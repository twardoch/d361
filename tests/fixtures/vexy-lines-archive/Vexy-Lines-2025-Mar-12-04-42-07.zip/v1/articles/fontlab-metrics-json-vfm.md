## Metadata_Start 
## code: en
## title: FontLab Metrics JSON (VFM) 
## slug: fontlab-metrics-json-vfm 
## seoTitle: FontLab Metrics JSON (VFM) 
## description:  
## contentType: Markdown 
## Metadata_End

TBA.