## Metadata_Start 
## code: en
## title: Remove kerning pairs by specified criteria 
## slug: remove-kerning-pairs-by-specified-criteria 
## seoTitle: Remove kerning pairs by specified criteria 
## description:  
## contentType: Markdown 
## Metadata_End

In the ==Remove Kerning Pairs== dialog, you can remove some kerning pairs from the current font master according to criteria you specify. To open the dialog:

- Choose ==Font > Kerning > Remove Pairs...== to apply the criteria to all pairs in the current master. If you
- Select some kerning pairs in the ==Kerning== panel, and choose ==Remove Pairs...== from the panel local menu to apply the criteria to the selected pairs, or turn on ==Apply to all pairs== to apply the criteria to all pairs in the current master.

To remove kerning exceptions that differ insignificantly from the class pair, open the dialog and use the new option ==Remove exceptions that differ from class pair by _n_ units or less==.
