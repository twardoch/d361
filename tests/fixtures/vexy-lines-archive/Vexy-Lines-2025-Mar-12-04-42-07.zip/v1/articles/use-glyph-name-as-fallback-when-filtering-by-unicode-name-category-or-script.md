## Metadata_Start 
## code: en
## title: Use glyph name as fallback when filtering by Unicode name, category or script 
## slug: use-glyph-name-as-fallback-when-filtering-by-unicode-name-category-or-script 
## seoTitle: Use glyph name as fallback when filtering by Unicode name, category or script 
## description:  
## contentType: Markdown 
## Metadata_End

When this option is selected, FontLab will generate Unicode indices XXXX from uniXXXX or uXXXX when filtering glyph cells in the Font window.