## Metadata_Start 
## code: en
## title: Variable TT ( 
## slug: variable-tt 
## seoTitle: Variable TT ( 
## description:  
## contentType: Markdown 
## Metadata_End

**Variable TT (.ttf) export profile**

The export profile for TrueType-based variable OpenType fonts is now called Variable TT (.ttf) (previously it was OpenType Variations (.ttf)).