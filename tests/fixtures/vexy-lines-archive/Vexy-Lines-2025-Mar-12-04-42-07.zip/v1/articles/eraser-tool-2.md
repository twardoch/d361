## Metadata_Start 
## code: en
## title: Eraser tool 
## slug: eraser-tool-2 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

The **Eraser tool** (++Q++ key) is used to erase nodes and/or simplify paths:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-eraser_in_toolbar.png)

- Clicking with the Eraser tool removes any nodes and handles that you click, while ++Shift++-clicking will selectively not remove certain “strategic” nodes.

- ++Ctrl++-drag to resize the Eraser (like adjusting the size of a brush or eraser in Photoshop).

- ++Ctrl++-click a node, and then click another node on the same contour, and the Eraser will simplify the path between those two nodes:

  ![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-eraser_tool_01.gif)
