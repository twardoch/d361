## Metadata_Start 
## code: en
## title: AlignTop and AlignBottom Instructions 
## slug: aligntop-and-alignbottom-instructions 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

#### \#\#\# AlignTop and AlignBottom Instructions

These instructions are available only when the vertical TTH\_panel\_02.png hinting direction is selected.

To add AlignTop or AlignBottom commands:

1\. Select the Align tool TTH\_panel\_05.png.

2\. Position the cursor over the point that you want to align and click the mouse button.

3\. If the selected point was in one of the alignment zones, an AlignTop or AlignBottom command will be added to the hinting program. If the selected point is not in the zone, the “free” Align command will be added.

The AlignTop command appears as:

TTH\_tool\_24.png

The AlignBottom command is similar to the AlignTop command.

How AlignTop and AlignBottom Commands Work

1\. In the prep program (this program interprets every time the PPM is changed) all alignment zones (stored in the cvt table) are aligned to the closest integer position.

2\. When the glyph program interprets, the position of the point aligned to the zone by the AlignTop or AlignBottom command is set equal to the aligned position of the zone if the scaled distance between it and the zone is no more than 16/17 pixels.

The AlignTop and AlignBottom commands have two arguments: the name of the point that is aligned by the command and the name of the zone. In the Code panel these commands appear as:

alignt at01 "T: 1447"

alignb ab01 "B: 0"

where \_at01\_ and \_ab01\_ are point names and "\_T: 1447\_“ and ”\_B: 0\_" are names of the top and bottom zones, respectively.