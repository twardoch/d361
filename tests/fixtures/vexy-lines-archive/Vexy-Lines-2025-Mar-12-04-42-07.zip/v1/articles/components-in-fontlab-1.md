## Metadata_Start 
## code: en
## title: Components in FontLab 
## slug: components-in-fontlab-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

In FontLab, components work like components in FontLab Studio 5, UFO or in TrueType-flavored OpenType fonts. Components are a standards-compliant way to build glyphs from other glyphs. Each component points to a source glyph, and can have a transformation (such as shift, optionally also scale, rotation or slant) applied to it. Previous versions of FontLab simulated components using [Element References](Detecting-Element-References), but now both mechanisms are available independently.

Using Components, you can build [composite glyphs](Using-Composite-and-Auto-Glyphs) in one or all masters — via Generate Glyphs, Add Component, Copy-Paste or Auto Layers. You can mix Components and simple contours in one layer. You can use nested Components that point to glyphs that are made of Components (for example, you can build a `dieresiscomb` glyph from two `dotaccentcomb` Components, and then build `Adieresis` from the Components `A` and `dieresiscomb`).

FontLab will keep your Component structure when it exports your font to a format that supports components (TTF, VFB, UFO), and will decompose Components as needed when a format does not support components at all, or does not support some aspects such as rotated Components or Components mixed with contours.


## Differences between Components & Element References


Components should not be confused with [Element References](Detecting-Element-References). While Components point to a single source glyph, Element References are all equal and link to each other. Components come in handy when you want to build simple composite glyphs using other glyphs. On the other hand, Element References are useful when a stem, serif or other glyph fragments (contours or images) has to be reused across multiple glyphs in the same layers, and a link needs to be maintained across all its placements. Whereas Components contain information about [glyph metrics](Glyph-Metrics) and [anchors](Anchors-and-Pins) of the source glyph, Element References don’t. 

Hence both Element References and Components are shown and controlled in the [[Elements panel]] they are presented slightly differently:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-comp-vs-ref.png)
