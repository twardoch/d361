## Metadata_Start 
## code: en
## title: Custom Glyph Recipes 
## slug: custom-glyph-recipes 
## seoTitle: Custom Glyph Recipes 
## description:  
## contentType: Markdown 
## Metadata_End

In Font › Generate Glyphs › Custom:

\- Put multiple glyph names in one or more lines to use built-in glyph recipes.

\- Turn on Use simple (FLS5) syntax and put each glyph recipe in a separate line to mix both simple and extended syntax: a recipe prefixed with \`!\` uses extended syntax (\`!Aacute = A + acute\`), otherwise simple syntax (\`A+acute=Aacute\`).

\- Turn off Use simple (FLS5) syntax to only use extended syntax (one glyph recipe per line).

Simple syntax

\- attach mark: \`A+dieresis\` — \`\_anchor\` in mark will snap to \`anchor\` in base glyph if present

\- specify positioning if no anchors present: \`A+\^\>dotaccentcomb\`

\- place at origin: \`\|\`, left-align to box: \`\<\`, right-align: \`\>\` — otherwise center

\- place at baseline: \`\~\`, raise by \_caps height – x-height\_: \`\^\` — otherwise raise if base is uppercase

\- extra shift by UPM size ‰: \`A+\|-200\~50acutecomb\`

\- build ligatures:

\- marks attach to each base component: \`f&f\`, \`f\_f&i\`, \`T+acutecomb&A+gravecomb\`

\- marks attach to first component, wrap glyph names that contain \`\_\` in \`\`: \`f\_f\`, \`f\_f\_i\`

\- spaces not permitted

Type \_simple\_recipe\_ into auto layer recipe field: \`A+acute\`.

Type newline- or space-separated \_simple\_recipe\_\`=\`\_result\_glyphName\_ entries into Font › Generate Glyphs › Custom — with Use legacy (FLS5) code on: \`A+acute=Aacute\`.

Extended syntax

\- ligatures: \`= f & i\`, with kerning: \`= A &\\\\ V\`

\- attach mark at 0,0: \`= A + ringcomb + acutecomb\`

\- attach \`\_top\` mark anchor at \`top\` anchor: \`= A + ringcomb@top\`

\- attach mark at \`x,y\`: \`= A + acute@200,-100\`

\- attach a mark at % of boxes: \`= A + acute@10%,80%\`

\- use named parameters: \_guideName\_, \`descender\`, \`xHeight\`, \`capHeight\`, \`ascender\`, \`left\`, \`right\`, \`innerLeft\`, \`innerRight\`, \`width\`, \`bottom\`, \`top\`, \`origin\`, \`center\`: \`= a + ogonek@center,innerRight\`

\- flip vertically: \`= M@,\~\`

\- flip horizontally: \`= A + grave@\~center,top\`

\- flip H & V: \`= g + commaaccent@\~center,\~top\`

\- apply transformation matrix: \`= A + acute@1, 0, 0, 1, 100, 100\`

\- use expressions: \`\` = A + ring@center,\`top+10\` + acute@center,\`top-10\` \`\`

\- refer to different preceding glyph: \`= A + acute@50%,top + ogonek@A:innerRight\`

\- set advance width: \`= A + acute \^ 400\` or \`= A + acute \^ A * 2\`

\- set sidebearings: \`= A + acute \^ 30, 30\` or \`= A + acute \^ A / 3, B * 2\`

\- spaces are permitted but not required

Type \`=\`\_extended\_recipe\_ into auto layer recipe field: \`= A + acute\`.

Type newline-separated \_result\_glyphName\_ \`=\` \_extended\_recipe\_ entries into Font › Generate Glyphs › Custom — with Use legacy (FLS5) code off: \`Aacute = A + acute\`.

Both syntaxes

\- add \`Custom note\` to glyph: \`= A+acutecomb \#!Custom note\`

\- comment (ignored): \`A+acute \# comment\`

reference.markdown: Markdown and HTML in glyph notes; \<h1\>Markdown and HTML in glyph notes\</h1\>

In glyph notes, you can use a subset of Markdown and HTML. In both Markdown and HTML, there is a concept of \_blocks\_ and of \_inline elements\_.

Blocks occupy the full width of the document. Each new block creates a line break. Examples of blocks include paragraphs, headings, tables and lists.

Inline elements are pieces of formatting that flow with the text inside a block and don’t create a line break. Typical examples of inline elements are emphases (bold or italic) and links.

\<h1\>Markdown blocks\</h1\>

Markdown is plain text with a few non-alphabetic characters that are used to apply formatting.

Type Enter twice to get a blank line, which starts a new \_Markdown block\_. Each Markdown block has a blank like above it and below it.

To make the largest H1 heading, like the one above, make a block and start the line with one hash (\`\#\`) followed by a space.

\<pre\>

\# Markdown blocks

\</pre\>

To make a paragraph of text, put a blank line, type your text, and put another blank line using Enter. A paragraph is the most basic Markdown block.

Add a blank line to start a \_new paragraph\_.

Add another blank line to start a new paragraph.

Add a simple linebreak to stay in the same the paragraph.

To get the above result, type:

\<pre\>

To make a paragraph of text, put a blank line, type your text (...).

Add a blank line to start a \*new paragraph\*.

Add another blank line to start a new paragraph.

Add a simple linebreak to stay in the same the paragraph.

\</pre\>

\#\# Markdown lists

To get a H2 heading, start a new Markdown block with two hashes (\`\#\#\`) followed by a space.

\<pre\>

\#\# Markdown lists

\</pre\>

\#\#\# Unordered Markdown lists

A new Markdown block that starts with three hashes (\`\#\#\#\`) gives a H3 heading.

\<pre\>

\#\#\# Unordered Markdown lists

\</pre\>

To make \_unordered\_ (bulleted) Markdown lists, start a new block and prefix each line with an asterisk (\`\*\`), a hyphen (\`-\`) or a plus (\`+\`). Indent sub-levels with at least two spaces.

\-   Unordered list item with \`-\`

\-   Another unordered list item with \`+\`

\-   Unordered sub-list item with \`-\` indented by two spaces.

\-   The next sub-list item must use the same indent.

\-   Another unordered list item with \`\*\`

Paragraphs indented the same way as a list item will align to that list item.

If you indent a paragraph, each indented line after a break creates a new line.

Note that this line is separate, but within the same paragraph.

To get the above result, type:

\<pre\>

\- Unordered Markdown list item with \`-\`

\+ Another unordered list item with \`+\`

\- Unordered sub-list item with \`-\` indented by two spaces.

\- The next sub-list item must use the same indent.

Another unordered list item with \`\*\`

Paragraphs indented the same way (...)

If you indent a paragraph, each (...)

Note that this line is separate (...)

\</pre\>

\#\#\# Ordered Markdown lists

To make ordered Markdown lists, use numbers followed with a period (\`.\`). The actual numbers don’t matter, the list will be automatically numbered. Indent sub-levels with at least two spaces.

1\.  First ordered list item

2\.  Another item

\-   Unordered sub-list.

1\.  Actual numbers dont matter, just that its a number

To get the above result, type:

\<pre\>

1\. First ordered list item

2\. Another item

Unordered sub-list.

1\. Actual numbers dont matter, just that its a number

\</pre\>

\#\# Other Markdown headings

Heading 4

\<pre\>

Heading 4

\</pre\>

\#Heading 5

\<pre\>

\#Heading 5

\</pre\>

\#\#Heading 6

\<pre\>

\#\#Heading 6

\</pre\>

\#\# Blockquotes

\> Blockquotes are indented paragraphs.

\> This line is part of the same indented paragraph.

Normal paragraph break.

\> Since this is a block, use Markdown

\> and \<font color=\\\#ff3e00\\\>HTML\</font\> inline.

\<pre\>

&gt; Blockquotes are indented paragraphs.

&gt; This line is part of the same indented paragraph.

Normal paragraph break.

&gt; Since this is a block, use Markdown

&gt; and &lt;font color=&quot;\#ff3e00&quot;&gt;HTML&lt;/font&gt; inline.

\</pre\>

\#\# Horizontal rule

Put three or more hyphens (\`---\`), asterisks (\`\*\`) or underscores (\`\_\_\_\`) into a line surrounded by blank lines to make a horizontal rule.

---

\<h1\>Inline elements\</h1\>

Inside any Markdown text (also inside tables), you can surround some text with simple Markdown codes or with HTML tags to apply additional formatting. Text wrapped this way is an inline element. It flows with the text and doesn’t create a line break.

\#\# Common Markdown and HTML inline elements

\| Markdown/HTML          \| Description                                \|

\|:-----------------------\|:-------------------------------------------\|

\| \`abc\`              \| surround with two asterisks for bold   \|

\| \`\_\_abc\_\_\`              \| surround with two underscores for bold \|

\| \`abc\`           \| HTML \`b\` is bold                    \|

\| \`\<strong\>abc\</strong\>\` \| HTML \`strong\` \<strong\>is bold\</strong\>     \|

\| \`\_abc\_\`                \| surround with one underscore \_for italic\_  \|

\| \`\*abc\*\`                \| surround with one asterisk \_for italic\_    \|

\| \`abc\`           \| HTML \`i\` is italic                  \|

\| \`\<em\>abc\</em\>\`         \| HTML \`em\` \<em\>is italic\</em\>               \|

\| \`abc\`   \| small is small text         \|

\| \`\<sub\>abc\</sub\>\`       \| sub \<sub\>is subscript\</sub\>                \|

\| \`\<sup\>abc\</sup\>\`       \| sur \<sub\>is superscript\</sub\>              \|

\| \`\<nobr\>abc\</nobr\>\`     \| no-break \<nobr\>keeps words together\</nobr\> \|

\| \`\<link\>abc\</link\>\`     \| link \<link\>is invisible\</link\>             \|

\#\# Other inline HTML elements

\| HTML tag                 \| Description                            \|

\|:-------------------------\|:---------------------------------------\|

\| \`\<address\>abc\</address\>\` \| address \<address\>is italic\</address\>   \|

\| \`\<cite\>abc\</cite\>\`       \| cite \<cite\>is italic\</cite\>            \|

\| \`\<var\>abc\</var\>\`         \| variable \<var\>is italic\</var\>          \|

\| \`\<dfn\>abc\</dfn\>\`         \| definition \<dfn\>is italic\</dfn\>        \|

\| \`\<kbd\>abc\</kbd\>\`         \| keyboard \<kbd\>input is monospace\</kbd\> \|

\<h1\>Code\</h1\>

To format an inline piece of text as \`monospace\`, surround it with backticks (\\\\\`) like so \<code\>\\\\\`abc\\\\\`\</code\> or with the HTML \`code\` tag like so \`\<code\>abc\</code\>\`.

To make a code block, surround your block with the HTML \`pre\` tag. Markdown also allows surrounding code blocks with three backticks (\\\\\`\\\\\`\\\\\`) but this doesn’t work in glyph notes.

\<pre\>

This is an HTML code block with &lt; and &gt; and &amp;.

Indents and line breaks are shown as they are

and Markdown formatting is ignored.

\</pre\>

To get the above, type the following.

Inside the \`pre\` tag, type \`\<\` as \`&lt;\`, \`\>\` as \`&gt;\` and \`&\` as \`&amp;\`.

\<pre\>

&lt;pre&gt;

This is an HTML code block with &amp;lt; and &amp;gt; and &amp;amp;.

Indents and line breaks are shown as they are

and Markdown formatting is ignored.

&lt;/pre&gt;

\</pre\>

\<h1\>Tables\</h1\>

You can use an intuitive Markdown syntax to make a simple, borderless, compact table.

\- The first row is the header row. Use vertical bar (\`\|\`) to separate the columns.

\- The bars don’t need to align, and the outer bars (\`\|\`) are optional, but each row must contain the same number of bars.

\- The second row must use at least three hyphens (\`---\`) to separate the header from the actual cells in each column. Optionally use \`:\` to align columns.

\- Subsequent rows are table cells.

\- You can use Markdown and HTML inside the cells.

\| Left-align   \|     Center     \|    Right-align \|

\|:-------------\|:--------------:\|---------------:\|

\| FontLab      \| ultra bold \| type designers \|

\| Fontographer \|     medium     \|      designers \|

\| TypeTool     \|    \_light\_     \|       students \|

To get the above, type:

\<pre\>

\| Left-align   \|     Center     \|    Right-align \|

\|:-------------\|:--------------:\|---------------:\|

\| FontLab      \| ultra bold \| type designers \|

\| Fontographer \|     medium     \|      designers \|

\| TypeTool     \|    \_light\_     \|       students \|

\</pre\>

\<h1\>Using HTML\</h1\>

\#\# Styling HTML

When you use HTML tags instead of Markdown:

1\. You can use the HTML \`div\` tag to create an unstyled HTML block, and use CSS to apply

some styling to all HTML blocks (lists, paragraphs) inside that block.

2\. You can align text by adding the \`align\` attribute with the possible values \`left\`, \`right\`, \`center\`, \`justify\`

to the \`h1–h6\`, \`p\`, \`div\`, \`dl\`, \`dt\` block tags.

3\. You can wrap some inline text with the HTML \`span\` tag like so \`\<span\>abc\</span\>\`  and apply CSS styling.

4\. To apply CSS styling, add \`style\` attribute to the tag, and use these CSS properties:

\| CSS property                                                     \| Description                           \|

\|:-----------------------------------------------------------------\|:--------------------------------------\|

\| \`color: \#rrggbb\`                                                 \| Text foreground color                 \|

\| \`background-color: \#rrggbb\`                                      \| Background color                      \|

\| \`background-image: \<uri\>\`                                        \| Background image                      \|

\| \`font-family: Family Name\`                                     \| Font family name                      \|

\| \`font-size: \<size\>pt\`, \`\<size\>px\`                                \| Font size, relative or in pt/px       \|

\| \`font-style: normal\`, \`italic\`, \`oblique\`                        \| Upright, italic or oblique font style \|

\| \`font-weight: normal\`, \`bold\`, \`100–900\`                         \| Text font weight                      \|

\| \`text-decoration: none\`, \`underline\`, \`overline\`, \`line-through\` \| Lines under, over or through text     \|

\| \`font: \<style\> \<weight\> \<size\> \<family\>\`                         \| Font shorthand property               \|

\| \`text-transform: uppercase\` , \`lowercase\`                        \| Show text as uppercase or lowercase   \|

\| \`font-variant: small-caps\`                                       \| Show text as small caps               \|

\| \`margin-top: \<len\>px\`                                            \| Top paragraph margin in px            \|

\| \`margin-bottom: \<len\>px\`                                         \| Bottom paragraph margin in px         \|

\| \`margin-left: \<len\>px\`                                           \| Left paragraph margin in px           \|

\| \`margin-right: \<len\>px\`                                          \| Right paragraph margin in px          \|

\| \`text-indent: \<len\>px\`                                           \| First line text indentation in pixels \|

\| \`word-spacing: \<len\>px\`                                          \| Set the width of a word space         \|

\| \`font-kerning: normal\`, \`none\`                                   \| Lets you turn kerning on or off       \|

\| \`white-space: normal\`, \`pre\`, \`nowrap\`, \`pre-wrap\`               \| Treating whitespace                   \|

\| \`float: left\`, \`right\`, \`none\`                                   \| Let text flow around a table or image \|

\| \`page-break-before: auto\`, \`always\`                              \| Page break before a paragraph/table   \|

\| \`page-break-after: auto\`, \`always\`                               \| Page break after a paragraph/table    \|

\#Examples

\<h2 align=\\center\\\>Centered HTML Heading 2\</h2\>

\<pre\>

&lt;h2 align=&quot;center&quot;&gt;Centered HTML Heading 2&lt;/h2&gt;

\</pre\>

\<h3 style=\\font-family: Georgia\\\>HTML Heading 3 with font\</h3\>

\<pre\>

&lt;h3 style=&quot;font-family: Georgia&quot;&gt;HTML Heading 3 with font&lt;/h3&gt;

\</pre\>

\<p align=\\right\\ style=\\color: \#ff3e00; background-color: \#eaebec;

font-variant: small-caps;\\\>Right-aligned paragraph set in colored

small caps on a background\</p\>

\<pre\>

&lt;p align=&quot;right&quot; style=&quot;color: \#ff3e00; background-color: \#eaebec;

font-variant: small-caps;&quot;&gt;Right-aligned paragraph set in colored

small caps on a background&lt;/p&gt;

\</pre\>

\#\# HTML font element

The HTML \`font\` tag is no longer recommended in HTML, but you can use surround inline text with it and use attributes to change the text font \`face\`, \`size\` and \`color\` inline. In addition, you can use the \`style\` attribute with CSS properties.

\| Attribute \| Explanation           \|

\|:----------\|:----------------------\|

\| \`face\`    \| font family name      \|

\| \`size\`    \| font size (unit-less) \|

\| \`color\`   \| \`\#rrggbb\`             \|

Quick brown \<font face=\\Georgia\\ size=\\5\\ color=\\\#ff3e00\\ style=\\text-decoration: overline\\\>font\</font\> jumps.

\<pre\>

Quick brown &lt;font face=&quot;Georgia&quot; size=&quot;5&quot; color=&quot;\#ff3e00&quot;

style=&quot;text-decoration: overline&quot;&gt;font&lt;/font&gt; jumps.

\</pre\>

\#\# Styling HTML lists

\#\#\# Unordered HTML lists

In unordered HTML lists, use \`\<ul type=\\\\\>\` with the values \`square\`, \`disc\` or \`circle\`.

\<ul type=\\square\\\>

\<li\>Unordered list item with square\</li\>

\<li\>Another list item\</li\>

\</ul\>

\<ul type=\\disc\\\>

\<li\>Unordered list item with disc\</li\>

\<li\>Another list item\</li\>

\</ul\>

\<ul type=\\circle\\\>

\<li\>Unordered list item with circle\</li\>

\<li\>Another list item\</li\>

\</ul\>

\<pre\>

&lt;ul type=&quot;square&quot;&gt;

&lt;li&gt;Unordered list item with square&lt;/li&gt;

&lt;li&gt;Another list item&lt;/li&gt;

&lt;/ul&gt;

&lt;ul type=&quot;disc&quot;&gt;

&lt;li&gt;Unordered list item with disc&lt;/li&gt;

&lt;li&gt;Another list item&lt;/li&gt;

&lt;/ul&gt;

&lt;ul type=&quot;circle&quot;&gt;

&lt;li&gt;Unordered list item with circle&lt;/li&gt;

&lt;li&gt;Another list item&lt;/li&gt;

&lt;/ul&gt;

\</pre\>

\#\#\# Ordered lists

In HTML ordered lists, use \`\<ul type=\\\\\>\` with the values \`1\`, \`a\`, \`A\`.

\<ol type=\\a\\\>

\<li\>First ordered list item\</li\>

\<li\>Another item\</li\>

\</ol\>

\<pre\>

&lt;ol type=&quot;a&quot;&gt;

&lt;li&gt;First ordered list item&lt;/li&gt;

&lt;li&gt;Another item&lt;/li&gt;

&lt;/ol&gt;

\</pre\>

\<h1\>Styling HTML tables\</h1\>

To create a table with styling (borders, padding etc.), you need to use HTML tables.

\#\#\# Table attributes

\| attribute     \| meaning                                \|

\|:--------------\|:---------------------------------------\|

\| \`border\`      \| \`0\` for no border, \`1\` for 1px border  \|

\| \`bgcolor\`     \| \`\#RRGGBB\`                              \|

\| \`cellspacing\` \| space between cells, \`val\` in pixels   \|

\| \`cellpadding\` \| outer inside the cell, \`val\` in pixels \|

\| \`width\`       \| relative (\`75%\`) or absolute (\`260\`)   \|

\| \`height\`      \| absolute (\`260\`)                       \|

\#\#\# Table cell attributes

In HTML tables, you can add the following attributes to the \`td\` and \`th\` tags:

\| attribute \| meaning                                        \|

\|:----------\|:-----------------------------------------------\|

\| \`width\`   \| relative (\`20%\`), absolute (\`50\`) or no value) \|

\| \`bgcolor\` \| \`\#rrggbb\`                                      \|

\| \`colspan\` \|                                                \|

\| \`rowspan\` \|                                                \|

\| \`align\`   \| \`left\`, \`right\`, \`center\`, \`justify\`           \|

\| \`valign\`  \| \`top\`, \`middle\`, \`bottom\`                      \|

\#\#\# Table CSS properties

\| CSS                                               \| Description                                \|

\|:--------------------------------------------------\|:-------------------------------------------\|

\| \`border-color: \#rrggbb\`                           \| Table border color if \`border=\\1\\\` or more \|

\| \`border-style: none\`, \`solid\`, \`dotted\`, \`dashed\` \| Table border style if \`border=\\1\\\` or more \|

\| \`padding: \<len\>px\`                                \| All cell padding in px                     \|

\| \`padding-top: \<len\>px\`                            \| Top table cell padding in px               \|

\| \`padding-bottom \<len\>px\`                          \| Bottom table cell padding in px            \|

\| \`padding-left \<len\>px\`                            \| Left table cell padding in px              \|

\| \`padding-right \<len\>px\`                           \| Right table cell padding in px             \|

\| \`vertical-align: top\`, \`middle\`, \`bottom\`         \| Vertical text alignment in table cells     \|

Example

\<table width=\\100%\\ border=\\1\\ cellspacing=\\0\\ cellpadding=\\5\\

style=\\border-style: dotted; border-color: \#d1b434; padding:20px;\\\>

\<thead\>

\<tr\>

\<th align=\\left\\\>Tables\</th\>

\<th align=\\center\\\>Are\</th\>

\<th align=\\right\\\>Cool\</th\>

\</tr\>

\</thead\>

\<tbody\>

\<tr\>

\<td align=\\left\\\>col 3 is\</td\>

\<td align=\\center\\\>right-aligned\</td\>

\<td align=\\right\\\>$1600\</td\>

\</tr\>

\</tbody\>

\</table\>

To get the above result, type:

\<pre\>

&lt;table width=&quot;100%&quot; border=&quot;1&quot; cellspacing=&quot;0&quot; cellpadding=&quot;5&quot;

style=&quot;border-style: dotted; border-color: \#d1b434; padding:20px;&quot;&gt;

&lt;thead&gt;

&lt;tr&gt;

&lt;th align=&quot;left&quot;&gt;Tables&lt;/th&gt;

&lt;th align=&quot;center&quot;&gt;Are&lt;/th&gt;

&lt;th align=&quot;right&quot;&gt;Cool&lt;/th&gt;

&lt;/tr&gt;

&lt;/thead&gt;

&lt;tbody&gt;

&lt;tr&gt;

&lt;td align=&quot;left&quot;&gt;col 3 is&lt;/td&gt;

&lt;td align=&quot;center&quot;&gt;right-aligned&lt;/td&gt;

&lt;td align=&quot;right&quot;&gt;$1600&lt;/td&gt;

&lt;/tr&gt;

&lt;/tbody&gt;

&lt;/table&gt;

\</pre\>

\<h1\>Remarks\</h1\>

\#\# Links and images

Markdown lets you include \[links\](https://www.fontlab.com/) and images !\[icon\](https://res.cloudinary.com/fontlab/image/fetch/f\_auto,w\_32,c\_scale/https://www.fontlab.com/img/icon-fontlab-vi.png \\title\\) but links and images don’t work in glyph notes.

\<pre\>

Markdown lets you include

\[links\](https://www.fontlab.com/)

and images

!\[icon\](https://www.fontlab.com/img/icon-fontlab-vi.png &quot;title&quot;)

but links and images don&\#x2019;t work in glyph notes.

\</pre\>

\#\# Mixing Markdown and HTML

You can use HTML tags inside Markdown, and you can use Markdown inside inline HTML, but you cannot use Markdown inside HTML blocks.

So \`\_italic \<sup\>superscript\</sup\> text\_\` will produce \_italic \<sup\>superscript\</sup\> text\_

and \`cited bold text\` will produce cited bold text, but

\<pre\>

&lt;div style=&quot;color: \#ff3e00&quot;&gt;

some bold text in a \`div\`

&lt;/div&gt;

\</pre\>

will ignore the Markdown formatting and will produce

\<div style=\\color: \#ff3e00\\\>

some bold text in a \`div\`

\</div\>

\#\# Escaping characters in Markdown

To use characters that are used in Markdown, “escape” (prefix) them with \`\\\\\`.

\| escape   \| escape result         \|

\|:---------\|:----------------------\|

\| \`\\\\\\\\\`     \| \\\\\\\\ : backslash        \|

\| \`\\\\\` \\\\\` \\\\ \| \\\\\` : backtick \|       \|

\| \`\\\\\*\`     \| \\\\\* : asterisk         \|

\| \`\\\\\_\`     \| \\\\\_ : underscore       \|

\| \`\\\\\#\`     \| \# : hash              \|

\| \`\\\\+\`     \| + : plus              \|

\| \`\\\\-\`     \| - : hyphen            \|

\| \`\\\\.\`     \| . : dot               \|

\| \`\\\\!\`     \| ! : exclamation       \|

\| \`\\\\\{\\\\\}\`   \| \{\} : curly braces     \|

\| \`\\\\\[\\\\\]\`   \| \\\\\[\] : square brackets \|

\| \`\\\\(\\\\)\`   \| () : parentheses      \|