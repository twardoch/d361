## Metadata_Start 
## code: en
## title: Set variation location when you add a new layer 
## slug: set-variation-location-when-you-add-a-new-layer 
## seoTitle: Set variation location when you add a new layer 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab has several ways to create a new layer in one or more glyphs, and to optionally also add a font master, which will hold separate ==Font Info== data and kerning.

With the following techniques, you can add a new font master, and optionally fill its glyph layers with the content of another font master:

- ==Font > Add Variation== is the fastest way to duplicate the current font master (including all its font master data, and its glyph layers). Here, you can also quickly run a predefined action set.

- The ==+== button in the bottom-left of the ==Font Info== dialog gives you a few more choices. Here, you can add a new font master, and you can specify how to create the layers in the new glyphs. You can create a new font master with default font master data, and copy the glyph layers from the current master, or create glyph layers with no content, or not create any glyph layers. Or you can copy an existing font master (even from another font), including all its font master data, and its glyph layers.

With these techniques, you can create new glyph layers, and optionally a font master, which will contain **interpolated** content that will reflect the current dynamic instance (the `#instance` layer):

- With the ==Add glyph master== (==+==) button in the ==Variations== panel, you can add glyph layers (but no font master) to the selected glyphs. The layers will contain the current dynamic instance selected in the panel. This is useful to create intermediate glyph masters in only a few glyphs.

- With ==Font > Generate Instance== or with the ==Add current instance as font master== button in the ==Variations== panel, you can add a font master that will reflect the current dynamic instance selected in the panel, including interpolated kerning, interpolated Font Info data, and the interpolated variation location.

![Set variation location when adding layer](https://i.fontlab.com/fl8/rn/fl8-rn-variation-location-in-add-layer.png){ .r data-scale='50%' title="Set variation location when adding layer" }

Finally, the most advanced way to create new glyph layers and font masters is to use ==Glyph > Layer > Add…==, or the ==Add layer== button in the ==Layers & Masters== panel. This offers all choices available in the methods described above. It opens the ==Add Layer== dialog, where you can:

- specify the name of the new layer (and optionally font master)
- set the lock, service and wireframe properties of the new layer
- can specify the location of the new layer in the variation space
- choose to add the new layer in the current glyph, selected glyphs, or all glyphs and optionally to also add a font master
- decide what should happen if the same-named layer already exists in a glyph
- optionally fill the new layer with the content of another master from the same or different font, or with the currently selected dynamic instance
- if you use element references, and you’re adding the new layer to some glyphs but that layer already exists in other glyphs, you can change the references to point to elements that already exist in the layer
- create a bitmap layer that will contain rasterized content at a specified PPM

