## Metadata_Start 
## code: en
## title: Mask Properties 
## slug: mask-properties 
## seoTitle: Mask Properties 
## description:  
## contentType: Markdown 
## Metadata_End
Masks in Vexy Lines determine which parts of your artwork are visible and which are hidden. 

To access mask properties, look for the **MASK** section in the Properties palette and click the > icon to expand it.

![vl-mask.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/vl-mask.png){height="" width="300"}

Once expanded, you'll see several options that control how your mask behaves and appears:

## Invert
![mask-invert.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mask-invert.svg) Flip your mask inside out with one click:
- Switch between masked and unmasked areas
- Create interesting negative space effects
- Quickly reverse your mask's effect

## Smooth Mode
Enable the Smooth checkbox to unlock soft, blended masking effects. This mode is perfect for creating natural-looking transitions and subtle effects. When disabled, masks have crisp, precise edges.

### Opacity
![mask-opacity.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mask-opacity.svg) Control how see-through your mask appears
- Blend layers together naturally
- Create subtle overlapping effects
- Available when Smooth mode is on

### Feather
![mask-feather.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mask-feather%281%29.svg) Softens mask edges
- Creates gentle transitions
- Perfect for natural-looking blends
- Works only with Smooth mode

## Modify
The **Modify** section provides tools to adjust your mask's shape and appearance after creation. These tools help you refine your mask without starting over, giving you more control over your artwork.

### Expand or Contract
![mask-expand.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mask-expand.svg) Make your entire mask larger or smaller:
- Grow the mask outward (positive values)
- Shrink the mask inward (negative values)
- Fine-tune the mask's coverage

### Edge to Stroke
![mask-stroke.svg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/mask-stroke.svg) Transform your mask's edge into a thick stroke:
- Convert the boundary into a stroke
- Adjust the stroke width as needed
- Create interesting outline effects

Remember: Turn on Smooth mode when you want soft, blended effects. Keep it off when you need sharp, precise edges.