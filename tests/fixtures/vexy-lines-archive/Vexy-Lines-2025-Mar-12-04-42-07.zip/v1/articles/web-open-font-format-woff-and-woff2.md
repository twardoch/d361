## Metadata_Start 
## code: en
## title: Web Open Font Format (WOFF and WOFF2) 
## slug: web-open-font-format-woff-and-woff2 
## seoTitle: Web Open Font Format (WOFF and WOFF2) 
## description:  
## contentType: Markdown 
## Metadata_End

Web Open Font Format (WOFF) is actually an OpenType or TrueType font with compression and some additional data for use on web pages. Its purpose is to support font distribution from a web server to a client browser over a network.

WOFF 2.0 (WOFF2), with reference code provided by Google, is an update with improved compression. WOFF 2.0 uses Brotli as the byte-level compression format, giving more than 30% reduction in file size.

Table with support by browser