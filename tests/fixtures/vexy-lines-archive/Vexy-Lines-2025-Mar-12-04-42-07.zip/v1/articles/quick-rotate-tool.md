## Metadata_Start 
## code: en
## title: Quick Rotate tool 
## slug: quick-rotate-tool 
## seoTitle: Quick Rotate tool 
## description:  
## contentType: Markdown 
## Metadata_End

The Quick Rotate tool is used to quickly rotate the active contour selection or element, depending one the currently active tool. Tap R to activate it (hold the key to activate it temporarily). 

Hold the mouse button and DRAG to rotate current selection or element. Hold SHIFT to constrain rotation to 15 degree increments.