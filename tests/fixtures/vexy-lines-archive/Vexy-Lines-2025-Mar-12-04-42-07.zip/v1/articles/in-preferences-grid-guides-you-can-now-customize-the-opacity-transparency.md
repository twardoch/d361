## Metadata_Start 
## code: en
## title: In Preferences > Grid & Guides you can now customize the opacity (transparency 
## slug: in-preferences-grid-guides-you-can-now-customize-the-opacity-transparency 
## seoTitle: In Preferences > Grid & Guides you can now customize the opacity (transparency 
## description:  
## contentType: Markdown 
## Metadata_End

In Preferences \> Grid & Guides you can now customize the opacity (transparency) at which the Glyph window displays font dimension lines, font guides (also applies to zones), glyph guides (also applies to hints) and elements guides when they’re turned on in the View menu. If you drag the opacity sliders down to 20-25%, these lines are still visible but no longer visually disturb your content.