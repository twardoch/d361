## Metadata_Start 
## code: en
## title: Typing glyphs in Glyph window 
## slug: typing-glyphs-in-glyph-window 
## seoTitle: Typing glyphs in Glyph window 
## description:  
## contentType: Markdown 
## Metadata_End

1. **capture**

When you press Cmd+L or choose Edit \> List Related Glyphs… in the Glyph window, FontLab shows a popup that shows glyphs that are in some way related to the current glyph. You can choose a glyph with the arrow keys.

In this popup, as well as in the Edit \> Find Glyphs popup (Cmd+F/Ctrl+F), the Quick Find Glyph popup (/) and the Find by Unicode popup () in the Glyph window:

* When you press Enter, FontLab will insert the glyph you chose into the text and replace the current glyph.
* In FontLab 7, when you press Cmd+Enter (Mac) or Ctrl+Enter (Windows), FontLab will insert the glyph you chose into the text after the current glyph, so you will see both glyphs.