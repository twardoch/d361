## Metadata_Start 
## code: en
## title: Creating a New Document 
## slug: creating-new-document 
## seoTitle: Creating a New Document 
## description:  
## contentType: Markdown 
## Metadata_End
In this guide, we will walk you through the process of creating a new document in Vexy Lines, a robust tool designed to convert raster images into vector artwork. 

Vexy Lines features an easy-to-use interface that enables you to import your original raster image, also known as the "source image". This source image could be a photograph, a scanned hand-drawn sketch, or any other bitmap image. The document you create in Vexy Lines will contain this source image and a structure comprising the data needed to generate your vector artwork. The document itself has a rectangular shape defined by the height, width, and resolution parameters.

The following steps will help you create your first document and kickstart your artistic journey with Vexy Lines.

## Steps to Create a New Document

1. **Open New Document Options Dialog:** To create a new document in Vexy Lines, go to **File->New**. The New Document Options dialog box will appear in the center of the screen.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-42YIXP6E.png){height="" width="940"}

2. **Load Source Image:** In the middle of the New Project Options dialog box is a placeholder for the source image. You can either drag your bitmap image to this location or click on the "open" link and select this image in the file dialog. Alternatively, you can choose the "New from clipboard" menu item to load an image from the clipboard.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-P5BM1BZG.png){height="" width="940"}

3. **Set Document Parameters:** The right side of the dialog box displays the parameters of the new document based on the loaded image - height, width, and resolution. You can modify these parameters as required. If you select the "resample" option, the number of pixels in the image will remain unchanged, but the size will be adjusted by changing the "resolution" parameter.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-CDH6K61V.png){height="" width="184"}

> **Consider Resolution:** Remember that increasing "resolution" may not always enhance the final result. For tasks where the maximum step between strokes won't exceed 1mm, it's advisable to set "resolution" no more than 96dpi.


5. **Create Blank Document (Optional):** In some instances, you might want to begin with a blank document without an original image. To do this, click on the "create empty document" button in the upper right corner of the dialog box, and choose from standard document presets with predefined sizes.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-FZD0CZUH.png){height="" width="940"}

6. **Finalize Document Creation:** To finish creating a new document, click the "Ok" button located in the lower right part of the dialog box. This action creates a new document with your entered parameters and source image while closing any previous documents. To cancel this operation, click the "Cancel" button located next to it.


## Example: Creating a New Document in Vexy Lines

Let's illustrate the process of creating a new document in Vexy Lines using a real-world example. Imagine you have a fantastic photo from your recent vacation, and you wish to print this photo on a t-shirt. While you could simply print the photo directly or use a neural network to generate the image, you want something more creative and personalized. Perhaps you're thinking about a design that resembles shading or engraving. Vexy Lines is the perfect tool for this job.

Let's begin by following the steps outlined above to create a new document:

1. **Open the New Document Dialog Box:** Launch Vexy Lines and navigate to **File->New**. The New Document Options dialog box will appear on your screen.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-PTF9CGTB.png){height="" width="940"}

2. **Load Your Photo:** Now, drag and drop your photo into the dialog box, or click on "Open" to load it from your files. Once loaded, the photo will be displayed in the dialog box, and its dimensions will appear on the right side.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3NOC2I0H.png){height="" width="940"}

3. **Check and Adjust Parameters:** The photo's size is currently displayed as 4033x3025px at 300dpi. However, these pixel dimensions may not be ideal for our purpose, so let's convert them to millimeters by clicking on the "Unit" button and selecting "millimeters". The new dimensions become 341x256mm at 300dpi.

4. **Resize Your Image:** The image might be too large for our needs, so let's resize it. A width of 150mm should suffice. Enter "150mm" for the width, and the height will automatically adjust based on the image's proportions, giving us new dimensions of 150x112mm.

5. **Adjust Resolution:** The current resolution is 300dpi, which might be too high for fabric printing where the hatching step shouldn't exceed 1mm. Let's reduce the resolution to 96dpi. You could also go as low as 72dpi; the specific value isn't crucial in this case.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3GE41EJ9.png){height="" width="940"}

6. **Create Your Document:** Click "OK" to finalize your settings and create your new document. You'll now see your new document in the Vexy Lines workspace, complete with your loaded image and specified dimensions of 150x112mm.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-4HBKMIE2.png){height="" width="940"}

With your new document ready, you're all set to start creating your first hatching or filling. Enjoy exploring the creative possibilities with Vexy Lines!

-->