## Metadata_Start 
## code: en
## title: Transform 
## slug: transform-2 
## seoTitle: Transform 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:transform-->
The TRANSFORM panel let you move, resize, and rotate the selected group of objects.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28655%29.png){height="" width="300"}

To access these options, click the "Expand" button.
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28664%29.png){height="" width="300"}

### Reference Point
<!--qh:center-->
Use this control to set a point on the bounding box of the selected group of objects. Transformation will happen relative to this point, and its coordinates will be shown in the corresponding input fields.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28656%29.png){height="" width="300"}

### Positioning
<!--qh:transformXY-->
These fields are for entering coordinates of the selected group of objects, determined by the currently set reference point.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28657%29.png){height="" width="300"}

<!--qh:transformOffset-->
If the relative positioning mode is on, the entered values will be added or subtracted from the current coordinates of the reference point, shifting the objects in the selected group accordingly.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28658%29.png){height="" width="300"}

### Size
<!--qh:transformWH-->
Size input fields determine the width and height of the selected group of objects. Changes in width and height will be relative to the chosen reference point.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28659%29.png){height="" width="300"}

<!--qh:transformLink-->
The **Link** button enables the mode to maintain the proportions of size values.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28660%29.png){height="" width="300"}

### Rotation
<!--qh:transformAngle-->
The **Rotate** input field is for rotating the selected group of objects around the specified reference point by a specified angle in degrees.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28661%29.png){height="" width="300"}

### Flip
<!--qh:flip-->
Buttons for vertical and horizontal flipping of objects.
<!--qh-->

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28663%29.png){height="" width="300"}

