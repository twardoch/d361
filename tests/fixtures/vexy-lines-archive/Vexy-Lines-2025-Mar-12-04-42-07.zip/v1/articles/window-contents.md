## Metadata_Start 
## code: en
## title: Window Contents 
## slug: window-contents 
## seoTitle: Window Contents 
## description:  
## contentType: Markdown 
## Metadata_End

You can export the window contents – what you see on the Glyph Window or the Sketchboard – as Scalable Vector Graphics (SVG) or as PDF. The format and destination can be selected in the Standard Save File dialog box before you click Save. This command exports not only outlines and bitmaps but also hints, guidelines, metrics, zones etc. – everything you turned on in the View menu.

wincontents.png