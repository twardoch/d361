## Metadata_Start 
## code: en
## title: Single Window Mode 
## slug: single-window-mode 
## seoTitle: Single Window Mode 
## description:  
## contentType: Markdown 
## Metadata_End

**TBA**.