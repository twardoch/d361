## Metadata_Start 
## code: en
## title: Adding a Layer 
## slug: adding-a-layer-1 
## seoTitle: Adding a Layer 
## description:  
## contentType: Markdown 
## Metadata_End
You'll want to create a new layer when you need to:
- Apply different fill styles to separate areas
- Work on elements independently
- Organize your artwork more effectively
- Keep complex designs manageable

For example, when creating a portrait, you might use separate layers for hair, face, and clothing since each area might need different fill styles.

### Creating Layers

You can add new layers in several ways:
- Choose **Layer > New > Layer** from the menu
![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-FWQBELV9.png){height="" width="221"}
- Click the "Add Layer" button ![Add a new Layer](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/add-layer.svg) in the Layers panel
- Create a fill in an empty document (this automatically creates a layer)
- Start drawing a mask when no layer is selected
- Use the Pencil tool without selecting a layer

The new layer will appear in your Layers panel. Double-click its name to rename it.

### Layer Location

New layers are always created within the selected group. If no group is selected, the layer will be created in the root of the document.

This hierarchy helps you organize complex artwork. For example, you might have:
- A "Background" group with landscape layers
- A "Character" group with separate layers for body parts
- A "Details" group with highlight and shadow layers
