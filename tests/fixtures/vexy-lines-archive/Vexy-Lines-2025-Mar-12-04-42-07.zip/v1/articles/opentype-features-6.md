## Metadata_Start 
## code: en
## title: OpenType features 
## slug: opentype-features-6 
## seoTitle: OpenType features 
## description:  
## contentType: Markdown 
## Metadata_End

*Compiling features*

FontLab uses the FEA syntax to describe the way OpenType Layout features will work in the final font. You can edit these features definitions in the Features panel. FontLab compiles the feature definitions into binary OpenType Layout tables when you export an OpenType font, or when you click the Compile button in the Features panel or the Features sidebar in the Glyph window, or the Features dialog in the Preview panel or Glyph window property bar. FontLab uses the industry-standard Adobe FDK for OpenType library to compile the features.

[![][fl712-feature-error]](file:///Volumes/Igor/Manual/Github/docs/fontlab/7/manual/img/fl712-feature-error.png)

More readable feature compilation errors and warnings

When there is a problem in the feature definitions and FontLab 7.1.2 compiles them, the Output panel now shows problem messages that are much more meaningful. They include the name of the feature and/or lookup in which the problem occurs. The messages now use the following prefixes:

* \[N\] means Note: informative message about a potential problem that FontLab automatically corrects
* \[W\] means Warning: shown in bold, the message indicates a more serious problem; FontLab can still compile the features, but the resulting features may not work as you intended
* \[E\] means Error, 
* \[F\] means Fatal Error: shown in red and bold, the message points to a serious problem in the feature definitions that prevents FontLab from compiling the features completely. FontLab may still export the font, but the font will contain no features.

[fl712-feature-error]: fl712-feature-error.png width=360px height=30px