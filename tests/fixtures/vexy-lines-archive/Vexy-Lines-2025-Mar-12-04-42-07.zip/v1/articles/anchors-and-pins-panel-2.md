## Metadata_Start 
## code: en
## title: Anchors and Pins panel 
## slug: anchors-and-pins-panel-2 
## seoTitle: Anchors and Pins panel 
## description:  
## contentType: Markdown 
## Metadata_End

The glyphs table at the bottom of the Anchors and Pins panel is now shown only in the Anchors tab, since it has no relevance for the Pins tab. Pins are only used in elements.