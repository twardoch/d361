## Metadata_Start 
## code: en
## title: Organizing Font Families 
## slug: organizing-font-families-1 
## seoTitle:  
## description:  
## contentType: Markdown 
## Metadata_End

[TOC]

The ==Fonts > Organize Fonts== submenu offers some automatic operations for organizing/[naming fonts](Font-Naming) within font families. Use these commands for the fonts selected in the [[Fonts panel]].


## Families from Styling Group


This operation divides one large family into several smaller families – it copies the existing Styling group names to Typographic family names, and copies the existing Styling link names to Typographic style names. The result is that each font will have identical menu names in all applications (both modern applications such as those on Mac OS X or by Adobe, and on old Windows applications). This is useful if you want 100% cross-platform compatibility, including on older Windows apps, for your naming. 

Note, however, that each such family will have no more than four styles, and that all styles will have names “Regular”, “Italic”, “Bold” or “Bold Italic”. So the “typographic finesse” of the family naming will be lost and you will no longer have “large families” containing more than four members.

For example, 6 fonts from the Adobe Caslon Pro family will be divided into 2 families the following way:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-organizing_font_family_01.png)


## Families from PostScript Name


Uses the PostScript names to build the typographic family names and typographic style names. Useful primarily if your source fonts are old Mac Type 1 or Windows Type 1 fonts that did not get good typographic stylings. Since the PostScript names don’t use spaces, you may need additional editing to “prettify” the Typographic family and style names.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-organizing_font_family_02.png)


## Separate Families


This operation divides one family into several families: every single family member becomes a separate family. The Full font name is used as the Typographic family name, and “Regular” is used as the Typographic style name. This can be useful if your font family is incomplete, lacking certain basic styles. Also useful when creating CSS-compatible webfonts. For example, 6 fonts from the Adobe Caslon Pro family will be divided into 6 families the following way:

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-organizing_font_family_03.png)


## Merge Families


This is the opposite to the previous operation. It tries to place all selected fonts into one family. This is a complex operation — FontLab will attempt to rebuild the Typographic style name for each font using the design parameters declared in the fonts. FontLab will also attempt to resolve some naming conflicts, and will automatically place fonts into styling groups. The results may require additional manual name editing, or using one of the next commands. 


## Build Styling Group Names


Builds Styling group names for the selected fonts based on the Typographic family name and the Typographic style name of the regular style within each Styling group. Useful if you changed the Typographic family or style names or after merging families.


## Optimal Styling


The most “magical” operation: attempts to build optimal styling groups within the families in which the selected fonts reside. FontLab will analyze the various design parameters declared in the fonts; find fonts which match; and produce styling groups in which most fonts will be linked to their italic counterparts, while the fonts with the regular (numeric 400) and bold (700) Weight will also be linked together. Useful if some fonts from your family are not accessible in some applications, particularly in Microsoft Office on Windows or Mac OS X, or in other Windows applications.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-organizing_font_family_05.png)

<!---
## Italic Styling

Attempts to build styling groups by linking fonts with their matching italic counterparts. Does not link fonts across different weights, otherwise similar to Optimal Styling. Useful if you definitely want each weight of a family to appear as a single “family” in older Windows applications, but want to retain italic style linking.
-->


## Separate Styling


Places each font within a family into a separate styling group and sets each font’s Styling link value to Regular.

![image](https://github.com/Fontlab/FontLabVI-help/blob/master/img/flvi-organizing_font_family_06.png)


## Build Style Names


Another “magical” operation: analyses the design parameters (Weight, Width, Slope) declared in Font Info and automatically builds good Typographic style names. It builds the TSNs using naming conventions adopted by many vendors.
