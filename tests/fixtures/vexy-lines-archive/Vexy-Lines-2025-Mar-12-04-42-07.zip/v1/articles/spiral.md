## Metadata_Start 
## code: en
## title: Spiral Fill 
## slug: spiral 
## seoTitle: Spiral 
## description:  
## contentType: Markdown 
## Metadata_End
<!--qh:spiral-->
The **SPIRAL** fill type in Vexy Lines produces a continuous spiral engraving using one smooth line. Use this fill for a clean, mechanical engraving effect in your design.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28105%29.png){height="" width="400"}
<!--qh-->

### Fill Parameters:

![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2875%29.jpeg){height="" width="300"}

<!--qh:spiralInterval-->
![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) **Interval** ([units](/v1/docs/units)): Sets the distance between each turn of the spiral. Use a lower value for a tighter engraving and a higher value for more space.
<!--qh-->

<!--qh:spiralDispersion-->
![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-dispersion.svg) **Interval Randomization** (%): Adds a small random variation to the spacing for a slightly hand-crafted look.
<!--qh-->

<!--qh:spiralMiddle-->
![Stroke Shift](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-middle.svg) **Stroke Shift**: Adjusts the starting point of the spiral turns.
<!--qh-->

<!--qh:spiralCenter-->
![Center](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/center_x.svg) **Center** ([units](/v1/docs/units)): Determines the center point from which the engraving begins.
<!--qh-->

These parameters let you fine-tune the engraving to suit your design.

## Creating and Customizing a Spiral Fill

To create a new Spiral fill, follow the steps in our [Creating a new fill](/v1/docs/creating-new-fill) guide and select **Spiral**.

![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2874%29.jpeg){height="" width="160"}

Fine-tuning your Spiral fill involves adjusting its parameters. Here's a simple guide:

1. Access Properties: Go to the PROPERTIES panel, typically on the left side of the Vexy Lines interface.

2. Locate Parameter: In the PROPERTIES panel, switch to the SPIRAL FILL tab and find the parameter you wish to adjust.

Feel free to experiment with these parameters to create unique and dynamic engraving patterns for your vector artwork.

### Interval
1. Find the **Interval** ![Interval](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-interval.svg) parameter in the SPIRAL FILL tab.
2. Adjust the distance using the slider or by typing a value.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28129%29.png){height="" width="300"}

<!--qh:spiralInterval-->
| interval: 1 | interval: 2 | interval: 3 |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28114%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28115%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28116%29.jpeg){height="" width="300"}|
<!--qh-->

### Randomization
1. Find the **Randomization** ![Randomization](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/sm-dispersion.svg) parameter.
2. Adjust it to add variation to the spacing.
3. Higher values make the engraving less uniform.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28128%29.png){height="" width="300"}

<!--qh:spiralDispersion-->
| randomization: 10% | randomization: 50% | randomization: 100% |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28117%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28118%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28121%29.jpeg){height="" width="300"}|
<!--qh-->

### Shift
1. Find the **Shift** parameter.
2. Adjust it to change the starting angle of the spiral.
3. This alters the overall orientation of the engraving.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28127%29.png){height="" width="300"}

<!--qh:spiralMiddle-->
| shift: 15% | shift: 50% | shift: 70% |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28122%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28123%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28124%29.jpeg){height="" width="300"}|
<!--qh-->

### Center
1. Find the **Center** parameter.
2. Set the horizontal and vertical coordinates to define the engraving's center.
3. You can adjust these values using the slider, entering them manually, or using the Interactive Center Locator.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%28106%29.png){height="" width="300"}

<!--qh:spiralCenter-->
| center: 40,40 | center: 80,0 | center: 40,80 |
| --- | --- | --- |
|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2877%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2878%29.jpeg){height="" width="300"}|![image.jpeg](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2879%29.jpeg){height="" width="300"}|
<!--qh-->

## Stroke Properties
Additional stroke properties include:
1. [COLOR](/v1/docs/color-strokes)
2. [IMAGE THRESHOLD](/v1/docs/image-threshold)
3. [STROKE THICKNESS](/v1/docs/stroke-thickness)
4. [DASHED LINE](/v1/docs/dashed-line)
5. [STROKE CAPS](/v1/docs/stroke-caps)
6. [EMBOSS](/v1/docs/emboss)
7. [OVERLAP CONTROL](/v1/docs/overlap-control)

## Link to Example
You can use the example file [UM3-Fills-Spiral.strx](https://www.tracexz.com/um3/UM3-Fills-Spiral.strx) to practice adjusting Spiral fill settings.
