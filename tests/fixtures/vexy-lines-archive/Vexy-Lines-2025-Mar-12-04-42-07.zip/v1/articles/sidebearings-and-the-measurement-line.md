## Metadata_Start 
## code: en
## title: Sidebearings and the measurement line 
## slug: sidebearings-and-the-measurement-line 
## seoTitle: Sidebearings and the measurement line 
## description:  
## contentType: Markdown 
## Metadata_End

Horizontal glyph metrics (usually referred to as \_glyph metrics\_ or just \_metrics\_) are metric values of individual glyphs that are used to compute line lengths. This includes advance widths and sidebearings.

\_Advance width\_ is the white space taken by a glyph, regardless of the marking portions of the glyph. For example, the space character has an advance width, even though it has no outline. It is not unusual to give numerals the same advance width, even though the space taken up by their glyph outlines may vary. It is possible for a marking glyph to have no advance width at all, as is sometimes done with combining accent marks.

\_Sidebearings\_ are the amount of white space on each side of a glyph. The distance between the origin of the glyph and the first marking point on the glyph outline is the \_left sidebearing\_. The distance between the farthest right marking portion of the glyph and the advance width is the \_right sidebearing\_. When the glyph takes up less space than the advance width, inside the sidebearings, that creates positive sidebearings. Sometimes part of a glyph can “stick out” beyond the advance width; this creates a negative sidebearing. For example, if the right side of the letter “f” goes beyond the advance width, it has a negative sidebearing. An accent mark with no advance width might be centered on the X=0 origin line, and have both sidebearings negative.

Abbreviations RSB (right sidebearing) and LSB (left sidebearing) are sometimes used in FontLab.

For details on editing metrics, see Editing Glyph Metrics. Also see Glyph Positioning.