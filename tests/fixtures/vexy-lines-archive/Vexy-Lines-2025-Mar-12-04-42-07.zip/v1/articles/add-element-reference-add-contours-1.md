## Metadata_Start 
## code: en
## title: Add Element Reference > Add Contours 
## slug: add-element-reference-add-contours-1 
## seoTitle: Add Element Reference > Add Contours 
## description:  
## contentType: Markdown 
## Metadata_End

**Add Element Reference \> Add Contours**

**NEW** If you have multiple masters and you want to copy-paste the content of each master of one glyph into the corresponding master of another glyph, you can now use the Add Contours operation.

[![][fl713-add-contours]](https://help.fontlab.com/fontlab/7/alpha/img/fl713-add-contours.png)

Element \> Element Reference \> Add Contours

Navigate to the glyph into which you want to add the contours, and choose Element \> Element Reference \> Add Element Reference (Ctrl+I / Ctrl+Alt+Shift+I). In the dialog, type the name of the source glyph, and turn on Apply to all masters. Click Add Contours or press Cmd+Enter / Ctrl+Enter, and FontLab will insert the contours of the source glyph to the current glyph, matching master by master.

Turn off Apply to all masters in the dialog, and the result will be the same as Paste Contours.

[fl713-add-contours]: fl713-add-contours.png width=320px height=250px