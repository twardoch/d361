## Metadata_Start 
## code: en
## title: OpenType 
## slug: opentype-2 
## seoTitle: OpenType 
## description:  
## contentType: Markdown 
## Metadata_End

OpenType, also identified as OT, is the most used font format nowadays. It’s supported in all modern operating systems and offers a number of improvements over previous formats. Based on Unicode, an OpenType font can have up to 65,536 glyphs. It allows the designer to include advanced typographic refinements such as true small caps, different styles of figures, and extensive sets of ligatures and alternates.

In the Type Reference chapter there are additional details about the OpenType format.

| :----- |
| Note that different applications have differing levels of support for the OpenType features. |