## Metadata_Start 
## code: en
## title: Action status bar 
## slug: action-status-bar 
## seoTitle: Action status bar 
## description:  
## contentType: Markdown 
## Metadata_End

The status bar (bottom line) of the ==Tools > Actions== dialog now gives a better synopsis of what will happen:

- if FontLab will run an action set or an action (then its name is shown)
- which layers will be affected, depending on the top ==Layers== selector
- how many glyphs will be affected, depending on the top ==Glyphs== selector