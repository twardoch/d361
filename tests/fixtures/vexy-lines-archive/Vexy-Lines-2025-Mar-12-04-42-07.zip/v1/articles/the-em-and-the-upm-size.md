## Metadata_Start 
## code: en
## title: The Em and the UPM Size 
## slug: the-em-and-the-upm-size 
## seoTitle: The Em and the UPM Size 
## description:  
## contentType: Markdown 
## Metadata_End

**TBA: clean text, captures**

Each glyph is designed in a space called an *Em*. The Em in metal type was originally a square of metal the same height and width as the point size. This may have gotten its name from an average letter “M” that required a block of about that width.

In digital type, the Em is simply an imaginary space, subdivided into a grid for design purposes. The division is usually 1000 or 2048 units, referred to as **Units Per eM (UPM) size**. Think of these units and the grid as relative coordinates rather than as specific physical distances.

In FontLab, you can set the UPM in File \> Font Info \> Family Dimensions.

When type is imaged on screen or in print, the Em is scaled to the desired size. For example, when type is scaled to 12 points, it is the Em that is 12 points high, not any particular/specific part of the type or its letters. Defining a font in this fashion allows a single outline to be scaled to any size requested. It is also independent of any single writing system, allowing a common scale for things as diverse as symbol fonts, Arabic, Chinese and English (this diversity is why we can’t just specify all font size by, say, cap height).

The font’s effective height is determined by the distance between the highest and lowest points on the outline, which might be the ascender and descender in western (Latin) fonts. This can be more or less than the height of the Em.

The position of the baseline in the Em is always at zero in the X direction; but how much of the Em is above the baseline and how much is below can vary. Generally in western fonts it is 75–80% above and 20–25% below.

If a font has 1000 UPM, to get a text string with a height of 100 pixels (assuming that we use a raster output device), the rendering system would scale this font by 10%. If a font has 2048 UPM size of 2048, to get a text string of 100 pixels it would need to be scaled by 4.9%. 

| :----- |
| The maximum UPM size allowed by font format specs is 16,384 for TrueType and OpenType TT. |

OpenType PS fonts usually have a UPM size of 1000 font units. Although they can theoretically have any UPM within the spec limit, there are various old systems and workflows with lower limits. If you intend to output as OpenType PS (.otf), whatever UPM you use, keeping all glyph coordinates within +/4095 units in X and Y on the grid is “safer.”

Microsoft promotes having UPM for TrueType fonts always be a power of 2 for performance reasons. However, on modern hardware this is rarely an issue. TrueType and OpenType TT fonts typically have a UPM size of 2048 units, although other values are more common than is the case with OpenType PS fonts.

| :----- |
| Glyphs are not restricted directly by the Em, but font consumers (operating systems and applications) may have unexpected problems with glyphs that exceed the Em by dramatic amounts. We recommend restricting all vertical (y direction) coordinates to not exceed 1.3 x the Em. |