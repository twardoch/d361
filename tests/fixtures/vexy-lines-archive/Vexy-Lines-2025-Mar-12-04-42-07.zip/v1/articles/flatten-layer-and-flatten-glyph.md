## Metadata_Start 
## code: en
## title: Flatten Layer and Flatten Glyph 
## slug: flatten-layer-and-flatten-glyph 
## seoTitle: Flatten Layer and Flatten Glyph 
## description:  
## contentType: Markdown 
## Metadata_End

When you choose Glyph \> Flatten Layer, FontLab “flattens” the current layer in the current glyph (or, in Font window, in selected glyphs): it decomposes all components, removes all filters and combines the decomposed elements into a single element.

When you hold Alt and click the Glyph menu, the menu item is called Flatten Glyph. When you choose it, FontLab flattens all layers in the current glyph or in selected glyphs.