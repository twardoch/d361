## Metadata_Start 
## code: en
## title: Moving control points 
## slug: moving-control-points 
## seoTitle: Moving control points 
## description:  
## contentType: Markdown 
## Metadata_End

To keep the direction of the control vector unchanged, hold down Shift while moving the moving the control point:

![][contour_tool_07]

To temporarily change the connection type from sharp to smooth, so that the adjacent control vector will be collinear hold down Alt while dragging the control point.

*Shift-double-click to align nodes and handles*

If you have a node or handle that is nearly aligned (in either X or Y) with an adjacent node, this will shift it to become aligned.

[contour_tool_07]: contour_tool_07.png width=120px height=80px