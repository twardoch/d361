## Metadata_Start 
## code: en
## title: Defining position of alignment zones 
## slug: defining-position-of-alignment-zones 
## seoTitle: Defining position of alignment zones 
## description:  
## contentType: Markdown 
## Metadata_End

Similarly, to use expressions to define the position of an alignment zone, choose the zone and enter the value in the Expression field of the Guideline panel Window \> Panels \> Guideline or Property bar.