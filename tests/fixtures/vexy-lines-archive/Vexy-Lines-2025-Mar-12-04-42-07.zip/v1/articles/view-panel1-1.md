## Metadata_Start 
## code: en
## title: View panel-1 
## slug: view-panel1-1 
## seoTitle: View panel-1 
## description:  
## contentType: Markdown 
## Metadata_End

**View panel**

The View panel is used to toggle the visibility, snapping behavior and lock status of various details of the Glyph window. The panel is divided into three parts. The top part contains buttons that control details that help in drawing and editing contours:

Preview Rounding turns on the Rounding Coordinates mode that turns off fractional precision for outline editing and transformations.

\*\\tPower Nudge\\tturns on the Power Nudge editing mode, which automatically identifies additional nodes and handles that should be nudged along with your selected nodes, and moves them to produce the best possible result.

\*\\tShow Tunni Lines allows you to edit curves using Tunni Lines.

\*\\tSuggest Nodes\\tturns on Suggest Nodes mode, where FontLab shows dotted lines suggesting where to put nodes so they are aligned to existing nodes.

\*\\tSuggest Bounds turns on Suggest Bounds mode, which adds a smart guide on the edge of the element and on the element center.

\*\\tSuggest Tangents turns on Suggest Tangents mode, which suggests that some points that are configured like tangent points, maybe ought to be actual tangent points.

\*\\tSuggest Stems\\tturns on Suggest Stems mode, which adds a smart guide on a distance to the vertical/horizontal line that is equal to the thickness of a standard stem.

The second part of the panel allows you to do all the actions available in the View › Show, View › Snap and View › Lock menus along with letting you choose the outline or mask layer for editing. To choose an outline or mask layer for editing,  click its name in the panel. The chosen layer  will be displayed in bold. This part of the panel is organized like a table:

\- The first column controls an item’s visibility in the Glyphs window. It corresponds to commands in View › Show. 

\- The second column controls the “snap to” feature, and corresponds to commands in the View › Snap menu.

\- The third column lets you lock items, and corresponds to the commands in View › Lock menu. Outline cannot be locked. The Grid and the Global Mask are always locked so the corresponding checkboxes are not available.

With the panel you can easily control all items at once using the clickable icons above the list – Show, Snap and Lock.

The third part of the panel controls the visibility of the following items:

Nodes\\tmakes all nodes visible

\*\\tCoordinates\\tshows coordinates for selected nodes

\*\\tHandles\\tmakes all handles visible

\*\\tCurvature\\tmakes curvature or curve tension visible

\*\\tAnchor cloud shows the “cloud” of anchored elements

\*\\tKerning classes\\tmakes the cloud of all glyphs belonging to the same kerning class visible in Kerning mode

\*\\tNode links shows green arrows that link nodes to Power Guides

\*\\tFontAudit\\tshows FontAudit arrows that point to odd points and suspicious curves or technical errors

\*\\tMeasurement line shows the Measurement Line, which is an optional horizontal line you can use to force the calculation of sidebearings at a particular position, instead of from the farthest extremes of the glyph.

\*\\tElement frame\\tshows gray rectangles around an element with element name if assigned, and number of references

\*\\tElement references shows red arrows that connect Element References

\*\\tCharacter placeholders shows the light gray template image showing what character should go in that glyph cell

\*\\tHints and Metrics shadows\\tshows light gray “shadows” of hints and alignment zones

\*\\tSmooth outline shows the outlines rendered smooth, but this can slow performance down

\*\\tMetrics table\\topens the Metrics table where you can edit spacing and kerning

\*\\tText bar opens the Text Bar, a horizontal text field where you can edit the “source” of the text that is shown in the Glyph window

\*\\tTrue fill\\ttoggle can be used to switch the glyph fill to 100% opaque, while keeping it possible that other items like nodes, handles, curvature, etc. can also be made visible

\*\\tMaster relations shows lines connecting corresponding nodes of different masters

Cousins\\tturns Cousins on/off