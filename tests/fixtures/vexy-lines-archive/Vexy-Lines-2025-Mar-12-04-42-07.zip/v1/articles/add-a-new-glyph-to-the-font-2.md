## Metadata_Start 
## code: en
## title: Add a new glyph to the font 
## slug: add-a-new-glyph-to-the-font-2 
## seoTitle: Add a new glyph to the font 
## description:  
## contentType: Markdown 
## Metadata_End

If you’re in the Font window and only have existing glyphs selected, or if you’re in the Glyph window, you can quickly add a new glyph with Font \> New Glyph… (which is then shown instead of Create Glyphs). On the Mac, use Alt+Cmd+N.

[![][fl7-dlg-new-glyph]](file:///Volumes/Igor/Manual/Github/fontlab/7/manual/img/fl7-dlg-new-glyph.png)

Quickly add a new glyph from Font menu

Enter a glyph name (e.g. adieresis.ss01), a character (e.g. ä) or a character with a suffix (e.g. ä.ss01) in the dialog box and press Enter. FontLab will generate the glyph using Preferences \> Operations \> New glyphs, and if you’re in the Glyph window, it’ll insert the new glyph into the text next to your current glyph.

Previously, you could add new glyphs to the font using Font \> Generate Glyphs… or Font \> Add Glyphs…, but that required using a more complex user interface. New Glyph… is quick and simple.

[fl7-dlg-new-glyph]: fl7-dlg-new-glyph.png width=143px height=65px