## Metadata_Start 
## code: en
## title: Importing and exporting keyboard shortcuts 
## slug: importing-and-exporting-keyboard-shortcuts 
## seoTitle: Importing and exporting keyboard shortcuts 
## description:  
## contentType: Markdown 
## Metadata_End

1. import keyboard shortcuts, click the ☰ menu button and select Import Shortcuts…. A standard dialog will appear where you can choose the appropriate file to import.
2. export keyboard shortcuts, click the ☰ menu button and select Export Shortcuts…. A standard dialog for saving files will appear. Here you can choose the name of the file and where it will be saved. Note that exported keyboard shortcuts are saved in a JSON file.