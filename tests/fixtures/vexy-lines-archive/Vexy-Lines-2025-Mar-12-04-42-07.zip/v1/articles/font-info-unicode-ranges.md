## Metadata_Start 
## code: en
## title: Font Info > Unicode Ranges 
## slug: font-info-unicode-ranges 
## seoTitle: Font Info > Unicode Ranges 
## description:  
## contentType: Markdown 
## Metadata_End

**Font Info \> Unicode Ranges**

Use the Font Info › Unicode Ranges section to specify the supported Unicode ranges in the font, as specified in the OS/2 table.

To select supported Unicode ranges automatically, click the Detect Unicode ranges button. FontLab will analyze the Unicode information available in the font and will automatically detect which unicode ranges this font supports.

To add a Unicode range to the list of supported ranges, select a Unicode range in the list.

To remove a Unicode range to the list of supported ranges, uncheck it in the list.

To reset the list of supported Unicode ranges, click the Remove all selected Unicode ranges button.

Use the Filter field below the list to search for a Unicode range.