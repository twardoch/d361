## Metadata_Start 
## code: en
## title: Mask Overlay 
## slug: mask-overlay 
## seoTitle: Mask Overlay 
## description:  
## contentType: Markdown 
## Metadata_End
### Overlay

<!--qh:layersMaskOverlay-->

In Vexy Lines, each layer has an **Overlay** option. When turned on, the mask becomes solid, covering its selected area and hiding any masks below it. Essentially, a layer with the activated **Overlay** will be displayed on top of other underlying layers.

| overlay: off | overlay: on|
| --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-Y0IW3XNL.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-3GCV56K5.png){height="" width="300"}|

The Overlay's behavior is also influenced by the group's Overlay setting:

* If the group's Overlay is on, its masks will cover any layers below the group.
* If it's off, the masks will only affect layers within that group.

| group overlay: off |  group overlay: on |  group overlay: on |
| --- | --- | --- |
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-IHJEKWMD.png){height="" width="238"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-7ZQ8HIOT.png){height="" width="238"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-U7V12G3R.png){height="" width="238"}|
|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-9YKY9YVB.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-9DTDC597.png){height="" width="300"}|![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-AIJ0FPA9.png){height="" width="300"}|

You can enable or disable the **Overlay** property in the **Layers** panel. The **Overlay** icon is located on the right side, next to the **Group** or **Layer** line.

![image.png](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image-ZBXPHB35.png){height="" width="238"}
<!--qh-->