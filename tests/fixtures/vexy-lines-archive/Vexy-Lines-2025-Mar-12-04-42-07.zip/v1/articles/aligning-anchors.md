## Metadata_Start 
## code: en
## title: Aligning anchors 
## slug: aligning-anchors 
## seoTitle: Aligning anchors 
## description:  
## contentType: Markdown 
## Metadata_End

Select multiple anchors, but not nodes or handles, and use one of the ==Contour > Align Points== commands to align them.