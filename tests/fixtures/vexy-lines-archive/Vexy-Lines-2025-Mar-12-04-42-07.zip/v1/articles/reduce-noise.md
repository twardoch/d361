## Metadata_Start 
## code: en
## title: Reduce Noise 
## slug: reduce-noise 
## seoTitle: Reduce Noise 
## description:  
## contentType: Markdown 
## Metadata_End

The Reduce Noise filter makes images less noisy. Some small details of the image may disappear so be ready to use Undo.

![][image_panel_02]  ![][image_panel_09]

[image_panel_02]: image_panel_02.png width=61px height=62px

[image_panel_09]: image_panel_09.png width=62px height=62px