## Metadata_Start 
## code: en
## title: Exporting FEA features to VOLT 
## slug: exporting-fea-features-to-volt-2 
## seoTitle: Exporting FEA features to VOLT 
## description:  
## contentType: Markdown 
## Metadata_End

Before you export your features as a VOLT project file (VTP file):

* Sort your Font window by Index and make sure your first 4 glyphs in the font are .notdef, NULL, CR and space.
* Switch to the master you want to export.
* In ☰ menu of the Features panel you may want to choose Add Auto Features so that FontLab automatically builds various OpenType features that the glyph repertoire of your font supports.
* In the same menu, choose Create \[kern\] and Create \[mark\] and \[mkmk\] to create the FEA code for your kerning and mark attachment for the current master. When you export the features into VTP, FontLab will then include these feature definitions, and you’ll be able to visually refine kerning and mark positioning in VOLT.

To export your features as VTP:

1. Go to File \> Export \> Export Font As…, choose the OpenType TT (.ttf) or OpenType PS (.otf) profile, click Customize… In Glyph organization, turn off Sort glyphs in optimal order and choose Use current glyph names. Export Current layer using that profile.
2. Go to File \> Export \> Features… and choose the VOLT project file (.vtp) format.
3. Navigate to the same folder as you’ve exported the font, and export the VTP file.