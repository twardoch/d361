## Metadata_Start 
## code: en
## title: File Menu 
## slug: file-menu 
## seoTitle: File Menu 
## description:  
## contentType: Markdown 
## Metadata_End

Choose File \> Open Fonts (Cmd+O) to show the Open File dialog box. Hold Cmd/Ctrl to select multiple files or hold Shift to select the first and last file of a sequence. Click OK to open them.

![][opendialog-r]

You can also open fonts inside a .zip file without first expanding it. Just select the .zip file in the dialog, and FontLab will parse it for you. This also includes the **UFOZ** format, which is a zipped UFO folder.

To open all the fonts in a folder, choose File \> Open \> Font Folder. FontLab will open all the fonts it can from this folder, while ignoring files it doesn’t recognize.

To open installed fonts, use File \> Open \> Installed Fonts. You can filter the list of the installed fonts by writing system (shows only fonts for the particular script) and also by the font name using the Filter edit box (shows only matching font names). Again, you can hold Cmd/Ctrl and Shift to select multiple fonts. Click OK to open.

![][installed-r]

Did you notice the small sample string below the list of fonts? You can type a different text by clicking there. This may be quite useful if you are searching which fonts include a given character:

![][openinstalledcustom-r]

The 15 more recently opened fonts are listed in File \> Recent Fonts. It’s the same list you see in the Welcome screen. You can reset the list in File \> Recent Fonts \> Clear Menu.

[opendialog-r]: opendialog-r.jpg width=415px height=237px

[installed-r]: installed-r.jpg width=284px height=177px

[openinstalledcustom-r]: openinstalledcustom-r.jpg width=285px height=183px