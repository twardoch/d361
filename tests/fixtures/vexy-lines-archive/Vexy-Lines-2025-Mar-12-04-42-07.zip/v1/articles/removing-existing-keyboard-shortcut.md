## Metadata_Start 
## code: en
## title: Removing existing keyboard shortcut 
## slug: removing-existing-keyboard-shortcut 
## seoTitle: Removing existing keyboard shortcut 
## description:  
## contentType: Markdown 
## Metadata_End

To remove the existing keyboard shortcut from the particular command, select the command in the list and click the Clear button on the right of the text field below the list.