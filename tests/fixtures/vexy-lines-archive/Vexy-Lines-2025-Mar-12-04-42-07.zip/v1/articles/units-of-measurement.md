## Metadata_Start 
## code: en
## title: Units of Measurement 
## slug: units-of-measurement 
## seoTitle: Units of Measurement 
## description:  
## contentType: Markdown 
## Metadata_End
In Vexy Lines, you can choose the unit that best suits your design needs. The available options are:

- Pixels
- Millimeters
- Inches
- Points

## Where Your Unit Is Used

Your selected unit is applied to several aspects of the design process:

- **Object Settings**: Controls the size and position of your objects.
- **Ruler**: Helps you align elements on the workspace.

  ![Ruler Example](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2820%29.jpeg){height="" width="250"}

- **"Meter" Tool**: Displays distances using your chosen unit.

  ![Meter Tool](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2822%29.jpeg){height="" width="250"}

## Changing the Unit of Measurement

Switching your measurement unit is easy:

1. Open the **PROPERTIES** panel
2. Find the **VIEW** tab in the very bottom of the properties list
3. Choose your preferred unit from the available options

![Change Unit Example](https://cdn.document360.io/f64a08c7-43f3-48cf-ac56-a1facdb8f0ec/Images/Documentation/image%2823%29.jpeg){height="" width="300"}

Now you're all set to work in the unit that feels most natural for your project!
