## Metadata_Start 
## code: en
## title: EXPORT LAW ASSURANCES 
## slug: export-law-assurances 
## seoTitle: EXPORT LAW ASSURANCES 
## description:  
## contentType: Markdown 
## Metadata_End

You may not use or otherwise export or reexport the software except as authorized by United States law and the laws of the jurisdiction in which the software was obtained. The software may not be used or otherwise exported or re-exported (i) into (or to a national or resident of) a United States embargoed country or (ii) to anyone on the Treasury Department’s list of Specially Designated Nationals or the U.S. Department of commerce’s Table of Denial Orders. By using the software you represent and warrant that you are not located in, under control of, or a national or resident of any such country or on any such list.