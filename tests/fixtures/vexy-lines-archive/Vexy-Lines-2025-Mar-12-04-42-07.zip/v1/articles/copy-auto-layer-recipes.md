## Metadata_Start 
## code: en
## title: Copy auto layer recipes 
## slug: copy-auto-layer-recipes 
## seoTitle: Copy auto layer recipes 
## description:  
## contentType: Markdown 
## Metadata_End

![Copy recipes to masters](https://i.fontlab.com/fl8/rn/fl8-rn-copy-autolayer-recipes.png){ .plain .r data-scale='75%' title="Copy recipes to masters" }

If you show the ==Layer properties== in the ==Layers & Masters== panel, the ==Auto layer== section at the bottom now has a ==Copy recipe to masters== button.

Click it to copy the current layer’s auto layer recipe to all other masters.
