## Metadata_Start 
## code: en
## title: Opening color OpenType+SVG 
## slug: opening-color-opentypesvg 
## seoTitle: Opening color OpenType+SVG 
## description:  
## contentType: Markdown 
## Metadata_End

![Image](https://i.fontlab.com/fl8/rn/fl8-rn9-colrv1.png){ .plain .r data-scale='33%' }

If you open an OpenType+SVG font in which different glyphs use different parts of the same SVG document stored inside the `SVG ` table, FontLab now opens the font correctly. FontLab does not retain the native SVG content in this case, but instead automatically converts the glyphs to editable elements (same as ==Element > Image > Make SVG Editable==). Previously, FontLab could not open such fonts correctly.
