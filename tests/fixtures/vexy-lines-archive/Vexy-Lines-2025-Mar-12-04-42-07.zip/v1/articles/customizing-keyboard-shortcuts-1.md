## Metadata_Start 
## code: en
## title: Customizing Keyboard Shortcuts 
## slug: customizing-keyboard-shortcuts-1 
## seoTitle: Customizing Keyboard Shortcuts 
## description:  
## contentType: Markdown 
## Metadata_End

FontLab has a basic keyboard shortcuts customization feature. Keyboard shortcuts consisting of one single key (like V for Element tool or L for Tunni Lines) cannot be customized yet, but others can be.

To assign shortcuts to menu commands, open the Commands dialog Tools \> Commands (CmdShiftP).

The Commands dialog can only show the first seventy-five commands, so not all commands are listed. Use the search field at its top to enter the name of the command you are looking for to bring it up. When you select a command from the list by clicking it, you will see its current keyboard shortcut in the text field below the list. The empty field means that no keyboard shortcut has been set for that command.

To save changes and close the dialog, click Close in the dialog.

To save the changes and also perform the selected command, click Go.