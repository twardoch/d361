## Metadata_Start 
## code: en
## title: To make a contour segment compatible across all masters 
## slug: to-make-a-contour-segment-compatible-across-all-masters 
## seoTitle: To make a contour segment compatible across all masters 
## description:  
## contentType: Markdown 
## Metadata_End

#### To make a contour segment compatible across all masters:

1\. Marquee select matching nodes on one end of the segment. The selected nodes will form the blue group.

2\. Marquee select matching nodes on the other end of the segment. The selected nodes will form the orange group.

3\. After the segment is highlighted, click once on one of the groups. FontLab will try to make the segment match in all masters by adding nodes.

matchmaker\_tool\_04.gif)

If the Allow to clean up segments button match\_clean\_segment\_alt.png is pressed, FontLab may also remove nodes from the segment. Repeat the segment matching procedure for all suspect segments, until the status circle in the Property bar turns green.

To try to automatically match masters for the whole glyph, select the Match Masters match\_master\_alt.png button, or use the Glyph \> Match Masters command, or Ctrl+M keyboard shortcut.

To clean up all the masters, select the Clean Up All Masters match\_cleanup\_alt.png button. This is the equivalent of running Contour \> Clean Up operation for all masters.

!!! **Note**

If your contours have the same number of nodes but are still incompatible, switch to the Contour tool and check whether they occasionally contain mixed PS and TT segments. If they do you must convert them.

matchmaker\_tool\_06.png

matchmaker\_tool\_05.png