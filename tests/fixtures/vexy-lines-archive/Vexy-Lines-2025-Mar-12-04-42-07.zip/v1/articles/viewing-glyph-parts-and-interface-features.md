## Metadata_Start 
## code: en
## title: Viewing glyph parts and interface features 
## slug: viewing-glyph-parts-and-interface-features 
## seoTitle: Viewing glyph parts and interface features 
## description:  
## contentType: Markdown 
## Metadata_End

In the Glyph Window, you can control the visibility of different glyph parts and interface features. Turning them on/off can assist you in drawing, spacing, kerning and hinting your glyphs, and creating a workspace that fits better with your workflow.

Use the View menu or buttons in top part of the View panel to toggle the visibility of FontLab features that help you in drawing and editing your glyphs:

![][panelview-r]

View panel

| **Button** | **Command** | **Description** |
| :-----: | :----- | :----- |
| H | Preview Rounding | Turns on the Rounding Coordinates mode that turns off fractional precision for outline editing and transformations. |
| C | Power Nudge | Turns on the \[Power Nudge\](Moving-Pointspower-nudge) editing mode. This mode automatically identifies additional nodes and handles, which should be nudged along with your selected nodes, and moves them to produce the best possible result. |
| L | Edit Tunni Lines | Allows to edit curves using Tunni Lines. Tunni lines are imaginary lines connecting two neighboring control handles of a smooth contour, and useful for symmetrically editing a curve. |
|  | Suggest Nodes | Turns on Suggest Nodes mode. During editing or drawing of contours in this mode, FontLab shows dotted lines suggesting where to put nodes so they are aligned to existing nodes. |
|  | Suggest Bounds | Turns on Suggest Bounds mode, which adds a smart guide on the edge of the element and on the element center. |
|  | Suggest Tangents | Turns on Suggest Tangents mode, which suggests that some points that are configured like tangent points, maybe ought to be actual tangent points. |
|  | Suggest Stems | Turns on Suggest Stems mode, which adds a smart guide on a distance to the vertical/horizontal line that is equal to the thickness of a standard stem. |

Use the View menu or the View button in the View panel to directly toggle the visibility of:

| **Option** | **Description** |
| :----- | :----- |
| Rulers | Shows horizontal and vertical rulers. |
| Glyph Guidelines | Horizontal, vertical and diagonal glyph (local) guides. |
| Font Guidelines | Horizontal, vertical and diagonal font (global) guides. |
| Font Metrics | Vertical font metrics, such as ascender, descender, cap height and x-height. |
| Measurement Line | Special horizontal guideline for measuring sidebearings. |
| Anchor Cloud | Shows the “cloud” of anchored elements. |
| Character Placeholders | The light grey template image showing what character should go in that glyph cell. |
| Kerning Classes | Groups of glyphs used for defining kerning classes. |
| Metrics Table | The table of glyph metrics and kerning values. |
| Text Bar | The text bar works the same way as the text field in the content sidebar of the Glyph Window. |
| Scoreboard | The Scoreboard displays large numeric values for those who want to see text in larger sizes. Works in all modes in the Glyph Window. With the Element tool it shows the coordinates of the cursor while dragging the element. |
| Element Frame | Grey rectangle around an element with element name if assigned. |
| Metrics & Hinting Shadows | Light grey “shadows” of hints and alignment zones. |
| True Fill | Turns the opaque fill on/off. |
| Cousins | Turns \[Cousins\](Using-the-Glyph-Windowcousins) on/off. |

And the View \> Show menu command or the buttons at the bottom of the View panel to toggle the visibility of:

| **Button** | **Command** | **Description** |
| :-----: | :----- | :----- |
| 󰃥 | Nodes | Makes all nodes visible. |
| 󰀘 | Coordinates | Shows coordinates for selected nodes. |
| 󰁨 | Handles | Makes all handles visible. |
| 󰀙 | Curvature | Makes curvature or curve tension visible. |
|  | Anchor Cloud | Shows the “cloud” of anchored elements. |
|  | Kerning Classes | Makes the cloud of all glyphs belonging to the same kerning class visible in Kerning mode. |
| 󰄈 | Node Links | Shows green arrows that link nodes to Power Guides. |
| ☯ | Font Audit | Shows FontAudit arrows that point to odd points and suspicious curves or technical errors. |
| 󰃫 | Measurement Line | Shows the Measurement Line, which is an optional horizontal line you can use to force the calculation of sidebearings at a particular position, instead of from the farthest extremes of the glyph. |
| 󰂦 | Element Frame | Shows grey rectangles around an element with element name if assigned, and number of references. |
| 󰂤 | Element References | Shows red arrows that connect \[Element References\](Detecting-Element-References). Note that Element References can only be seen when two or more element references are present in the Glyph window, otherwise selecting this option will have no visible effect. |
| 󰂢 | Character Placeholders | Shows the light grey template image showing what character should go in that glyph cell. |
|  | Hints and Metrics Shadow | Shows light grey “shadows” of hints and alignment zones. |
| 󰂡 | Smooth Outline | Selecting this option \[shows the outlines rendered smooth\](Outline-Appearancesmoothness-of-outlines), but this can result in slow performance. |
| ⬓ | Metrics Table | Opens the \[Metrics table\](Using-the-Metrics-Table) where you can edit spacing and kerning. |
|  | True Fill | True Fill is a toggle to switch the glyph fill to 100% opaque, while keeping it possible that other items like nodes, handles, curvature, etc. can also be made visible. |
|  | Master Relations | Shows lines connecting corresponding nodes of different masters. |
| 󰂧 | Cousins | Cousins |
| ⚙ | Select View Options | Shows a drop down list controlling the commands that will be visible. |

[panelview-r]: panelview-r.jpg width=111px height=210px