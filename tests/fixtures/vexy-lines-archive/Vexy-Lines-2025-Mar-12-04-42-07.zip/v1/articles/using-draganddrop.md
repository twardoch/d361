## Metadata_Start 
## code: en
## title: Using Drag-and-Drop 
## slug: using-draganddrop 
## seoTitle: Using Drag-and-Drop 
## description:  
## contentType: Markdown 
## Metadata_End

The quickest way to copy-paste glyphs is using the drag-drop method. It can be especially handy when copying glyphs from one font and pasting them to another one, because it is visual. To copy-paste glyphs using the drag-drop method, follow these steps:

1. Select one or several glyphs.
2. Position the mouse cursor on the selection.
3. Press the mouse button and hold down the Alt key.
4. Now drag the selection to the place where you want it to be copied.
5. Release the mouse button with the Alt key still pressed.