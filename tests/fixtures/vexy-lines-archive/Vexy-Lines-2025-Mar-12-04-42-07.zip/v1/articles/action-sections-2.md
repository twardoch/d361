## Metadata_Start 
## code: en
## title: Action sections 
## slug: action-sections-2 
## seoTitle: Action sections 
## description:  
## contentType: Markdown 
## Metadata_End

* **Basics**: very commonly used actions: four actions that perform geometric transformations (so they conceptually belong to the Adjust section, see below), and three common actions that conceptually belong to the Contour section.
* **Contour**: with these actions, you can change the technical structure of the contours and glyph layers while keeping the same design of the glyph, except for small corrections.
* **Metrics**: acthons which affect glyph metrics: sidebearings and the advance width.
* **Adjust**: with actions in the Adjust section, you can change three aspects of the glyph design: change the width, height or weight in a way that tries to be typographically correct, change corners and ink traps, and produce blank glyphs.
* **Effects**: with actions in the Effects section, you can introduce design modifications that are more decorative.
* **Guides & Anchors**: with the specialized actions from the Guides & Anchors section, you can affect “invisible” aspects of glyphs: guides and anchors.
* **Hinting**: the Hinting section has actions that change PostScript-style hints and TrueType hinting.

| **Basic** Scale Shift Slant Rotate Decompose Remove overlap Flatten glyph  | **Guides and Anchors** Add power guides Disconnect power guides Remove guides Remove anchors  | **Hinitng** Autohint Remove hints TT autohint Remove TT hints Reassign TT stems Reassign TT zones  | **Contour** Apply rounding Detect nodes Set start point Contour direction Convert to TT curves Convert to PS curves Simplify  |
| :----- | :----- | :----- | :----- |
| **Adjust** Change width Change height Change weight Add smart corners Add ink traps Remove smart corners Round corners Sharp corners Remove layer content  | **Effects** Smooth Blur Add nodes Distort Outline Perspective Shadow 3D extrude Engrave  | **Metrics** Adjust metrics Set width Set sidebearings Tracking Center layer Bind sidebearings Match metrics Nonspacing  | Clean up Harmonize Balance Nodes at extremes Make overlap Remove empty elements  |