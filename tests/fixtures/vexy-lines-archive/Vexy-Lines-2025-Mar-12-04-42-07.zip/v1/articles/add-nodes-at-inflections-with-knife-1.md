## Metadata_Start 
## code: en
## title: Add nodes at inflections with Knife 
## slug: add-nodes-at-inflections-with-knife-1 
## seoTitle: Add nodes at inflections with Knife 
## description:  
## contentType: Markdown 
## Metadata_End

When you activate the Knife tool (J, 🔪) and hold Shift near a contour, the knife indicator now “jumps” not just to extrema points but also to inflections. Shift+click and FontLab adds a node at the extremum or at the inflection.

If you have multiple masters and Edit \> Match when Editing is on, and you use Shift+click with Knife, FontLab adds the node at the extremum or inflection in the current master, and adds matching nodes in all other masters at the proportional position within the matching segments, which may not be extrema or inflections.

To add extrema in all masters, use Tools \> Actions \> Contour \> Nodes at extremes, though it may result in masters that no longer match.